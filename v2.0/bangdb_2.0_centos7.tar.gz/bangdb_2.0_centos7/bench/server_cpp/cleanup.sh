rm -rf data archive logdir reclaim_dir
