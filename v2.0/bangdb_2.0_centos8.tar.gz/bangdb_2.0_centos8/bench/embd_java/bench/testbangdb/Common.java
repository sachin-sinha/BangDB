package testbangdb;

public class Common {
	public static String key = "my key";
	public static String val = "my val";
	public static String val2 = "Amazing thing is the persistence, sheer presence of it can decide the fate of surroundings";
}
