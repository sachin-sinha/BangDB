#rm -rf reclaim_dir/ logdir/ data/ archive/
rm testbangdb/*.class
