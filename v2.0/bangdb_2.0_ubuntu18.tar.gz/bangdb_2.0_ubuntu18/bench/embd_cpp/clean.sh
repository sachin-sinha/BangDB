rm -rf data logdir archive reclaim_dir
