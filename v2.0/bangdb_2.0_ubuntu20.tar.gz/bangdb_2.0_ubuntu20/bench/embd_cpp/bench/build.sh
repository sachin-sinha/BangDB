g++ -D_FILE_OFFSET_BITS=64 -Wall -O3 -obench src/bench.cpp -I/usr/local/include/bangdb-embd  -lbangdb-embd-cpp
