package test;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		  Sample.testsanity();
		  Sample.test_manual_sample();
     		 return;
	}
}
