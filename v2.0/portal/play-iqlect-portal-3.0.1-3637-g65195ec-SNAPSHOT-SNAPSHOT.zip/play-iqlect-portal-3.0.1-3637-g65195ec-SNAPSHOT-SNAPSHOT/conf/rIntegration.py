import requests
import json
import sys
import re


client = requests.session()

#usage: rIntegration.py <url>
url = sys.argv[1] #Eg: python rIntegration.py https://ampere.iqlect.com
login = url + "/signIn"

#To get CSRF Token
# client.get(login)
# csrfToken = client.cookies['PLAY_CSRF_TOKEN']
# print "CSRF Token: ",csrfToken


#To get token by logging in
payload = {'email': "tech@iqlect.com", 'password': "iqlect", 'rememberMe': True}
# post = client.post(login, data=json.dumps(payload), headers={'Content-Type': 'application/json', 'Csrf-Token': csrfToken})
post = client.post(login, data=json.dumps(payload), headers={'Content-Type': 'application/json'})

print(post)
print(post.status_code)
print(post.text)
p = json.loads(post.text)
token = p['token']

print("Token:",token)


#This needs to be taken from https://github.com/sachin-sinha/Portal/blob/dev/play-portal/conf/adhoc_templates.json
#data = [{"name":"K Means","function_name":"kmeans","language":"R","description":"Perform K-Means Clustering on the selected data","arguments":[{"name":"clusters","displayName":"Number of Clusters","dataType":"integer","required":False,"argType":"user"},{"name":"algorithm","displayName":"Algorithm","dataType":"string","required":False,"argType":"user","enum":[{"name":"lloyd","displayName":"Lloyd","default":True},{"name":"Hartigan-Wong","displayName":"Hartigan Wong","default":False},{"name":"Forgy","displayName":"Forgy","default":False},{"name":"MacQueen","displayName":"MacQueen","default":False}]},{"name":"xAxis","displayName":"xAxis","required":True,"argType":"stream"},{"name":"yAxis","displayName":"yAxis","required":True,"argType":"stream"}]},{"name":"Box Plot","function_name":"boxplot","language":"R","description":"Draw a box plot against selected data, to identify the 5 Numbers for the data. If xAxis and yAxis are not selected then you will get a plot of all the numerical attributes in the stream","arguments":[{"name":"xAxis","displayName":"xAxis","dataType":"double","required":False,"argType":"stream"},{"name":"yAxis","displayName":"yAxis","required":False,"argType":"stream"},{"name":"groupBy","displayName":"Group By","required":False,"dependencies":["xAxis"],"argType":"stream"}]},{"name":"Scatter Plot","function_name":"scatterplot","language":"R","description":"Draw a scatter plot across selected attributes","arguments":[{"name":"xAxis","displayName":"xAxis","required":True,"argType":"stream"},{"name":"yAxis","displayName":"yAxis","required":True,"argType":"stream"},{"name":"groupBy","displayName":"Group By","required":False,"dependencies":["xAxis"],"argType":"stream"}]},{"name":"Matrix of Scatter Plots","function_name":"scatterplot","language":"R","description":"Draws a matrix of scatter plots across all numerical attributes of the stream","arguments":[]},{"name":"Histogram","function_name":"histplot","language":"R","description":"Draw a Histogram for the selected stream attribute","arguments":[{"name":"yAxis","displayName":"yAxis","required":True,"argType":"stream"},{"name":"breaks","displayName":"Number of Breaks","dataType":"integer","required":False,"argType":"user"},{"name":"curve","displayName":"Plot Density Curve","dataType":"boolean","required":False,"argType":"user"}]},{"name":"Density Plot","function_name":"kdplot","language":"R","description":"Identify how your data is distributed","arguments":[{"name":"xAxis","displayName":"xAxis","required":True,"argType":"stream"},{"name":"groupBy","displayName":"Group By","required":False,"dependencies":["xAxis"],"argType":"stream"}]},{"name":"Co-relation Matrix","function_name":"corplot","language":"R","description":"Identify co-relation across all numerical attributes of the stream","arguments":[]},{"name":"Regression Diagnostics","function_name":"regressionDiagnostics","language":"R","description":"Perform few regression diagnostic techniques","arguments":[{"name":"algorithm","displayName":"Algorithm","dataType":"string","argType":"user","required":True,"enum":[{"name":"leveragePlot","displayName":"Leverage Plots","default":True},{"name":"avPlot","displayName":"Added Variable Plots","default":False},{"name":"influencePlots","displayName":"Influence Plots","default":False},{"name":"qqPlot","displayName":"Quantile Quantile Plots","default":False},{"name":"DoSR","displayName":"Distribution of Standardized residuals","default":False},{"name":"crPlot","displayName":"Component + Residual Plot","default":False},{"name":"ceresPlot","displayName":"Ceres Plot","default":False}]}]}]
with open('adhoc_templates.json') as json_data:
    data = json.load(json_data)
print("Json retrieved from adhoc_templates.json:",json.dumps(data))


for i in data:
	print ("Function Name:",i['name'])
	# post3 = client.post(url+"/reports/scripts/adhoc/save", data=json.dumps(i), headers={'Content-Type': 'application/json', 'Csrf-Token': csrfToken, 'X-Auth-Token':token})
	post3 = client.post(url+"/reports/scripts/adhoc/save", data=json.dumps(i), headers={'Content-Type': 'application/json', 'X-Auth-Token':token})
	print("Status code:",post3.status_code)
	print("Response:",post3.text)
