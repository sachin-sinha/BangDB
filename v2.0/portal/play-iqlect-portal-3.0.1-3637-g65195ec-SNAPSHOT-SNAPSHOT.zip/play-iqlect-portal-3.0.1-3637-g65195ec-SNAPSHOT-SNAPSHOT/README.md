Ampere
=====================================

# Getting started

## Prerequisite 
 - Java 8 need to installed
 - Bangdb2.0 server up and running
 - Access to blue-moon project (https://github.com/sachin-sinha/blue-moon.git)


### For Development Setup:

1) cd play-portal
1) Run setup_dev.sh
2) sbt run - Browser will be opened with localhost:3000

### For Test Setup:

1) cd play-portal
2) Run setup_dev.sh
2) sbt dist - zip will be created in target/universal folder
3) cd target/universal
4) unzip play-iqlect-portal-*.zip (reaplce * with file name)
5) cd play-iqlect-portal-* (cd into folder)
6) ./conf/scripts/iqlect-portal start alpha
7) open http://localhost:9000 in browser

### Jenkins Build
https://jenkins.iqlect.com/job/build-portal2.0/
 - Run build with params
 - BRANCH:  bangdb2.0-UI
 - ENVFILE: alpha or local (more will be added) choose local running build in local mechine

 - Download Artificates 

 - unzip play-iqlect-portal-*.zip (reaplce * with file name)
 - cd play-iqlect-portal-* (cd into folder)
 - ./conf/scripts/iqlect-portal start alpha
 - open http://localhost:9000 in browser

