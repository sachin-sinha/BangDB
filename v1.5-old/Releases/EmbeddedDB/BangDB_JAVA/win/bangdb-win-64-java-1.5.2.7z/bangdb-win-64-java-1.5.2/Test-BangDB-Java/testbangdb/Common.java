package testbangdb;

public class Common {
	public static String key = "my key";
	public static String val = "This to test bangdb in java and see how we fare against the bangdb in c++, hope we get good results";
	public static String val2 = "Amazing thing is the persistence, sheer presence of it can decide the fate of surroundings";
}
