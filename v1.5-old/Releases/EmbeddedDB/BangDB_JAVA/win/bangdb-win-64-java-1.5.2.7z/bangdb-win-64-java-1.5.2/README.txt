****************************************************************************************

****************************************************************************************



	---------	======  ======   || 	  ======   ======  ====== 

	|	|	  ||    |    |   ||	  |	  ||	     ||
	
	|----	|         ||    |    |   ||	  |====	  |	     ||		

	|   |	| 	  ||    |  \\|   ||	  |	  ||	     ||
	
	---------	======  ====\\   ======	  ======   ======    ||

	


	||===\        /\ 	||\    ||   /=====\   ||====\    ||===\
	
	||   ||	     //\\	|| \   ||   |         ||    ||   ||   ||
	
	||===       //  \\	||  \  ||   |   ====  ||    ||	 ||=== 
	
	||   ||	   //====\\	||   \ ||   |      /  ||    ||   ||   ||

	||===/    //      \\	||    \||   \=====/   ||====/    ||===/




****************************************************************************************

****************************************************************************************



-------------
Release Note:

-------------



This is version 1.5.2 of the BangDB Embedded Flavor. This is a stable release candidate version and can be used in production or any environment as required.
Following additions have been made to 1.5.2 release compared to its earlier version;

a. Multi Table Types - Normal Table, Wide Table, Primitive Table

    Normal Table - key value store with value as opaque entity
    Wide Table - document store, value as json doc, create index on fields, query accordingly
    Primitive Table - for primitive key and value types, more performance and resource optimized

b. Multi Indexing - create index on the fly or let db create on auto mode as defined
c. json data support and parser
d. Composite key support, index on composite keys
e. Built in abstraction for RealTime data analysis;

    Store, process and query data, all in sub second fashion
    Same get, put API for all analysis, abstraction takes care of all other details
    Results are stored in processed fashion hence responds to query instantly
    Counting - Absolute, Probablistic, Unique, Non-unique
    topk - (query top k items group by 'field')
    Sliding Window - spanned and slotted, handle huge amount of data in sliding window using humble commodity machine

f. Native support for opaque, string, int, long data type (for better performance for native data types)
g. App logger as handy tool for user to log application related info using BangDB logger. The logger is
   supported natively by the BangDB which provided high performance and durability of the log. BangDB also
   logs its own error messages using the logger. However, user can use the config param to set logging using
   the logger or to syslog(for linux) or simply flush to stdout/stderr
h. BangDB now installs several signal handlers to handle the db/app/machine crash or any other shutdown gracefully
i. Fixes for performance related and other bugs
j. Many more config parameters in the bangdb.config file

k. Memory usage optimization for scan operations. Users can use pre allocated memory to run scan which improves 
   the overall memory usage
l. The APIs for scan and other get and put for user defined pre allocated memory
m. Bugs in scan for non unique keys in some corner case scenario
n. Addition of static lib for bangdb in the package

Please see detailed feature list for the release at www.iqlect.com/developer.php

Please note that this version is not backward compatible hence the previous version(s) of BangDB should be uninstalled or removed if earlier installed


To build the bangdbjava dll, lib and bangdb.jar please follow the steps as given below;

0. Please ensure Java jdk is installed on the machine.

1. BangDB windows native lib and dll - already available in native dir (bangdbwin.lib, bangdbwin.dll)

2. BangDB jar file - available in jar folder, but user should create it by running java-src/complile-bangdb.bat file
   		  
> cd java-src
> compile-bangdb.bat

 This will build bangdb.jar, copy the bangdb.jar file to jar folder for future usage
> copy bangdb.jar ..\jar

3. BangDB java native lib and dll - available, but user should create it by using VS 2012 or onwards
				  - The folder bangdbjava contains the project and solution file
				  - Open the solution java-src/bangdbjava/bangdbjava.sln and build the project

To build the native lib and dll, please ensure to set the following properties;

    Open the Project->Properties->C/C++->General and set the Additional Include Directories;

	C:\Program Files\Java\jdk1.7.0_65\include
	C:\Program Files\Java\jdk1.7.0_65\include\win32

please select the appropriate jdk folder according to your machine setting

Now just build the project and you will get the bangdjava.lib, bangdbjava.dll in x64/Release dir.
Please copy these lib and dll to the native dir for future usage

Now we have all necessary components for building apps for bangdb java on windows.

In summary you needed to do following;
------------------------------------

A. Run compile-bangdb.bat - builds jar file and create other native files
B. Build bangdbjava project - gives bangdbjava.lib and dll files


Now you are ready to play with the BangDB Java
Simply copy the all the dlls and libs available in native
dir to the test-BangDB-Java folder, also copy the jar/bangdb.jar into the Test-BangDB-Java folder

> clean.bat
> make-app.bat
> exapp.bat

That's all!