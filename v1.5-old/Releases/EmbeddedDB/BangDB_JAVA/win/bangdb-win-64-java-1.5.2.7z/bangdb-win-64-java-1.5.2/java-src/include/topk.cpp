#include "topk.h"
namespace bangdb
{
topk::topk(char *topkName, int swSizeSec, int k, bool desc, char *uniqueBy)
{
	_tk = CreateTopk(topkName, swSizeSec, k, desc, uniqueBy);
}

void topk::put(long score, char *data, int datalen, char *uniqueParam)
{
	Put_topk(_tk, score, data, datalen, uniqueParam);
}

resultset *topk::getTopK(int k)
{
	HANDLE rs = GetTopk(_tk, k);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

char *topk::getTopKJson(int k)
{
	char *val = NULL;
	GetTopkJson(_tk, &val, k);
	return val;
}

void topk::Close()
{
	CloseTopk(_tk);
	FreeHandle(&_tk);
	_tk = NULL;
}

topk::~topk()
{
}
}