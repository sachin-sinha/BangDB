package bangdb;

public class SWSlotCountImpl implements SWSlotCount {
	
	public native long init(int swTime, int swExpiry, short swType);
	public native void add(String str, int len, long ptslwc);
	public native int count(long ptslwc);
	public native void shutdown(long ptslwc);
	public native int count(int span, long ptslwc);
	public native int[] list(int span, long ptslwc);
	public native void foldSlots(long ptslwc);
	public native void reset(long ptslwc);

	public long ptslwc;

	public SWSlotCountImpl(int swTime, int swExpiry, short swType) {
		ptslwc = init(swTime, swExpiry, swType);	
	}

	@Override
	public void add(String str) {
		add(str, str.length(), ptslwc);
	}

	@Override
	public int count() {
		return count(ptslwc);
	}

	@Override
	public void shutDown() {
		shutdown(ptslwc);
	}
	
	@Override
	public int count(int span) {
		return count(span, ptslwc);
	}

	@Override
	public int[] list(int span) {
		return list(span, ptslwc);
	}

	@Override
	public void foldSlots() {
		foldSlots(ptslwc);
	}

	@Override
	public void reset() {
		reset(ptslwc);
	}
}
