package bangdb;

public enum BangDBDataOpsFlag {
	FlagSetNone,
	DataReadDone,
	MoreDataToCome,
	DataReadOverflow,
	DataReadError,
	DataOpsFlagInvalid;

	public static BangDBDataOpsFlag fromInt(int e) {
		switch(e) {
			case 0:
				return FlagSetNone;
			case 1:
				return DataReadDone;
			case 2:
				return MoreDataToCome;
			case 3:
				return DataReadOverflow;
			case 4:
				return DataReadError;
		}
		return DataOpsFlagInvalid;
	}

	public static int toInt(int ordinal)
	{
		switch(ordinal)
		{
			case 0:
				return 0;
			case 1:
				return 1;
			case 2:
				return 2;
			case 3:
				return 3;
			case 4:	
				return 4;
		}
		return 4;
	}
}
