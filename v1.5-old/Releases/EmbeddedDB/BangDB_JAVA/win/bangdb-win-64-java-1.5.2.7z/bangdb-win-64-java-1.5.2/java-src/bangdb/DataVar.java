package bangdb;

public class DataVar {

	public native long init(int size);
	public native byte[] getBuffer(long pdv);
	public native void setBuffer(byte[] _buf, long pdv);
	public native int getBufferLength(long pdv);
	public native void setBufferLength(int len, long pdv);
	public native int getDataLength(long pdv);
	public native void setDataLength(int len, long pdv);
	public native int getDataOffset(long pdv);
	public native void setDataOffset(int dofft, long pdv);
	public native int getErrorFlag(long pdv);
	public native void setErrorFlag(int flag, long pdv);
	public native void reset(long pdv);
	public native void clear(long pdv);
	
	public long pdv;
	
	public DataVar(int size) {
		pdv = init(size);
	}

	public void reset() {
		reset(pdv);
	}

	public byte[] getBuffer() {
		return getBuffer(pdv);
	}

	public void setBuffer(byte[] _buf) {
		setBuffer(_buf, pdv);
	}
	
	public int getBufferLength() {
		return getBufferLength(pdv);
	}

	public void setBufferLength(int bufLen) {
		setBufferLength(bufLen, pdv);
	}

	public int getDataLen() {
		return getDataLength(pdv);
	}

	public void setDataLen(int datLen) {
		setDataLength(datLen, pdv);
	}

	public int getDataOffset() {
		return getDataOffset(pdv);
	}

	public void setDataOffset(int datOfft) {
		setDataOffset(datOfft, pdv);
	}

	public BangDBDataOpsFlag getErrorFlag() {
		return BangDBDataOpsFlag.fromInt(getErrorFlag(pdv));
	}

	public int getErrorFlagOrdinal() {
		return getErrorFlag(pdv);
	}

	public void setErrorFlag(BangDBDataOpsFlag eflag) {
		setErrorFlag(eflag.ordinal(), pdv);
	}

	public void setErrorFlag(int eflag) {
		setErrorFlag(eflag, pdv);
	}

	public void clear() {
		clear(pdv);
	}
}
