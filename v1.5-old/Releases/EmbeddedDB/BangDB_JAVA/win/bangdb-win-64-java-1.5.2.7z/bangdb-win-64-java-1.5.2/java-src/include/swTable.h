/*
 *  swTable.h
 *
 *  Author: sachin sinha
 *  bangdbwin library
 *
 *  Copyright (C) 2012 IQLECT All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are
 *  met:
 *
 *      * Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *      * Redistributions in binary form must reproduce the above
 *  copyright notice, this list of conditions and the following disclaimer
 *  in the documentation and/or other materials provided with the
 *  distribution.
 *
 *      * The names of its contributors may not be used to endorse or
 *  promote products derived from this software without specific prior
 *  written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef _SW_TABLE_H_
#define _SW_TABLE_H_
#include "database.h"
namespace bangdb
{
class swTable {
private:
	HANDLE _swtbl;
public:
	swTable(database *db, char *tableName, table_env *tenv, int ttlsec, bool archive = false);

	void addIndex(char *idxName, table_env *tenv);

	int initialize();

	//returns handle to wideConnection
	HANDLE getConnection();

	//returns handle to wideConnection
	HANDLE getActiveConnection();

	//returns handle to wideConnection
	HANDLE getPassiveConnection();

	int put(char *str, int len, insert_options iop);

	int put(char *str, int len, char *idx, char *idxkey);

	int put(char *str, int len, char *idx, char *idxkey, int idxkeylen);

	/*
	 * scan for period sec means from (current - period) upto current
	 */
	resultset *scan(int period);

	/*
	 * scan for period sec with lag means from (current - lag - period) upto (current - lag)
	 * note lag can't be beyonbd the window size
	 */
	resultset *scan(int period, int lag);

	/*
	 * scan for whole ttlsec
	 */
	resultset *scan_full();

	resultset *scan_remaining(LONG_T from_time, int lag);

	int getTTLSec();

	bool needPassive(int windowsec);

	void Close();

	~swTable();
};
}
#endif