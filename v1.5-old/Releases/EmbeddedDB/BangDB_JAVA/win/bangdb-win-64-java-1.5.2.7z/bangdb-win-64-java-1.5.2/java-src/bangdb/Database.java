package bangdb;

public interface Database {
     
   public Table getTable(String name, DBAccess openflag, TableEnv tenv);

   public WideTable getWideTable(String name, DBAccess openflag, TableEnv tenv);

   public Table getPrimitiveTable(String name, BangDBPrimitiveDataType dataType, DBAccess openflag, TableEnv tenv);

   public void beginTransaction(Transaction txn);

   public long commitTransaction(Transaction txn);

   public void abortTransaction(Transaction txn);
         
   public int closeTable(Table tbl, DBClose dbclose); 

   public int closeTable(WideTable tbl, DBClose dbclose);
       
   public int closeTable(String rname, DBClose tbclose); 

   public void cleanup (); 
   
   public String getDBName();
   
   public void closeDatabase(DBClose dbclose);
}
