package bangdb;

public class SWEntityCountImpl implements SWEntityCount {

	public native long init(String entityName, int swTime, int swExpiry, int nEntity);

	public native int init(long ptswEntCount);

	public native int add(String entityName, String str, int len, long ptswEntCount);

	public native void addCreate(String entityName, String str, int len, int swType, int countType, long ptswEntCount);

	public native int count(String entityName, long ptswEntCount);

	public native int count(String entityName, int span, long ptswEntCount);

	public native String listCountJson(long ptswEntCount);

	public native String listCountStr(long ptswEntCount);

	public native void createEntity(String name, int swType, int countType, long ptswEntCount);

	public native void removeEntity(String name, long ptswEntCount);

	public native boolean shouldExit(long ptswEntCount);

	public native void shutdown(long ptswEntCount);

	public long ptswEntCount;

	public SWEntityCountImpl(String entityName, int swTime, int swExpiry, int nEntity) {
		ptswEntCount = init(entityName, swTime, swExpiry, nEntity);
	}

	@Override
	public int init() {
		return init(ptswEntCount);
	}

	@Override
	public int add(String entityName, String str) {
		return add(entityName, str, str.length(), ptswEntCount);
	}

	@Override
	public void addCreate(String entityName, String str, BangDBWindowType swType, BangDBCountType countType) {
		addCreate(entityName, str, str.length(), swType.ordinal(), countType.ordinal(), ptswEntCount);
	}

	@Override
	public int count(String entityName) {
		return count(entityName, ptswEntCount);
	}

	@Override
	public int count(String entityName, int span) {
		return count(entityName, span, ptswEntCount);
	}
	
	@Override
	public String listCountJson() {
		return listCountJson(ptswEntCount);
	}

	@Override
	public String listCountStr() {
		return listCountStr(ptswEntCount);
	}

	@Override
	public void createEntity(String name, BangDBWindowType swType, BangDBCountType countType) {
		createEntity(name, swType.ordinal(), countType.ordinal(), ptswEntCount);
	}

	@Override
	public void removeEntity(String name) {
		removeEntity(name, ptswEntCount);
	}

	@Override
	public boolean shouldExit() {
		return shouldExit(ptswEntCount);
	}

	@Override
	public void shutdown() {
		shutdown(ptswEntCount);
	}
}
