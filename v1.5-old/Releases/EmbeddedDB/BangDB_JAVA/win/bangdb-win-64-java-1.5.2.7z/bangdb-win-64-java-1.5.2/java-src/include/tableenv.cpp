/*
 * tableenv.cpp
 *
 *  Created on: 24-Aug-2013
 *      Author: sachin
 */

#include "tableenv.h"
namespace bangdb
{
table_env::table_env()
{
	_tenv = GetTableEnv();
}
table_env::~table_env()
{
	FreeHandle(&_tenv);
}
void table_env::reset()
{
	ResetTableEnv(_tenv);
}

void table_env::set_persist_type(int persist_type)
{
	Set_persist_type(_tenv, persist_type);
}
void table_env::set_idx_type(int BTREE_EXTHASH)
{
	Set_idx_type(_tenv, BTREE_EXTHASH);
}
void table_env::set_table_type(int _table_type)
{
	Set_table_type(_tenv, _table_type);
}
void table_env::set_key_size_byte(int key_size)
{
	Set_key_size_byte(_tenv, key_size);
}
void table_env::set_log_size_mb(int log_size_mb)
{
	Set_log_size_mb(_tenv, log_size_mb);
}
void table_env::set_table_size_hint(int TINY_SMALL_NORMAL_BIG)
{
	Set_table_size_hint(_tenv, TINY_SMALL_NORMAL_BIG);
}
void table_env::set_log_state(bool is_log_on)
{
	Set_log_state(_tenv, is_log_on ? 1 : 0);
}
void table_env::set_log_type(int log_type)
{
	Set_log_type(_tenv, log_type);
}
void table_env::set_autocommit_state(bool is_autocommit_on)
{
	Set_autocommit_state(_tenv, is_autocommit_on);
}
void table_env::set_sort_method(int sort_method)
{
	Set_sort_method(_tenv, sort_method);
}
void table_env::set_sort_dirction(int sort_direction)
{
	Set_sort_dirction(_tenv, sort_direction);
}
void table_env::set_key_type(int key_type)
{
	Set_key_type(_tenv, key_type);
}
void table_env::set_allow_duplicate(bool allowDuplicate)
{
	Set_allow_duplicate(_tenv, allowDuplicate ? 1 : 0);
}
void table_env::set_primitive_data_type(short _data_type)
{
	Set_primitive_data_type(_tenv, _data_type);
}
void table_env::set_table_subtype(short _sub_type)
{
	Set_table_subtype(_tenv, _sub_type);
}
void table_env::set_config_vars()
{
	Set_config_vars(_tenv);
}
int table_env::get_persist_type()
{
	return Get_persist_type(_tenv);
}
int table_env::get_idx_type()
{
	return Get_idx_type(_tenv);
}
int table_env::get_table_type()
{
	return Get_table_type(_tenv);
}
int table_env::get_key_size_byte()
{
	return Get_key_size_byte(_tenv);
}
int table_env::get_log_size_mb()
{
	return Get_log_size_mb(_tenv);
}
int table_env::get_table_size_hint()
{
	return Get_table_size_hint(_tenv);
}
int table_env::get_log_type()
{
	return Get_log_type(_tenv);
}
bool table_env::get_log_state()
{
	return Get_log_state(_tenv) == 0 ? false : true;
}
bool table_env::get_autocommit_state()
{
	return Get_autocommit_state(_tenv) == 0 ? false : true;
}
int table_env::get_sort_method()
{
	return Get_sort_method(_tenv);
}
int table_env::get_sort_direction()
{
	return Get_sort_direction(_tenv);
}
int table_env::get_key_type()
{
	return Get_key_type(_tenv);
}
int table_env::get_sort_id()
{
	return Get_sort_id(_tenv);
}
short table_env::get_primitive_data_type()
{
	return Get_primitive_data_type(_tenv);
}
short table_env::get_table_subtype()
{
	return Get_table_subtype(_tenv);
}
bool table_env::get_allow_duplicate()
{
	return Get_allow_duplicate(_tenv) == 0 ? false : true;
}
}