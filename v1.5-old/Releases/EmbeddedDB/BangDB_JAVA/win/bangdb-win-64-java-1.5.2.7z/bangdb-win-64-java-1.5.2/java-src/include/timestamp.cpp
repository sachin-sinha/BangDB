#include "timestamp.h"
namespace bangdb
{
unsigned long long getCurrentTimeMicroSec()
{
	return GetCurrentTimeMicroSec();
}

unsigned long long getCurrentTimeMilliSec()
{
	return GetCurrentTimeMilliSec();
}

unsigned long long uniqueTimeStampMicroSec()
{
	return UniqueTimeStampMicroSec();
}

unsigned long long uniqueTimeStampMilliSec()
{
	return UniqueTimeStampMilliSec();
}

unsigned long long getCurrentTime()
{
	return GetCurTime();
}

unsigned long long subTime(long nsec)
{
	return SubTime(nsec);
}

unsigned long long addTime(long nsec)
{
	return AddTime(nsec);
}

unsigned long long uniqueTimeStamp()
{
	return UniqueTimeStamp();
}

unsigned long long convertTimeUnit(long nsec)
{
	return ConvertTimeUnit(nsec);
}

unsigned long long getLagTime(unsigned long long from_time)
{
	return GetLagTime(from_time);
}
}