#include "database.h"
#include "bangdb_Transaction.h"
using namespace bangdb;

JNIEXPORT jboolean JNICALL Java_bangdb_Transaction_is_1active
  (JNIEnv *env, jobject obj, jlong pttxn)
{
	if(pttxn == -999999)
		return false;
	return ((bangdb_txn*)pttxn)->is_active();
}

JNIEXPORT void JNICALL Java_bangdb_Transaction_close
  (JNIEnv *env, jobject obj, jlong pttxn)
{
	if(pttxn != -999999)
		delete ((bangdb_txn*)pttxn);
}
