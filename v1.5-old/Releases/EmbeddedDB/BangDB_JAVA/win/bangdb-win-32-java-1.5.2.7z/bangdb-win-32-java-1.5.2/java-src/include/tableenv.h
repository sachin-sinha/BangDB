/*
 * tableenv.h
 *
 *  Created on: 24-Aug-2013
 *      Author: sachin
 */

#ifndef TABLEENV_H_
#define TABLEENV_H_

#include "common.h"
namespace bangdb
{
class table_env {
private:

	HANDLE _tenv;

public:

	table_env();
	void reset();

	void set_persist_type(int persist_type);
	void set_idx_type(int BTREE_EXTHASH);
	void set_table_type(int _table_type);
	void set_key_size_byte(int key_size);
	void set_log_size_mb(int log_size_mb);
	void set_table_size_hint(int TINY_SMALL_NORMAL_BIG);
	void set_log_state(bool is_log_on);
	void set_log_type(int log_type);
	void set_autocommit_state(bool is_autocommit_on);
	void set_sort_method(int sort_method);
	void set_sort_dirction(int sort_direction);
	void set_key_type(int key_type);
	void set_allow_duplicate(bool allowDuplicate);
	void set_primitive_data_type(short _data_type);
	void set_table_subtype(short _sub_type);
	void set_config_vars();

	int get_persist_type();
	int get_idx_type();
	int get_table_type();
	int get_key_size_byte();
	int get_log_size_mb();
	int get_table_size_hint();
	int get_log_type();
	bool get_log_state();
	bool get_autocommit_state();
	int get_sort_method();
	int get_sort_direction();
	int get_key_type();
	int get_sort_id();
	short get_primitive_data_type();
	short get_table_subtype();
	bool get_allow_duplicate();

	~table_env();
	friend class swTable;
	friend class database;
	friend class wideTable;
};
}
#endif /* TABLEENV_H_ */
