#include "bangdb_ScanFilter.h"
#include "database.h"
using namespace bangdb;

JNIEXPORT jlong JNICALL Java_bangdb_ScanFilter_scanfilter_1init
  (JNIEnv *env, jobject obj)
{
	scan_filter *sf = new scan_filter();
	return (jlong)sf;
}

JNIEXPORT void JNICALL Java_bangdb_ScanFilter_scanf_1reset
  (JNIEnv *env, jobject obj, jlong pscanf)
{
	((scan_filter*)pscanf)->reset();
}

JNIEXPORT void JNICALL Java_bangdb_ScanFilter_set_1filter
  (JNIEnv *env, jobject obj, jint sop, jint eop, jint limitBy, jint limit, jlong pscanf)
{
	if(pscanf == -999999)
		return;
	scan_filter *sf = (scan_filter*)pscanf;
	sf->skey_op = (scan_operator)sop;
	sf->ekey_op = (scan_operator)eop;
	sf->limitby = (scan_limit_by)limitBy;
	sf->limit = limit;
}

JNIEXPORT void JNICALL Java_bangdb_ScanFilter_scanf_1close
  (JNIEnv *env, jobject obj, jlong pscanf)
{
	if(pscanf != -999999)
		delete ((scan_filter*)pscanf);
}
