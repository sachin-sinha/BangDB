package bangdb;

public class TableImpl implements Table {
    public native long init(String rname, short openflg, TableEnv tenv);
    public native String getname(long pttb);
    //public native int init(String dbdir, long pttb);
    public native Connection getconnection(long pttb);
    public native PrimConnection getPrimConnection(long pttb);
    public native int closeconnection(Connection conn, long pttb);
    public native void dumpdata(long pttb);
    public native int getindextype(long pttb);
    public native void printstats(long pttb);
    public native int closetable(long pttb, short tableclose);
    public native int simple_close(long pttb); 
    public native int getTableType(long pttb); 
    public long pttb;

    public TableImpl(String rname, short openflg, TableEnv tenv) {
        //pttb = init(rname, openflg, tenv);
    }
 
    @Override
    public String getName() {
       return getname(pttb);
    }
   
    @Override
    public Connection getConnection() {
	if(BangDBTableType.fromInt(getTableType(pttb)) != BangDBTableType.NORMAL_TABLE)
	{
		throw new UnsupportedOperationException("table type is not NORMAL_TYPE, invalid method call");
	}
        return getconnection(pttb);
    }

    @Override
    public int getTableType() {
        return getTableType(pttb);
    }

    @Override
    public PrimConnection getPrimConnection() {
	BangDBTableType tp = BangDBTableType.fromInt(getTableType(pttb));
	if(tp != BangDBTableType.PRIMITIVE_TABLE_INT && tp != BangDBTableType.PRIMITIVE_TABLE_LONG && tp != BangDBTableType.PRIMITIVE_TABLE_STRING)
	{
		throw new UnsupportedOperationException("table type is not PRIMITIVE TYPE, invalid method call");
	}
        return getPrimConnection(pttb);
    }

    @Override
    public int closeConnection(Connection conn) {
        return closeconnection(conn, pttb);
    }

    @Override  
    public void dumpData() {
        dumpdata(pttb);
    }

    @Override
    public int getIndexType() {
        return getindextype(pttb);
    }

    @Override  
    public int closeTable(DBClose tableClose) {
	if(tableClose == null)
		tableClose = DBClose.DEFAULT;
        return closetable(pttb, (short)tableClose.ordinal());
    }

    @Override
    public int simpleClose() {
	throw new UnsupportedOperationException("method not implemented");
       //return simple_close(pttb); 
    } 
  
}
