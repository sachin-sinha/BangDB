#include "bangdb_ConnectionImpl.h"
#include "connection.h"
#include "iostream"
using namespace std;
using namespace bangdb;
/*
JNIEXPORT jobject JNICALL Java_bangdb_ConnectionImpl_getPrim__JJ
  (JNIEnv *env, jobject obj, jlong key, jlong ptconn)
{
	long val = 0;
	if(((connection *) ptconn)->get(key, &val) < 0)
		return NULL;
	
	jclass LongCls = env->FindClass("Ljava/lang/Long;");
	jmethodID jmid = env->GetMethodID(LongCls, "<init>","(J)V");

	//create an Long Object with the long return value
	jobject LongObj = env->NewObject(LongCls,jmid,val);
	
	return LongObj;
}

JNIEXPORT jobject JNICALL Java_bangdb_ConnectionImpl_getPrim__Ljava_lang_String_2J
  (JNIEnv *env, jobject obj, jstring key, jlong ptconn)
{
	jboolean iscopy;
	long val = 0;
    	connection *conn = (connection *) ptconn;
    	const char * keychar = env->GetStringUTFChars(key, &iscopy);

	if(((connection *) ptconn)->get_long((char*)keychar, &val) < 0)
		return NULL;

	env->ReleaseStringUTFChars(key, keychar);

	jclass LongCls = env->FindClass("Ljava/lang/Long;");
	jmethodID jmid = env->GetMethodID(LongCls, "<init>","(J)V");

	//create an Long Object with the long return value
	jobject LongObj = env->NewObject(LongCls,jmid,val);
	
	return LongObj;
}

JNIEXPORT jobject JNICALL Java_bangdb_ConnectionImpl_getPrim___3BJ
  (JNIEnv *env, jobject obj, jbyteArray keyarr, jlong ptconn)
{
	jboolean iscopy;
	connection *conn = (connection *)ptconn;
	void *key = env->GetByteArrayElements(keyarr, &iscopy);
	jint len = env->GetArrayLength(keyarr);
	FDT fk; fk.data = key; fk.length = len;
	long val = 0;

	if(((connection *) ptconn)->get_long(&fk, &val) < 0)
		return NULL;

	env->ReleaseByteArrayElements(keyarr, (jbyte*)key, 0);
	
	jclass LongCls = env->FindClass("Ljava/lang/Long;");
	jmethodID jmid = env->GetMethodID(LongCls, "<init>","(J)V");

	//create an Long Object with the long return value
	jobject LongObj = env->NewObject(LongCls,jmid,val);
	
	return LongObj;
}
*/
JNIEXPORT jstring JNICALL Java_bangdb_ConnectionImpl_getStr
  (JNIEnv *env, jobject obj, jlong key, jlong ptconn)
{
	FDT *v = ((connection *) ptconn)->get(key);
	if(!v)
		return NULL;
	jboolean iscopy;
	jstring jstr = env->NewStringUTF((char*)(v->data)); 
	v->free();
	delete v;
	return jstr;
}

JNIEXPORT jbyteArray JNICALL Java_bangdb_ConnectionImpl_getByte
  (JNIEnv *env, jobject obj, jlong key, jlong ptconn)
{
	FDT *v = ((connection *) ptconn)->get(key);
	if(!v)
		return NULL;
	jbyteArray retv = env->NewByteArray(v->length);
	env->SetByteArrayRegion(retv, 0, v->length, (const jbyte*)v->data);
	v->free();
	delete v;
	return retv;
}

JNIEXPORT jint JNICALL Java_bangdb_ConnectionImpl_get_1dv__Ljava_lang_String_2JJ
  (JNIEnv *env, jobject obj, jstring key, jlong dv, jlong ptconn)
{
	jboolean iscopy;
	const char * keychar = env->GetStringUTFChars(key, &iscopy);
	int retval = ((connection*)ptconn)->get((char*)keychar, strlen(keychar), (DATA_VAR*)dv);
	env->ReleaseStringUTFChars(key, keychar);
	return retval;
}

JNIEXPORT jint JNICALL Java_bangdb_ConnectionImpl_get_1dv___3BJJ
  (JNIEnv *env, jobject obj, jbyteArray keyarr, jlong dv, jlong ptconn)
{
	jboolean iscopy;
	void *key = env->GetByteArrayElements(keyarr, &iscopy);
	jint len = env->GetArrayLength(keyarr);
	int retval = ((connection*)ptconn)->get((char*)key, (int)len, (DATA_VAR*)dv);
	env->ReleaseByteArrayElements(keyarr, (jbyte*)key, 0);
	return retval;
}

JNIEXPORT jint JNICALL Java_bangdb_ConnectionImpl_get_1dv__JJJJ
  (JNIEnv *env, jobject obj, jlong key, jlong dv, jlong ptconn, jlong pttxn)
{
	return ((connection*)ptconn)->get(key, (DATA_VAR*)dv, (bangdb_txn*)pttxn);
}
/*
JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_put__Ljava_lang_String_2JSJ
  (JNIEnv *env, jobject obj, jstring key, jlong val , jshort flag, jlong ptconn)
{
	jboolean iscopy;
	const char * keychar = env->GetStringUTFChars(key, &iscopy);
	jlong retval = ((connection*)ptconn)->put((char*)keychar, val, (insert_options)flag);
	env->ReleaseStringUTFChars(key, keychar);
	return retval;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_put___3BJSJ
  (JNIEnv *env, jobject obj, jbyteArray keyarr, jlong val, jshort flag, jlong ptconn)
{
	jboolean iscopy;
	void *key = env->GetByteArrayElements(keyarr, &iscopy);
	jint len = env->GetArrayLength(keyarr);
	FDT k;
	k.data = key;
	k.length = len;
	jlong retval = ((connection*)ptconn)->put(&k, val, (insert_options)flag);
	env->ReleaseByteArrayElements(keyarr, (jbyte*)key, 0);
	return retval;
}
*/
JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_put__JLjava_lang_String_2SJ
  (JNIEnv *env, jobject obj, jlong key, jstring val, jshort flag, jlong ptconn)
{
	jboolean iscopy;
	const char * valchar = env->GetStringUTFChars(val, &iscopy);
	jlong retval = ((connection*)ptconn)->put(key, (char*)valchar, (insert_options)flag);
	env->ReleaseStringUTFChars(val, valchar);
	return retval;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_put__J_3BSJ
  (JNIEnv *env, jobject obj, jlong key, jbyteArray valarr, jshort flag, jlong ptconn)
{
	jboolean iscopy;
	void *val = env->GetByteArrayElements(valarr, &iscopy);
	jint len = env->GetArrayLength(valarr);
	FDT v;
	v.data = val;
	v.length = len;
	jlong retval = ((connection*)ptconn)->put(key, &v, (insert_options)flag);
	env->ReleaseByteArrayElements(valarr, (jbyte*)val, 0);
	return retval;
}
JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_put__J_3BSJJ
  (JNIEnv *env, jobject obj, jlong key, jbyteArray valarr, jshort flag, jlong ptconn, jlong pttxn)
{
	jboolean iscopy;
	void *val = env->GetByteArrayElements(valarr, &iscopy);
	jint len = env->GetArrayLength(valarr);
	FDT v;
	v.data = val;
	v.length = len;
	jlong retval = ((connection*)ptconn)->put(key, &v, (insert_options)flag, (bangdb_txn*)pttxn);
	env->ReleaseByteArrayElements(valarr, (jbyte*)val, 0);
	return retval;
}
/*
JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_put__JJSJ
  (JNIEnv *env, jobject obj, jlong key, jlong val, jshort flag, jlong ptconn)
{
	return ((connection*)ptconn)->put(key, val, (insert_options)flag);
}
*/
JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_put_1dv__Ljava_lang_String_2JSJ
  (JNIEnv *env, jobject obj, jstring key, jlong dv, jshort flag, jlong ptconn)
{
	jboolean iscopy;
	const char * keychar = env->GetStringUTFChars(key, &iscopy);
	jlong retval = ((connection*)ptconn)->put((char*)keychar, strlen(keychar), (DATA_VAR*)dv, (insert_options)flag);
	env->ReleaseStringUTFChars(key, keychar);
	return retval;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_put_1dv___3BJSJ
  (JNIEnv *env, jobject obj, jbyteArray keyarr, jlong dv, jshort flag, jlong ptconn)
{
	jboolean iscopy;
	void *key = env->GetByteArrayElements(keyarr, &iscopy);
	jint len = env->GetArrayLength(keyarr);
	jlong retval = ((connection*)ptconn)->put((char*)key, len, (DATA_VAR*)dv, (insert_options)flag);
	env->ReleaseByteArrayElements(keyarr, (jbyte*)key, 0);
	return retval;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_put_1dv__Ljava_lang_String_2JSJJ
  (JNIEnv *env, jobject obj, jstring key, jlong dv, jshort flag, jlong ptconn, jlong txn)
{
	jboolean iscopy;
	const char * keychar = env->GetStringUTFChars(key, &iscopy);
	jlong retval = ((connection*)ptconn)->put((char*)keychar, strlen(keychar), (DATA_VAR*)dv, (insert_options)flag, (bangdb_txn*)txn);
	env->ReleaseStringUTFChars(key, keychar);
	return retval;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_put_1dv___3BJSJJ
  (JNIEnv *env, jobject obj, jbyteArray keyarr, jlong dv, jshort flag, jlong ptconn, jlong txn)
{
	jboolean iscopy;
	void *key = env->GetByteArrayElements(keyarr, &iscopy);
	jint len = env->GetArrayLength(keyarr);
	jlong retval = ((connection*)ptconn)->put((char*)key, len, (DATA_VAR*)dv, (insert_options)flag, (bangdb_txn*)txn);
	env->ReleaseByteArrayElements(keyarr, (jbyte*)key, 0);
	return retval;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_del__JJ
  (JNIEnv *env, jobject obj, jlong key, jlong ptconn)
{
	return ((connection*)ptconn)->del((LONG_T)key);
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_del__JJJ
(JNIEnv *env, jobject obj, jlong key, jlong ptconn, jlong pttxn)
{
	return ((connection*)ptconn)->del(key, (bangdb_txn*)pttxn);
}

JNIEXPORT jobject JNICALL Java_bangdb_ConnectionImpl_scan__JJJJ
  (JNIEnv *env, jobject obj, jlong skey, jlong ekey, jlong ptconn, jlong pscanf)
{
	resultset *rs = ((connection*)ptconn)->scan((LONG_T)skey, (LONG_T)ekey, (scan_filter*)pscanf);

	if(rs == NULL)
    		return NULL;
    
    	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
    	env->SetLongField(rsObject, fld, (jlong)rs);
    	return rsObject;
}

JNIEXPORT jobject JNICALL Java_bangdb_ConnectionImpl_scan__JJJJJ
  (JNIEnv *env, jobject obj, jlong skey, jlong ekey, jlong ptconn, jlong pttxn, jlong pscanf)
{
	resultset *rs = ((connection*)ptconn)->scan(skey, ekey, (bangdb_txn*)pttxn, (scan_filter*)pscanf);

	if(rs == NULL)
    		return NULL;
    
    	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
    	env->SetLongField(rsObject, fld, (jlong)rs);
    	return rsObject;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_count
  (JNIEnv *env, jobject obj, jlong skey, jlong ekey, jlong pscanf, jlong ptconn)
{
	return ((connection*)ptconn)->count((LONG_T)skey, (LONG_T)ekey, (scan_filter*)pscanf);
}

/***********************************************/

JNIEXPORT jbyteArray JNICALL Java_bangdb_ConnectionImpl_get__Ljava_lang_String_2IJ (JNIEnv *env, jobject obj, jstring key, jint klen, jlong ptconn)
{
    	jboolean iscopy;
    	connection *conn = (connection *) ptconn;
    	const char * keychar = env->GetStringUTFChars(key, &iscopy);
	FDT fkey;
	fkey.data = (void*)keychar;
	fkey.length = klen;
	FDT *valchar = conn->get(&fkey);	
    	//char *valchar = conn->get((char *)keychar);
    	if(valchar != NULL)
    	{
		jbyteArray retv = env->NewByteArray(valchar->length);
		env->SetByteArrayRegion(retv, 0, valchar->length, (const jbyte*)valchar->data);
		valchar->free();
		delete valchar;
		env->ReleaseStringUTFChars(key, keychar);
		return retv;
		
		/*
	    jstring out =  env->NewStringUTF(valchar);
	    env->ReleaseStringUTFChars(key, keychar);
	    delete[] valchar;
	    return out;
		*/
    	}
    	env->ReleaseStringUTFChars(key, keychar);
    	return NULL;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_put__Ljava_lang_String_2ILjava_lang_String_2ISJ
 (JNIEnv *env, jobject obj, jstring key, jint klen, jstring val, jint vlen, jshort flag, jlong ptconn)
{
    	jboolean iscopy;
    	connection *conn = (connection *) ptconn;
    	const char * keychar = env->GetStringUTFChars(key, &iscopy);
    	const char *valchar = env->GetStringUTFChars(val, &iscopy);

	FDT fk, fv;
	fk.data = (void*)keychar; fk.length = klen;
	fv.data = (void*)valchar; fv.length = vlen;

    	jlong r = conn->put(&fk, &fv, (insert_options)flag);
    	env->ReleaseStringUTFChars(key, keychar);
    	env->ReleaseStringUTFChars(val, valchar);

    	return r;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_del__Ljava_lang_String_2IJ (JNIEnv *env, jobject obj, jstring key, jint klen, jlong ptconn)
{
    	jboolean iscopy;
    	connection *conn = (connection *) ptconn;
    	const char * keychar = env->GetStringUTFChars(key, &iscopy);
	FDT fk;
	fk.data = (void*)keychar; fk.length = klen;
    	jlong r = conn->del(&fk);
    	env->ReleaseStringUTFChars(key, keychar);

    	return r;
}

JNIEXPORT jobject JNICALL Java_bangdb_ConnectionImpl_Scan__Ljava_lang_String_2ILjava_lang_String_2IJJ
 (JNIEnv *env, jobject obj, jstring skey, jint sklen, jstring ekey, jint eklen, jlong ptconn, jlong pscanf)
{
	connection *conn = (connection *)ptconn;
	const char *start_key = NULL, *end_key = NULL;
	FDT sk, ek;

	if(skey != NULL)
	{
		start_key = env->GetStringUTFChars(skey, 0);
		sk.data = (void*)start_key; sk.length = sklen;
	}
	if(ekey != NULL)
	{
		end_key = env->GetStringUTFChars(ekey, 0);
		ek.data = (void*)end_key; ek.length = eklen;
	}
    
    	resultset *rs = conn->scan(skey ? &sk : NULL, ekey ? &ek : NULL, (scan_filter*)pscanf);
    
	if(skey != NULL)
	{
    		env->ReleaseStringUTFChars(skey, start_key);
	}
	if(ekey != NULL)
	{
    		env->ReleaseStringUTFChars(ekey, end_key);
	}
    
    	if(rs == NULL)
    		return NULL;
    
    	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
    	env->SetLongField(rsObject, fld, (jlong)rs);
    	return rsObject;
}

JNIEXPORT jbyteArray JNICALL Java_bangdb_ConnectionImpl_get___3BJ (JNIEnv *env, jobject obj, jbyteArray keyarr, jlong ptconn)
{
	jboolean iscopy;
	connection *conn = (connection *)ptconn;
	void *key = env->GetByteArrayElements(keyarr, &iscopy);
	jint len = env->GetArrayLength(keyarr);
	FDT fk; fk.data = key; fk.length = len;
	
	FDT *fout = conn->get(&fk);
	if(fout != NULL)
	{
		jbyteArray retv = env->NewByteArray(fout->length);
		env->SetByteArrayRegion(retv, 0, fout->length, (const jbyte*)fout->data);
		fout->free();
		delete fout;
		env->ReleaseByteArrayElements(keyarr, (jbyte*)key, 0);
		return retv;
	}
	env->ReleaseByteArrayElements(keyarr, (jbyte*)key, 0);
	return NULL;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_put___3B_3BSJ (JNIEnv *env , jobject obj, jbyteArray keyarr, jbyteArray valarr, jshort flag, jlong ptconn)
{
	jboolean iscopy;
	connection *conn = (connection *)ptconn;
	void *key = env->GetByteArrayElements(keyarr, &iscopy);
	jint klen = env->GetArrayLength(keyarr);
	void *val = env->GetByteArrayElements(valarr, &iscopy);
	jint vlen = env->GetArrayLength(valarr);
	FDT fk, fv;
	fk.data = key; fk.length = klen;
	fv.data = val; fv.length = vlen;
	
	jlong r = conn->put(&fk, &fv, (insert_options)flag);
	env->ReleaseByteArrayElements(keyarr, (jbyte*)key, 0);
	env->ReleaseByteArrayElements(valarr, (jbyte*)val, 0);

	return r;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_del___3BJ (JNIEnv *env, jobject obj, jbyteArray keyarr, jlong ptconn)
{
	jboolean iscopy;
	connection *conn = (connection *)ptconn;
	void *key = env->GetByteArrayElements(keyarr, &iscopy);
	jint klen = env->GetArrayLength(keyarr);
	FDT fk; fk.data = key; fk.length = klen;
	jlong r = conn->del(&fk);
	env->ReleaseByteArrayElements(keyarr, (jbyte*)key, 0);

	return r;
}

JNIEXPORT jobject JNICALL Java_bangdb_ConnectionImpl_Scan___3B_3BJJ
(JNIEnv *env, jobject obj, jbyteArray skey, jbyteArray ekey, jlong ptconn, jlong pscanf)
{
	connection *conn = (connection *)ptconn;
	void *start_key = NULL, *end_key = NULL;
	jint start_key_len = 0, end_key_len = 0;
	FDT fk, fv;

	if(skey != NULL)
	{
		start_key = env->GetByteArrayElements(skey, 0);
		start_key_len = env->GetArrayLength(skey);
		fk.data = start_key; fk.length = start_key_len;
	}
	if(ekey != NULL)
	{
		end_key = env->GetByteArrayElements(ekey, 0);
		end_key_len = env->GetArrayLength(ekey);
		fv.data = end_key; fv.length = end_key_len;
	}
	
	resultset *rs = conn->scan(skey ? &fk : NULL, ekey ? &fv : NULL, (scan_filter*)pscanf);
	
	if(skey != NULL)
		env->ReleaseByteArrayElements(skey, (jbyte*)start_key, 0);
	if(ekey != NULL)
		env->ReleaseByteArrayElements(ekey, (jbyte*)end_key, 0);
	
	if(rs == NULL)
		return NULL;
	
	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
   	 env->SetLongField(rsObject, fld, (jlong)rs);
   	 return rsObject;
}

JNIEXPORT jbyteArray JNICALL Java_bangdb_ConnectionImpl_get__Ljava_lang_String_2IJJ (JNIEnv *env, jobject obj, jstring key, jint klen, jlong ptconn, jlong pttxn)
{
   	jboolean iscopy;
    	connection *conn = (connection *) ptconn;
    	const char * keychar = env->GetStringUTFChars(key, &iscopy);
	FDT fkey;
	fkey.data = (void*)keychar;
	fkey.length = klen;
	FDT *valchar = conn->get(&fkey, (bangdb_txn*)pttxn);
	//char *valchar = conn->get((char *)keychar, (bangdb_txn*)pttxn);
    	if(valchar != NULL)
    	{
		jbyteArray retv = env->NewByteArray(valchar->length);
		env->SetByteArrayRegion(retv, 0, valchar->length, (const jbyte*)valchar->data);
		valchar->free();
		delete valchar;
		env->ReleaseStringUTFChars(key, keychar);
		return retv;
		/*
	    jstring out =  env->NewStringUTF(valchar);
	    env->ReleaseStringUTFChars(key, keychar);
	    delete[] valchar;
	    return out;
		*/
    	}
    	env->ReleaseStringUTFChars(key, keychar);
    	return NULL;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_put__Ljava_lang_String_2ILjava_lang_String_2ISJJ
  (JNIEnv *env, jobject obj, jstring key, jint klen, jstring val, jint vlen, jshort flag, jlong ptconn, jlong pttxn)
{
    	jboolean iscopy;
    	connection *conn = (connection *) ptconn;
    	const char * keychar = env->GetStringUTFChars(key, &iscopy);
    	const char *valchar = env->GetStringUTFChars(val, &iscopy);
	FDT fk, fv;
	fk.data = (void*)keychar; fk.length = klen;
	fv.data = (void*)valchar; fv.length = vlen;
    	jlong r = conn->put(&fk, &fv, (insert_options)flag, (bangdb_txn*)pttxn);
    	env->ReleaseStringUTFChars(key, keychar);
    	env->ReleaseStringUTFChars(val, valchar);

    	return r;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_del__Ljava_lang_String_2IJJ  (JNIEnv *env, jobject obj, jstring key, jint klen, jlong ptconn, jlong pttxn)
{
	jboolean iscopy;
    	connection *conn = (connection *) ptconn;
    	const char * keychar = env->GetStringUTFChars(key, &iscopy);
	FDT fk; fk.data = (void*)keychar; fk.length = klen;
    	jlong r = conn->del(&fk, (bangdb_txn*)pttxn);
    	env->ReleaseStringUTFChars(key, keychar);

    	return r;
}

JNIEXPORT jobject JNICALL Java_bangdb_ConnectionImpl_Scan__Ljava_lang_String_2ILjava_lang_String_2IJJJ 
(JNIEnv *env, jobject obj, jstring skey, jint skeylen, jstring ekey, jint ekeylen, jlong ptconn, jlong pttxn, jlong pscanf)
{
	connection *conn = (connection *)ptconn;
	const char *start_key = NULL, *end_key = NULL;
	FDT sk, ek;

	if(skey != NULL)
	{
		start_key = env->GetStringUTFChars(skey, 0);
		sk.data = (void*)start_key; sk.length = skeylen;
	}
	if(ekey != NULL)
	{
		end_key = env->GetStringUTFChars(ekey, 0);
		ek.data = (void*)end_key; ek.length = ekeylen;
	}
    
    	resultset *rs = conn->scan(skey ? &sk : NULL, ekey ? &ek : NULL, (bangdb_txn*)pttxn, (scan_filter*)pscanf);
    
	if(skey != NULL)
	{
	    	env->ReleaseStringUTFChars(skey, start_key);
	}
	if(ekey != NULL)
	{
	    	env->ReleaseStringUTFChars(ekey, end_key);
	}
    
    	if(rs == NULL)
    		return NULL;
    
    	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
    	env->SetLongField(rsObject, fld, (jlong)rs);
    	return rsObject;
}

JNIEXPORT jbyteArray JNICALL Java_bangdb_ConnectionImpl_get___3BJJ  (JNIEnv *env, jobject obj, jbyteArray keyarr, jlong ptconn, jlong pttxn)
{
	jboolean iscopy;
	connection *conn = (connection *)ptconn;
	void *key = env->GetByteArrayElements(keyarr, &iscopy);
	jint len = env->GetArrayLength(keyarr);
	FDT fk; fk.data = key; fk.length = len;
	
	FDT *fout = conn->get(&fk, (bangdb_txn*)pttxn);
	if(fout != NULL)
	{
		jbyteArray retv = env->NewByteArray(fout->length);
		env->SetByteArrayRegion(retv, 0, fout->length, (const jbyte*)fout->data);
		fout->free();
		delete fout;
		env->ReleaseByteArrayElements(keyarr, (jbyte*)key, 0);
		return retv;
	}
	env->ReleaseByteArrayElements(keyarr, (jbyte*)key, 0);

	return NULL;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_put___3B_3BSJJ  (JNIEnv *env, jobject obj, jbyteArray keyarr, jbyteArray valarr, jshort flag, jlong ptconn, jlong pttxn)
{
	jboolean iscopy;
	connection *conn = (connection *)ptconn;
	void *key = env->GetByteArrayElements(keyarr, &iscopy);
	jint klen = env->GetArrayLength(keyarr);
	void *val = env->GetByteArrayElements(valarr, &iscopy);
	jint vlen = env->GetArrayLength(valarr);
	FDT fk, fv; 
	fk.data = key; fk.length = klen;
	fv.data = val; fv.length = vlen;
	
	jlong r = conn->put(&fk, &fv, (insert_options)flag, (bangdb_txn*)pttxn);
	env->ReleaseByteArrayElements(keyarr, (jbyte*)key, 0);
	env->ReleaseByteArrayElements(valarr, (jbyte*)val, 0);

	return r;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_del___3BJJ  (JNIEnv *env, jobject obj, jbyteArray keyarr, jlong ptconn, jlong pttxn)
{
	jboolean iscopy;
	connection *conn = (connection *)ptconn;
	void *key = env->GetByteArrayElements(keyarr, &iscopy);
	jint klen = env->GetArrayLength(keyarr);
	FDT fk; fk.data = key; fk.length = klen;
	jlong r = conn->del(&fk, (bangdb_txn*)pttxn);
	env->ReleaseByteArrayElements(keyarr, (jbyte*)key, 0);

	return r;
}

JNIEXPORT jobject JNICALL Java_bangdb_ConnectionImpl_Scan___3B_3BJJJ  
(JNIEnv *env, jobject obj, jbyteArray skey, jbyteArray ekey, jlong ptconn, jlong pttxn, jlong pscanf)
{
	connection *conn = (connection *)ptconn;
	void *start_key = NULL, *end_key = NULL;
	jint start_key_len = 0, end_key_len = 0;
	FDT fk, fv;

	if(skey != NULL)
	{
		start_key = env->GetByteArrayElements(skey, 0);
		start_key_len = env->GetArrayLength(skey);
		fk.data = start_key; fk.length = start_key_len;
	}
	if(ekey != NULL)
	{
		end_key = env->GetByteArrayElements(ekey, 0);
		end_key_len = env->GetArrayLength(ekey);
		fv.data = end_key; fv.length = end_key_len;
	}

	resultset *rs = conn->scan(skey ? &fk : NULL, ekey ? &fv : NULL, (bangdb_txn*)pttxn, (scan_filter*)pscanf);
	
	if(skey != NULL)
		env->ReleaseByteArrayElements(skey, (jbyte*)start_key, 0);
	if(ekey != NULL)
		env->ReleaseByteArrayElements(ekey, (jbyte*)end_key, 0);
	
	if(rs == NULL)
		return NULL;
	
	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
   	 env->SetLongField(rsObject, fld, (jlong)rs);
   	 return rsObject;
}

JNIEXPORT jint JNICALL Java_bangdb_ConnectionImpl_closeconnection (JNIEnv *env, jobject obj, jlong ptconn)
{
    connection *conn = (connection *) ptconn;
    jint ret = (jint)conn->closeconnection();
    delete conn;
    return ret;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_Count__Ljava_lang_String_2ILjava_lang_String_2IJJ
  (JNIEnv *env, jobject obj, jstring skey, jint skeylen, jstring ekey, jint ekeylen, jlong pscanf, jlong ptconn)
{
	connection *conn = (connection *)ptconn;
	const char *start_key = NULL, *end_key = NULL;
	FDT sk, ek;

	if(skey != NULL)
	{
		start_key = env->GetStringUTFChars(skey, 0);
		sk.data = (void*)start_key; sk.length = skeylen;
	}
	if(ekey != NULL)
	{
		end_key = env->GetStringUTFChars(ekey, 0);
		ek.data = (void*)end_key; ek.length = ekeylen;
	}

	jlong ncount = conn->count(skey ? &sk : NULL, ekey ? &ek : NULL, (scan_filter*)pscanf);
    
	if(skey != NULL)
	{
    		env->ReleaseStringUTFChars(skey, start_key);
	}
	if(ekey != NULL)
	{
	    	env->ReleaseStringUTFChars(ekey, end_key);
	}
    
    	return ncount;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_Count___3B_3BJJ
  (JNIEnv *env, jobject obj, jbyteArray skey, jbyteArray ekey, jlong pscanf, jlong ptconn)
{
	connection *conn = (connection *)ptconn;
	void *start_key = NULL, *end_key = NULL;
	jint start_key_len = 0, end_key_len = 0;
	FDT fk, fv;

	if(skey != NULL)
	{
		start_key = env->GetByteArrayElements(skey, 0);
		start_key_len = env->GetArrayLength(skey);
		fk.data = start_key; fk.length = start_key_len;
	}
	if(ekey != NULL)
	{
		end_key = env->GetByteArrayElements(ekey, 0);
		end_key_len = env->GetArrayLength(ekey);
		fv.data = end_key; fv.length = end_key_len;
	}

	jlong ncount = conn->count(skey ? &fk : NULL, ekey ? &fv : NULL, (scan_filter*)pscanf);
	
	if(skey != NULL)
		env->ReleaseByteArrayElements(skey, (jbyte*)start_key, 0);
	if(ekey != NULL)
		env->ReleaseByteArrayElements(ekey, (jbyte*)end_key, 0);
	
	return ncount;
}

JNIEXPORT jlong JNICALL Java_bangdb_ConnectionImpl_Count__J
  (JNIEnv *env, jobject obj, jlong ptconn)
{
	connection *conn = (connection *)ptconn;
	return conn->count();
}

JNIEXPORT void JNICALL Java_bangdb_ConnectionImpl_SetAutoCommit
  (JNIEnv *nv, jobject obj, jboolean flag, jlong ptconn)
{
	connection *conn = (connection *)ptconn;
	conn->set_autocommit(flag);
}
/*
 * Class:     bangdb_ConnectionImpl
 * Method:    get_dvar
 * Signature: (JJJ)I
 */
JNIEXPORT jint JNICALL Java_bangdb_ConnectionImpl_get_1dvar
  (JNIEnv *env, jobject obj, jlong key, jlong dv, jlong ptconn)
{
	return ((connection*)ptconn)->get(key, (DATA_VAR*)dv);
}
/*
 * Class:     bangdb_ConnectionImpl
 * Method:    Scan_dvar
 * Signature: (Ljava/lang/String;ILjava/lang/String;IJJJ)Lbangdb/ResultSet;
 */
JNIEXPORT jobject JNICALL Java_bangdb_ConnectionImpl_Scan_1dvar__Ljava_lang_String_2ILjava_lang_String_2IJJJ
  (JNIEnv *env, jobject obj, jstring skey, jint sklen, jstring ekey, jint eklen, jlong pscanf, jlong dv, jlong ptconn)
{
	connection *conn = (connection *)ptconn;
	const char *start_key = NULL, *end_key = NULL;
	FDT sk, ek;

	if(skey != NULL)
	{
		start_key = env->GetStringUTFChars(skey, 0);
		sk.data = (void*)start_key; sk.length = sklen;
	}
	if(ekey != NULL)
	{
		end_key = env->GetStringUTFChars(ekey, 0);
		ek.data = (void*)end_key; ek.length = eklen;
	}
    
    	resultset *rs = conn->scan(skey ? &sk : NULL, ekey ? &ek : NULL, (scan_filter*)pscanf, (DATA_VAR*)dv);
    
	if(skey != NULL)
	{
    		env->ReleaseStringUTFChars(skey, start_key);
	}
	if(ekey != NULL)
	{
    		env->ReleaseStringUTFChars(ekey, end_key);
	}
    
    	if(rs == NULL)
    		return NULL;
    
    	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
    	env->SetLongField(rsObject, fld, (jlong)rs);
    	return rsObject;
}

/*
 * Class:     bangdb_ConnectionImpl
 * Method:    Scan_dvar
 * Signature: ([B[BJJJ)Lbangdb/ResultSet;
 */
JNIEXPORT jobject JNICALL Java_bangdb_ConnectionImpl_Scan_1dvar___3B_3BJJJ
  (JNIEnv *env, jobject obj, jbyteArray skey, jbyteArray ekey, jlong pscanf, jlong dv, jlong ptconn)
{
	connection *conn = (connection *)ptconn;
	void *start_key = NULL, *end_key = NULL;
	jint start_key_len = 0, end_key_len = 0;
	FDT fk, fv;

	if(skey != NULL)
	{
		start_key = env->GetByteArrayElements(skey, 0);
		start_key_len = env->GetArrayLength(skey);
		fk.data = start_key; fk.length = start_key_len;
	}
	if(ekey != NULL)
	{
		end_key = env->GetByteArrayElements(ekey, 0);
		end_key_len = env->GetArrayLength(ekey);
		fv.data = end_key; fv.length = end_key_len;
	}
	
	resultset *rs = conn->scan(skey ? &fk : NULL, ekey ? &fv : NULL, (scan_filter*)pscanf, (DATA_VAR*)dv);
	
	if(skey != NULL)
		env->ReleaseByteArrayElements(skey, (jbyte*)start_key, 0);
	if(ekey != NULL)
		env->ReleaseByteArrayElements(ekey, (jbyte*)end_key, 0);
	
	if(rs == NULL)
		return NULL;
	
	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
   	 env->SetLongField(rsObject, fld, (jlong)rs);
   	 return rsObject;
}

/*
 * Class:     bangdb_ConnectionImpl
 * Method:    Scan_dvar
 * Signature: (JJJJJ)Lbangdb/ResultSet;
 */
JNIEXPORT jobject JNICALL Java_bangdb_ConnectionImpl_Scan_1dvar__JJJJJ
  (JNIEnv *env, jobject obj, jlong skey, jlong ekey, jlong pscanf, jlong dv, jlong ptconn)
{
	resultset *rs = ((connection *)ptconn)->scan(skey, ekey, (scan_filter*)pscanf, (DATA_VAR*)dv);
	if(rs == NULL)
		return NULL;
	
	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
   	 env->SetLongField(rsObject, fld, (jlong)rs);
   	 return rsObject;
}

/*
 * Class:     bangdb_ConnectionImpl
 * Method:    Scan_dvar
 * Signature: (Ljava/lang/String;ILjava/lang/String;IJJJJ)Lbangdb/ResultSet;
 */
JNIEXPORT jobject JNICALL Java_bangdb_ConnectionImpl_Scan_1dvar__Ljava_lang_String_2ILjava_lang_String_2IJJJJ
  (JNIEnv *env, jobject obj, jstring skey, jint sklen, jstring ekey, jint eklen, jlong txn, jlong pscanf, jlong dv, jlong ptconn)
{
	connection *conn = (connection *)ptconn;
	const char *start_key = NULL, *end_key = NULL;
	FDT sk, ek;

	if(skey != NULL)
	{
		start_key = env->GetStringUTFChars(skey, 0);
		sk.data = (void*)start_key; sk.length = sklen;
	}
	if(ekey != NULL)
	{
		end_key = env->GetStringUTFChars(ekey, 0);
		ek.data = (void*)end_key; ek.length = eklen;
	}
    
    	resultset *rs = conn->scan(skey ? &sk : NULL, ekey ? &ek : NULL, (bangdb_txn*)txn, (scan_filter*)pscanf, (DATA_VAR*)dv);
    
	if(skey != NULL)
	{
    		env->ReleaseStringUTFChars(skey, start_key);
	}
	if(ekey != NULL)
	{
    		env->ReleaseStringUTFChars(ekey, end_key);
	}
    
    	if(rs == NULL)
    		return NULL;
    
    	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
    	env->SetLongField(rsObject, fld, (jlong)rs);
    	return rsObject;
}

/*
 * Class:     bangdb_ConnectionImpl
 * Method:    Scan_dvar
 * Signature: ([B[BJJJJ)Lbangdb/ResultSet;
 */
JNIEXPORT jobject JNICALL Java_bangdb_ConnectionImpl_Scan_1dvar___3B_3BJJJJ
  (JNIEnv *env, jobject obj, jbyteArray skey, jbyteArray ekey, jlong txn, jlong pscanf, jlong dv, jlong ptconn)
{
	connection *conn = (connection *)ptconn;
	void *start_key = NULL, *end_key = NULL;
	jint start_key_len = 0, end_key_len = 0;
	FDT fk, fv;

	if(skey != NULL)
	{
		start_key = env->GetByteArrayElements(skey, 0);
		start_key_len = env->GetArrayLength(skey);
		fk.data = start_key; fk.length = start_key_len;
	}
	if(ekey != NULL)
	{
		end_key = env->GetByteArrayElements(ekey, 0);
		end_key_len = env->GetArrayLength(ekey);
		fv.data = end_key; fv.length = end_key_len;
	}
	
	resultset *rs = conn->scan(skey ? &fk : NULL, ekey ? &fv : NULL, (bangdb_txn*)txn, (scan_filter*)pscanf, (DATA_VAR*)dv);
	
	if(skey != NULL)
		env->ReleaseByteArrayElements(skey, (jbyte*)start_key, 0);
	if(ekey != NULL)
		env->ReleaseByteArrayElements(ekey, (jbyte*)end_key, 0);
	
	if(rs == NULL)
		return NULL;
	
	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
   	 env->SetLongField(rsObject, fld, (jlong)rs);
   	 return rsObject;
}

/*
 * Class:     bangdb_ConnectionImpl
 * Method:    Scan_dvar
 * Signature: (JJJJJJ)Lbangdb/ResultSet;
 */
JNIEXPORT jobject JNICALL Java_bangdb_ConnectionImpl_Scan_1dvar__JJJJJJ
  (JNIEnv *env, jobject obj, jlong skey, jlong ekey, jlong txn, jlong pscanf, jlong dv, jlong ptconn)
{
	resultset *rs = ((connection *)ptconn)->scan(skey, ekey, (bangdb_txn*)txn, (scan_filter*)pscanf, (DATA_VAR*)dv);
	if(rs == NULL)
		return NULL;
	
	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
   	 env->SetLongField(rsObject, fld, (jlong)rs);
   	 return rsObject;
}

