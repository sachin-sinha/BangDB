#include "bangdb_SWEntityCountImpl.h"
#include "swEntityCount.h"
using namespace bangdb;

JNIEXPORT jlong JNICALL Java_bangdb_SWEntityCountImpl_init__Ljava_lang_String_2III
  (JNIEnv *env, jobject obj, jstring entityName, jint swTime, jint swExpiry, jint nEntity)
{
	jboolean iscopy;
	const char *entityname = env->GetStringUTFChars(entityName, &iscopy);
	swEntityCount *entity = new swEntityCount((char*)entityname, (int)swTime, (int)swExpiry, (int)nEntity);
	env->ReleaseStringUTFChars(entityName, entityname);
	return (jlong)entity;
}

JNIEXPORT jint JNICALL Java_bangdb_SWEntityCountImpl_init__J
  (JNIEnv *env, jobject obj, jlong ptswEntCount)
{
	swEntityCount *entity = (swEntityCount*)ptswEntCount;
	return entity->init();
}

JNIEXPORT jint JNICALL Java_bangdb_SWEntityCountImpl_add
  (JNIEnv *env, jobject obj, jstring entityName, jstring str, jint len, jlong ptswEntCount)
{
	jboolean iscopy;
	const char *entityname = env->GetStringUTFChars(entityName, &iscopy);
	const char *_str = env->GetStringUTFChars(str, &iscopy);
	swEntityCount *entity = (swEntityCount*)ptswEntCount;
	jint r = entity->add((char*)entityname, (char*)_str, (int)len);
	env->ReleaseStringUTFChars(str, _str);
	env->ReleaseStringUTFChars(entityName, entityname);
	return r;
}

JNIEXPORT void JNICALL Java_bangdb_SWEntityCountImpl_addCreate
  (JNIEnv *env, jobject obj, jstring entityName, jstring str, jint len, jint swType, jint countType, jlong ptswEntCount)
{
	jboolean iscopy;
	const char *entityname = env->GetStringUTFChars(entityName, &iscopy);
	const char *_str = env->GetStringUTFChars(str, &iscopy);
	swEntityCount *entity = (swEntityCount*)ptswEntCount;
	entity->add_create((char*)entityname, (char*)_str, (int)len, (bangdb_window_type)swType, (bangdb_count_type)countType);
	env->ReleaseStringUTFChars(str, _str);
	env->ReleaseStringUTFChars(entityName, entityname);
}

JNIEXPORT jint JNICALL Java_bangdb_SWEntityCountImpl_count__Ljava_lang_String_2J
  (JNIEnv *env, jobject obj, jstring entityName, jlong ptswEntCount)
{
	jboolean iscopy;
	const char *entityname = env->GetStringUTFChars(entityName, &iscopy);
	swEntityCount *entity = (swEntityCount*)ptswEntCount;
	jint r = entity->count((char*)entityname);
	env->ReleaseStringUTFChars(entityName, entityname);
	return r;
}

JNIEXPORT jint JNICALL Java_bangdb_SWEntityCountImpl_count__Ljava_lang_String_2IJ
  (JNIEnv *env, jobject obj, jstring entityName, jint span, jlong ptswEntCount)
{
	jboolean iscopy;
	const char *entityname = env->GetStringUTFChars(entityName, &iscopy);
	swEntityCount *entity = (swEntityCount*)ptswEntCount;
	jint r = entity->count((char*)entityname, (int)span);
	env->ReleaseStringUTFChars(entityName, entityname);
	return r;
}

JNIEXPORT jstring JNICALL Java_bangdb_SWEntityCountImpl_listCountJson
  (JNIEnv *env, jobject obj, jlong ptswEntCount)
{
	swEntityCount *entity = (swEntityCount*)ptswEntCount;
	char *str = entity->list_count_json();
	jstring jstr = env->NewStringUTF(str);
	delete[] str;
	return jstr;
}

JNIEXPORT jstring JNICALL Java_bangdb_SWEntityCountImpl_listCountStr
  (JNIEnv *env, jobject obj, jlong ptswEntCount)
{
	swEntityCount *entity = (swEntityCount*)ptswEntCount;
	char *str = entity->list_count_str();
	jstring jstr = env->NewStringUTF(str);
	delete[] str;
	return jstr;
}

JNIEXPORT void JNICALL Java_bangdb_SWEntityCountImpl_createEntity
  (JNIEnv *env, jobject obj, jstring name, jint swType, jint countType, jlong ptswEntCount)
{
	jboolean iscopy;
	const char *_name = env->GetStringUTFChars(name, &iscopy);
	swEntityCount *entity = (swEntityCount*)ptswEntCount;
	entity->createEntity((char*)_name, (bangdb_window_type)swType, (bangdb_count_type)countType);
	env->ReleaseStringUTFChars(name, _name);
}

JNIEXPORT void JNICALL Java_bangdb_SWEntityCountImpl_removeEntity
  (JNIEnv *env, jobject obj, jstring name, jlong ptswEntCount)
{
	jboolean iscopy;
	const char *_name = env->GetStringUTFChars(name, &iscopy);
	swEntityCount *entity = (swEntityCount*)ptswEntCount;
	entity->removeEntity((char*)_name);
	env->ReleaseStringUTFChars(name, _name);
}

JNIEXPORT jboolean JNICALL Java_bangdb_SWEntityCountImpl_shouldExit
  (JNIEnv *env, jobject obj, jlong ptswEntCount)
{
	return (jboolean)(((swEntityCount*)ptswEntCount)->shouldExit());
}

JNIEXPORT void JNICALL Java_bangdb_SWEntityCountImpl_shutdown
  (JNIEnv *env, jobject obj, jlong ptswEntCount)
{
	swEntityCount *entity = (swEntityCount*)ptswEntCount;
	entity->shutdown();
	delete entity;
}
