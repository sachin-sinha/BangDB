/*
 *  BangDBDef.h
 *
 *  Author: sachin sinha
 *  bangdbwin library
 *
 *  Copyright (C) 2012 IQLECT All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are
 *  met:
 *
 *      * Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *      * Redistributions in binary form must reproduce the above
 *  copyright notice, this list of conditions and the following disclaimer
 *  in the documentation and/or other materials provided with the
 *  distribution.
 *
 *      * The names of its contributors may not be used to endorse or
 *  promote products derived from this software without specific prior
 *  written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef BANGDBDEF_H_
#define BANGDBDEF_H_

namespace bangdb
{

//buffer size related macros end
#define MINLINE					128
#define SHORTLINE 				1024
#define MAXLINE 				4096               				
#define	BUFFSIZE 				8192							
#define MAXN 					16384							
#define MAXTRY					20	
#define MAXTABLE				16
#define SEP 					':' 							//in the idx file, fixed
#define SEP_STR					":"								//the str version of SEP
#define JSON_DOC_PK				"_pk"
#define MAX_RESULTSET_SIZE	8*1024*1024
typedef long long	LONG_T;
typedef short SHORT_T;
typedef long long	FILEOFF_T;
typedef unsigned long long ULONG_T;
typedef unsigned int UINT_T;

//types of db
enum bangdb_persist_type
{
	INMEM_ONLY,			//only RAM based, cache enabled (no overflow to disk, ideally overflow to other RAM)
	INMEM_PERSIST,		//disked backed, cache enabled (over flow to disk)
	PERSIST_ONLY,		//cache disabled, direct file IO
};

//types of index
enum bangdb_index_type
{
	HASH,
	EXTHASH,
	BTREE,
	HEAP
};

//log type
enum bangdb_log_type
{
	SHARED_LOG,
	PRIVATE_LOG,
};

//how should we access db, various ways
enum bangdb_open_type
{
	OPENCREATE,
	TRUNCOPEN,
	JUSTOPEN
};

//the various state of the db
enum bangdb_state
{
	DBCLOSE,
	DBOPEN
};

//how should db be closed
enum bangdb_close_type
{
	DEFAULT,
	CONSERVATIVE,
	OPTIMISTIC,
	CLEANCLOSE,
	SIMPLECLOSE,
};

//the insert options
enum insert_options
{
	INSERT_UNIQUE,		//if non-existing then insert else return
	UPDATE_EXISTING,	//if existing then update else return
	INSERT_UPDATE,		//insert if non-existing else update
	DELETE_EXISTING,	//delete if existing
};

enum db_transaction_type
{
	DB_TRANSACTION_NONE,
	DB_OPTIMISTIC_TRANSACTION,
	DB_PESSIMISTIC_TRANSACTION,
};

enum db_transaction_phase
{
	TRAN_READ_PHASE,
	TRAN_VALIDATE_PHASE,
	TRAN_COMMIT_PHASE,
	TRAN_ABORT_PHASE,
};

enum table_size_hint
{
	TINY_TABLE_SIZE,
	SMALL_TABLE_SIZE,
	NORMAL_TABLE_SIZE,
	BIG_TABLE_SIZE,
};

enum bangdb_table_type
{
	/* index and data files with opaque (void*) key */
	NORMAL_TABLE,
	WIDE_TABLE,
	/* no data file for following tables */
	INDEX_TABLE,			//opaque(void*) as key and dataoff, datlen is of actual value in the data file store in main table, no data file
	PRIMITIVE_TABLE_INT,	//int as key and int as val, stored in index file only, no data file
	PRIMITIVE_TABLE_LONG,	//long as key and long as val, stored in index file only, no data file
	PRIMITIVE_TABLE_STRING,	//opaque(void*) as key and data stored in the index only, no data file
};

enum bangdb_primitive_data_type
{
	PRIMITIVE_INT,
	PRIMITIVE_LONG,
	PRIMITIVE_STRING,
};

enum bangdb_window_type
{
	NON_SLIDING_WINDOW,
	SLIDING_WINDOW_SPAN,
	SLIDING_WINDOW_UNIT,
};

enum bangdb_count_type
{
	UNIQUE_COUNT,
	NON_UNIQUE_COUNT,
};

enum scan_limit_by
{
	LIMIT_RESULT_SIZE,
	LIMIT_RESULT_ROW,
};

enum scan_operator
{
	GT,
	GTE,
	LT,
	LTE,
};

enum bangdb_key_sort_method
{
	LEXICOGRAPH = 1,
	QUASI_LEXICOGRAPH = 2,
};

enum bangdb_key_sort_direction
{
	SORT_ASCENDING = 3,
	SORT_DESCENDING = 4,
};

enum bangdb_key_type
{
	NORMAL_KEY = 1,		//opaque (void*) as key
	COMPOSITE_KEY = 3,	//always treated as opaque even if it is of long:void* or long:long
	NORMAL_KEY_LONG = 10,	//long as key
	//COMPOSITE_KEY_LONG,	//long:long as key, all keys participating in composite will be long, no hybrid keys
};

enum bangdb_data_ops_flag
{
	FLAG_SET_NONE = 0,
	DATA_READ_DONE = 1,
	MORE_DATA_TO_COME = 2,
	DATA_READ_OVERFLOW = 3,
	DATA_READ_ERROR = 4,
};

struct scan_filter
{
	scan_operator skey_op;	//default GTE
	scan_operator ekey_op;	//default LTE
	scan_limit_by limitby;	//default LIMIT_RESULT_SIZE
	int limit;				//default 2MB (MAX_RESULTSET_SIZE) for LIMIT_RESULT_SETSIZE
	int skip_count;			//this is set by the db during scan when the last key is duplicated, so that in next scan db should skip these many counts
	scan_filter()
	{
		reset();
	}

	void reset()
	{
		skey_op = GTE;
		ekey_op = LTE;
		limitby = LIMIT_RESULT_SIZE;
		limit = MAX_RESULTSET_SIZE;
		skip_count = 0;
	}

	void clone(scan_filter *_sf)
	{
		skey_op = _sf->skey_op;
		ekey_op = _sf->ekey_op;
		limitby = _sf->limitby;
		limit = _sf->limit;
		skip_count = _sf->skip_count;
	}
};

//denotes whether analytical stuff or not
enum bangdb_table_subtype
{
	NON_ANALYTICAL_TABLE,
	SW_TABLE,
	SW_ENTITY_COUNT_TABLE,
	SW_TOPK_TABLE,
};

enum bangdb_bs_findpos
{
	BS_RANDOM_OCCUR,	//whichever is found first in the page (same as of first and last for unique key)
	BS_FIRST_OCCUR,		//the first occurrence of the key in the page
	BS_LAST_OCCUR,		//the last occurrence of the key in the page
};

}

#endif