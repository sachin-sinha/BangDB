#include "swTable.h"

namespace bangdb
{
swTable::swTable(database *db, char *tableName, table_env *tenv, int ttlsec, bool archive)
{
	_swtbl = CreateSWTable(db->_db, tableName, tenv->_tenv, ttlsec, archive ? 1 : 0);
}

void swTable::addIndex(char *idxName, table_env *tenv)
{
	AddIndexSWTable(_swtbl, idxName, tenv->_tenv);
}

int swTable::initialize()
{
	return InitSWTable(_swtbl);
}

HANDLE swTable::getConnection()
{
	return GetConnectionSWTable(_swtbl);
}

HANDLE swTable::getActiveConnection()
{
	return GetActiveConnectionSWTable(_swtbl);
}

HANDLE swTable::getPassiveConnection()
{
	return GetPassiveConnectionSWTable(_swtbl);
}

int swTable::put(char *str, int len, insert_options iop)
{
	return PutSWTable(_swtbl, str, len, iop);
}

int swTable::put(char *str, int len, char *idx, char *idxkey)
{
	return PutSWTableIdx(_swtbl, str, len, idx, idxkey, strlen(idxkey));
}

int swTable::put(char *str, int len, char *idx, char *idxkey, int idxkeylen)
{
	return PutSWTableIdx(_swtbl, str, len, idx, idxkey, idxkeylen);
}

/*
 * scan for period sec means from (current - period) upto current
 */
resultset *swTable::scan(int period)
{
	HANDLE rs = ScanSWTable(_swtbl, period);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

/*
 * scan for period sec with lag means from (current - lag - period) upto (current - lag)
 * note lag can't be beyonbd the window size
*/
resultset *swTable::scan(int period, int lag)
{
	HANDLE rs = ScanLagSWTable(_swtbl, period, lag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

/*
 * scan for whole ttlsec
*/
resultset *swTable::scan_full()
{
	HANDLE rs = ScanFullSWTable(_swtbl);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

resultset *swTable::scan_remaining(LONG_T from_time, int lag)
{
	HANDLE rs = ScanRemainingSWTable(_swtbl, from_time, lag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

int swTable::getTTLSec()
{
	return GetTTLSWTable(_swtbl);
}

bool swTable::needPassive(int windowsec)
{
	return NeedPassiveSWTable(_swtbl, windowsec) == 0 ? false : true;
}

void swTable::Close()
{
	CloseSWTable(_swtbl);
	FreeHandle(&_swtbl);
}

swTable::~swTable()
{

}
}