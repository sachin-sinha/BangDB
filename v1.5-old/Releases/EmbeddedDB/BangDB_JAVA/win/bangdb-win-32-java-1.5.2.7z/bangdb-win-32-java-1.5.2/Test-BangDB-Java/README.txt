To run the test do following;

run the make-app.bat file 

c:\bangdb-win-64-java-1.4\Test-BangDB-Java>make-app.bat

then run the test file by runnung the exapp.bat file, for ex;
to insert 100000 items using 2 threads do following;

c:\bangdb-win-64-java-1.4\Test-BangDB-Java>exapp.bat 100000 2

Further you can extend the code and rum more tests etc as you want
or, using the test code you can integrate BangDB with your project.

Enjoy!