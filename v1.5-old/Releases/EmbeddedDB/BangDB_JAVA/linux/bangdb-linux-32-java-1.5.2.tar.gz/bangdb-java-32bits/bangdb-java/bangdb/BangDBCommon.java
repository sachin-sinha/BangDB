package bangdb;

public class BangDBCommon {

	public static native void bangdbLogger(String str);
	public static native void bangdb_lasterror();
	public static void bangdb_logger(String str) {
		bangdbLogger(str);
	}
	public static void bangdb_last_error() {
		bangdb_lasterror();
	}
}
