package bangdb;

public class SWCountImpl implements SWCount {
	
	public native long init(int swTime, int swExpiry, short swType);
	public native void add(String str, int len, long ptswc);
	public native int count(long ptswc);
	public native void shutdown(long ptswc);
/* */
	public native int count(int span, long ptswc);
	public native int[] list(int span, long ptswc);
	public native void foldSlots(long ptswc);
	public native void reset(long ptswc);
/* */
	public long ptswc;

	public SWCountImpl(int swTime, int swExpiry, short swType) {
		ptswc = init(swTime, swExpiry, swType);	
	}

	@Override
	public void add(String str) {
		add(str, str.length(), ptswc);
	}

	@Override
	public int count() {
		return count(ptswc);
	}

	@Override
	public void shutDown() {
		shutdown(ptswc);
	}
	
	@Override
	public int count(int span) {
		return count(span, ptswc);
	}

	@Override
	public int[] list(int span) {
		return list(span, ptswc);
	}

	@Override
	public void foldSlots() {
		foldSlots(ptswc);
	}

	@Override
	public void reset() {
		reset(ptswc);
	}
}
