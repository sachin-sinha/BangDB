package bangdb;

public enum BangDBWindowType {
	NON_SLIDING_WINDOW,
	SLIDING_WINDOW_SPAN,
	SLIDING_WINDOW_UNIT;

	public static BangDBWindowType fromInt(int e) {
		switch(e) {
			case 0:
				return NON_SLIDING_WINDOW;
			case 1:
				return SLIDING_WINDOW_SPAN;
			case 2:
				return SLIDING_WINDOW_UNIT;
		}
		return NON_SLIDING_WINDOW;
	}

	public static int toInt(int ordinal)
	{
		switch(ordinal)
		{
			case 0:
				return 0;
			case 1:
				return 1;
			case 2:
				return 2;
		}
		return 0;
	}
}
