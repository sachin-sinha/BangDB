package bangdb;

public interface SWEntityCount {

	public int init();

	public int add(String entityName, String str);

	public void addCreate(String entityName, String str, BangDBWindowType swType, BangDBCountType countType);

	public int count(String entityName);

	public int count(String entityName, int span);

	public String listCountJson();

	public String listCountStr();

	public void createEntity(String name, BangDBWindowType swType, BangDBCountType countType);

	public void removeEntity(String name);

	public boolean shouldExit();

	public void shutdown();
}
