#include "connection.h"
namespace bangdb
{
connection::connection(HANDLE conn)
{
	_conn = conn;
}

int connection::get(const char *key, int keylen, char **val, int *vallen)
{
	return Get(_conn, (HANDLE)key, keylen, (HANDLE*)val, vallen);
}
int connection::get(const char *key, int keylen, char **val, int *vallen, bangdb_txn *txn_handle)
{
	return Get_Tran(_conn, (HANDLE)key, keylen, (HANDLE*)val, vallen, txn_handle->txn);
}

int connection::get(const char *key, int keylen, DATA_VAR *data)
{
	return GetAdvanced(_conn, (char*)key, keylen, (HANDLE*)&data->data_buf, data->data_buf_len, &data->data_len, data->data_offt, &data->flag);
}
int connection::get(const char *key, int keylen, DATA_VAR *data, bangdb_txn *txn_handle)
{
	return GetAdvancedTran(_conn, (char*)key, keylen, (HANDLE*)&data->data_buf, data->data_buf_len, &data->data_len, data->data_offt, &data->flag, txn_handle->txn);
}
int connection::get(LONG_T key, DATA_VAR *data)
{
	return GetAdvancedLong(_conn, key, &(data->data_buf), data->data_buf_len, &(data->data_len), data->data_offt, &(data->flag));
}
int connection::get(LONG_T key, DATA_VAR *data, bangdb_txn *txn_handle)
{
	return GetAdvancedLongTran(_conn, key, &(data->data_buf), data->data_buf_len, &(data->data_len), data->data_offt, &(data->flag), txn_handle->txn);
}
int connection::get(LONG_T key, LONG_T *val)
{
	return GetPrim(_conn, key, val);
}
int connection::get(int key, int *val)
{
	LONG_T _v = 0;
	int r = GetPrim(_conn, key, &_v);
	*val = (int)_v;
	return r;
}
FDT *connection::get(FDT *key)
{
	if(!key)
		return NULL;
	void *val = NULL;
	int len;
	if(Get(_conn, key->data, key->length, &val, &len) < 0)
		return NULL;
	FDT *v = new FDT(val, len);
	v->set_dll_alloc();
	return v;
}
char *connection::get(const char *key)
{
	if(!key)
		return NULL;
	char *val = NULL;
	int len;
	if(Get(_conn, (HANDLE)key, (int)strlen(key), (void**)&val, &len) < 0)
	{
		if(val)
			FreeBytes(val);
		return NULL;
	}
	return val;
}
/*
//please ensure to set the data->length to actual allocated buffer length before calling the function
int connection::get(FDT *key, FDT* data)
{
	if(!key || !data)
		return NULL;

	void *val = NULL;
	int len;
	int ret;
	
	if ((ret = Get(_conn, key->data, key->length, &val, &len)) < 0) {
		if(val)
			FreeBytes(val);
		return ret;
	}

	data->length = (data->length >= (unsigned int)len) ? len : data->length;

	memcpy(data->data, val, data->length);
	FreeBytes(val);

	return 0;
}
*/
int connection::get_long(FDT *key, LONG_T *val)
{
	return GetPrim_Str(_conn, (char*)key->data, key->length, val);
}
int connection::get_long(const char *key, LONG_T *val)
{
	return GetPrim_Str(_conn, (char*)key, strlen(key), val);
}
FDT *connection::get(FDT *key, bangdb_txn *txn)
{
	if(!key)
		return NULL;
	void *val = NULL;
	int len;
	if(Get_Tran(_conn, key->data, key->length, &val, &len, txn->txn) < 0)
	{
		if(val)
			FreeBytes(val);
		return NULL;
	}
		FDT *v = new FDT(val, len);
	v->set_dll_alloc();
	return v;
}

char *connection::get(const char *key, bangdb_txn *txn)
{
	if(!key)
		return NULL;
	char *val = NULL;
	int len;
	if(Get_Tran(_conn, (HANDLE)key, (int)strlen(key), (void**)&val, &len, txn->txn) < 0)
	{
		if(val)
			FreeBytes(val);
		return NULL;
	}
	return val;
}
/*
//please ensure to set the data->length to actual allocated buffer length before calling the function
int connection::get(FDT *key, FDT *data, bangdb_txn *txn)
{
	if(!key || !data || !txn || !txn->txn)
		return NULL;

	void *val = NULL;
	int len;
	int ret;
	
	if ((ret = Get_Tran(_conn, key->data, key->length, &val, &len, txn->txn)) < 0) {
		return ret;
	}

	data->length = (data->length >= (unsigned int)len) ? len : data->length;

	memcpy(data->data, val, data->length);
	FreeBytes(val);

	return 0;
}
*/
FDT *connection::get(LONG_T key)
{
	char *val = NULL;
	int vlen;
	if(Get_Long_Str(_conn, key, (HANDLE*)&val, &vlen) < 0)
	{
		if(val)
			FreeBytes(val);
		return NULL;
	}
	FDT *v = new FDT((void*)val, vlen);
	v->set_dll_alloc();
	return v;
}
FILEOFF_T connection::put(const char *key, int keylen, DATA_VAR *val, insert_options flag)
{
	return PutAdvanced(_conn, (char*)key, keylen, val->data_buf, val->data_buf_len, &val->data_len, val->data_offt, &val->flag, flag);
}
FILEOFF_T connection::put(const char *key, int keylen, DATA_VAR *val, insert_options flag, bangdb_txn *txn_handle)
{
	return PutAdvanced_Tran(_conn, (char*)key, keylen, val->data_buf, val->data_buf_len, &val->data_len, val->data_offt, &val->flag, flag, txn_handle->txn);
}
FILEOFF_T connection::put(FDT *k, FDT *v, insert_options flag)
{
	if(!k || !v)
		return -1;
	return Put(_conn, k->data, k->length, v->data, v->length, (int)flag);
}
FILEOFF_T connection::put(LONG_T key, LONG_T val, insert_options flag)
{
	return PutPrim(_conn, key, val, flag);
}
FILEOFF_T connection::put(int key, int val, insert_options flag)
{
	return PutPrim(_conn, key, val, flag);
}
FILEOFF_T connection::put(const char *key, LONG_T val, insert_options flag)
{
	return PutPrim_Str(_conn, (char*)key, strlen(key), val, flag);
}
FILEOFF_T connection::put(LONG_T key, FDT *val, insert_options flag)
{
	return PutByte_Long(_conn, key, (HANDLE)val->data, val->length, flag);
}
FILEOFF_T connection::put(LONG_T key, FDT *val, insert_options flag, bangdb_txn *txn)
{
	return PutByte_Long_Tran(_conn, key, (HANDLE)val->data, val->length, flag, (HANDLE)txn->txn);
}
FILEOFF_T connection::put(LONG_T key, const char *val, insert_options flag)
{
	return PutByte_Long(_conn, key, (HANDLE)val, strlen(val), flag);
}
FILEOFF_T connection::put(FDT *key, LONG_T val, insert_options flag)
{
	return PutPrim_Str(_conn, (char*)key->data, key->length, val, flag);
}
FILEOFF_T connection::put(const char *k, const char *v, insert_options flag)
{
	if(!k || !v)
		return -1;
	return Put(_conn, (HANDLE)k, (int)strlen(k), (HANDLE)v, (int)strlen(v), (int)flag);
}
FILEOFF_T connection::put(FDT *key, FDT *val, insert_options flag, bangdb_txn *txn)
{
	if(!key || !val)
		return -1;
	return Put_Tran(_conn, key->data, key->length, val->data, val->length, (int)flag, txn->txn);
}

FILEOFF_T connection::put(const char *key, const char *val, insert_options flag, bangdb_txn *txn)
{
	if(!key || !val)
		return -1;
	return Put_Tran(_conn, (HANDLE)key, (int)strlen(key), (HANDLE)val, (int)strlen(val), (int)flag, txn->txn);
}
FILEOFF_T connection::del(FDT *k)
{
	if(!k)
		return -1;
	return Del(_conn, k->data, k->length);
}
FILEOFF_T connection::del(const char *k)
{
	if(!k)
		return -1;
	return Del(_conn, (HANDLE)k, (int)strlen(k));
}
FILEOFF_T connection::del(FDT *key, bangdb_txn *txn)
{
	if(!key || !txn || !txn->txn)
		return -1;
	return Del_Tran(_conn, key->data, key->length, txn->txn);
}

FILEOFF_T connection::del(const char *key, bangdb_txn *txn)
{
	if(!key || !txn || !txn->txn)
		return -1;
	return Del_Tran(_conn, (HANDLE)key, (int)strlen(key), txn->txn);
}
FILEOFF_T connection::del(LONG_T key)
{
	return Del_Long(_conn, key);
}
FILEOFF_T connection::del(LONG_T key, bangdb_txn *txn)
{
	return Del_Long_Tran(_conn, key, (HANDLE)txn->txn);
}
FILEOFF_T connection::del(int key)
{
	return Del_Long(_conn, key);
}
resultset *connection::scan(FDT *sk, FDT *ek, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	
	void *s = sk?sk->data:NULL;
	int slen = sk?sk->length:0;
	void *e = ek?ek->data:NULL;
	int elen = ek?ek->length:0;
	
	HANDLE rs = Scan(_conn, s, slen, e, elen, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}
resultset* connection::scan(LONG_T skey, LONG_T ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;

	HANDLE rs = Scan_Long(_conn, skey, ekey, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}
resultset* connection::scan(LONG_T skey, LONG_T ekey, bangdb_txn *txn, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;

	HANDLE rs = Scan_Long_Tran(_conn, skey, ekey, (HANDLE)txn->txn, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}

resultset *connection::scan(int skey, int ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE rs = Scan_Long(_conn, skey, ekey, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}
resultset *connection::scan(const char *sk, const char *ek, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	int sklen = sk?(int)strlen(sk):0;
	int eklen = ek?(int)strlen(ek):0;
	HANDLE rs = Scan(_conn, (HANDLE)sk, sklen, (HANDLE)ek, eklen, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}
resultset *connection::scan(FDT *sk, FDT *ek, bangdb_txn *txn, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	void *s = sk?sk->data:NULL;
	int slen = sk?sk->length:0;
	void *e = ek?ek->data:NULL;
	int elen = ek?ek->length:0;
	
	HANDLE rs = Scan_Tran(_conn, s, slen, e, elen, txn->txn, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}
resultset *connection::scan(const char *sk, const char *ek, bangdb_txn *txn, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	int sklen = sk?(int)strlen(sk):0;
	int eklen = ek?(int)strlen(ek):0;
	HANDLE rs = Scan_Tran(_conn, (HANDLE)sk, sklen, (HANDLE)ek, eklen, txn->txn, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}

resultset* connection::scan(const char *skey, const char *ekey, bangdb_txn *txn_handle, scan_filter *sf, DATA_VAR *dv)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE rs = Scan_DV_Tran(_conn, (HANDLE)skey, skey ? strlen(skey) : 0, (HANDLE)ekey, ekey ? strlen(ekey) : 0, txn_handle->txn, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

resultset* connection::scan(FDT *skey, FDT *ekey, bangdb_txn *txn_handle, scan_filter *sf, DATA_VAR *dv)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE rs = Scan_DV_Tran(_conn, skey ? skey->data : NULL, skey ? skey->length : 0, ekey ? ekey->data : NULL, ekey ? ekey->length : 0, txn_handle->txn, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

resultset* connection::scan(LONG_T skey, LONG_T ekey, bangdb_txn *txn_handle, scan_filter *sf, DATA_VAR *dv)
{
	HANDLE rs = Scan_DV_Long_Tran(_conn, skey, ekey, (HANDLE)txn_handle->txn, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

resultset* connection::scan(const char *skey, const char *ekey, scan_filter *sf, DATA_VAR *dv)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE rs = Scan_DV(_conn, (HANDLE)skey, skey ? strlen(skey) : 0, (HANDLE)ekey, ekey ? strlen(ekey) : 0, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

resultset* connection::scan(FDT *skey, FDT *ekey, scan_filter *sf, DATA_VAR *dv)
{
	HANDLE rs = Scan_DV(_conn, skey ? skey->data : NULL, skey ? skey->length : 0, ekey ? ekey->data : NULL, ekey ? ekey->length : 0, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

resultset* connection::scan(LONG_T skey, LONG_T ekey, scan_filter *sf, DATA_VAR *dv)
{
	HANDLE rs = Scan_DV_Long(_conn, skey, ekey, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

LONG_T connection::count(FDT *sk, FDT *ek, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	void *s = sk?sk->data:NULL;
	int slen = sk?sk->length:0;
	void *e = ek?ek->data:NULL;
	int elen = ek?ek->length:0;
	return Count(_conn, s, slen, e, elen, (HANDLE)sf);
}
LONG_T connection::count(const char *sk, const char *ek, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	int sklen = sk?(int)strlen(sk):0;
	int eklen = ek?(int)strlen(ek):0;
	return Count(_conn, (HANDLE)sk, sklen, (HANDLE)ek, eklen, (HANDLE)sf);
}
LONG_T connection::count()
{
	return count((FDT*)NULL, (FDT*)NULL);
}
LONG_T connection::count(LONG_T skey, LONG_T ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	return Count_LONG(_conn, skey, ekey, (HANDLE)sf);
}
LONG_T connection::count(int skey, int ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	return Count_LONG(_conn, skey, ekey, (HANDLE)sf);
}

void connection::set_autocommit(bool flag)
{
	SetAutoCommit(_conn, flag?1:0);
}
bangdb_persist_type connection::getpersisttype()
{
	return (bangdb_persist_type)GetPersistType(_conn);
}
bangdb_index_type connection::getidxtype()
{
	return (bangdb_index_type)GetIdxType(_conn);
}
HANDLE connection::gethandle()
{
	return _conn;
}

int connection::closeconnection()
{
	int ret = CloseConnection(_conn);
	FreeHandle(&_conn);
	return ret;
}

connection::~connection()
{
}
}