#include "composite.h"
namespace bangdb
{
char *makeComposite_long_long(ULONG_T k1, ULONG_T k2)
{
	return MakeComposite_long_long(k1, k2);
}

char *makeComposite_str_str(char *k1, char *k2)
{
	return MakeComposite_str_str(k1, k2);
}

char *makeComposite_str_str2(char *k1, int l1, char *k2, int l2)
{
	return MakeComposite_str_str2(k1, l2, k2, l2);
}

char *makeComposite_long_str(ULONG_T k1, char *k2)
{
	return MakeComposite_long_str(k1, k2);
}

char *makeComposite_long_str2(ULONG_T k1, char *k2, int l2)
{
	return MakeComposite_long_str2(k1, k2, l2);
}

char *makeComposite_str_long(char *k1, ULONG_T k2)
{
	return MakeComposite_str_long(k1, k2);
}

char *makeComposite_str_long2(char *k1, int l1, ULONG_T k2)
{
	return MakeComposite_str_long2(k1, l1, k2);
}

char *makeComposite(char *k, ...)
{
	char *key = NULL, *temp, *nextkey;
	va_list vl;
	va_start(vl, k);
	int len = strlen(k);
	key = new char[len+1];
	memcpy(key, k, len);
	key[len] = 0;
	
	while(true)
	{
		nextkey = va_arg(vl, char*);
		if(nextkey == NULL)
			break;
		temp = makeComposite_str_str(key, nextkey);
		delete[] key;
		key = temp;
	}
	va_end(vl);
	return key;
}
}