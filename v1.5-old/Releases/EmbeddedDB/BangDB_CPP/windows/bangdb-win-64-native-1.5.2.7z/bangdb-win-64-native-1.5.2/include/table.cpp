#include "table.h"
namespace bangdb
{
table::table(HANDLE table, char *tableName)
{
	if(table == NULL || tableName == NULL)
		err_exit("table handle or name can't be null, quitting");
	_table = table;
	_tableName = new char[strlen(tableName) + 1];
	memcpy_s(_tableName, strlen(tableName), tableName, strlen(tableName));
	_tableName[strlen(tableName)] = '\0';
}

table::~table()
{
	delete[] _tableName;
	_tableName = NULL;
}

connection *table::getconnection()
{
	if(gettabletype() != NORMAL_TABLE)
	{
		BangDB_Logger("Table type is not NORMAL_TABLE - error");
		return NULL;
	}
	HANDLE conn = GetConnection(_table);
	if(conn == NULL)
		return NULL;

	return new connection(conn);
}

primConnection *table::getPrimConnection()
{
	int tp = gettabletype();
	if(tp != PRIMITIVE_TABLE_INT && tp != PRIMITIVE_TABLE_LONG && tp != PRIMITIVE_TABLE_STRING)
	{
		BangDB_Logger("Table type is not PRIMITIVE TYPE - error");
		return NULL;
	}
	HANDLE conn = GetPrimConnection(_table);
	if(conn == NULL)
		return NULL;

	return new primConnection(conn);
}

int table::closetable(bangdb_close_type tableclose)
{
	int ret = CloseThisTable(_table, (int)tableclose);
//	if(ret == 0)
		FreeHandle(&_table);
	return ret < 0 ? -1 : 0;
}

int table::closeconnection(connection *conn)
{
	HANDLE _conn = conn->gethandle();
	int ret = CloseTableConnection(_table, _conn);
	FreeHandle(&_conn);
	return ret;
}

int table::getindextype()
{
	return GetIndexType(_table);
}

int table::getpersisttype()
{
	return GetTablePersistType(_table);
}

int table::gettabletype()
{
	return GetTableType(_table);
}

char *table::getname()
{
	return _tableName;
}

int table::dumpdata()
{
	return DumpData(_table);
}

HANDLE table::getHandle()
{
	return _table;
}
}