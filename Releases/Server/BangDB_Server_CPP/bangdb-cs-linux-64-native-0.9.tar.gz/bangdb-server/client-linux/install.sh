#!/bin/sh
#
#assumes that the lib.so is in the same dir as the install.sh file
#

BANGDB_CLIENT=bangdb-client
BANGDB_CLIENT_LIB_NAME=libbangdb-client.so.0.9
SYS_LIB_DIR=/usr/local/lib
BANGDB_SRC_INCLUDE_DIR=include
DEST_INCLUDE_DIR=/usr/local/include
BANGDB_CONFIG=bangdb.config
BANGDB_CLIENT_SRC_INCLUDE_DIR=include

cp $BANGDB_CLIENT_LIB_NAME $SYS_LIB_DIR/
echo "copied the bangdb lib.so to sys local lib dir"

ln -sf $SYS_LIB_DIR/$BANGDB_CLIENT_LIB_NAME $SYS_LIB_DIR/libbangdb-client.so
ln -sf $SYS_LIB_DIR/libbangdb-client.so $SYS_LIB_DIR/libbangdb-client.so.0
echo "created the soft link to the lib."

ldconfig

mkdir $DEST_INCLUDE_DIR/$BANGDB_CLIENT
cp $BANGDB_CLIENT_SRC_INCLUDE_DIR/*.h $DEST_INCLUDE_DIR/$BANGDB_CLIENT
echo "copied the headers in the sys local include dir"
echo "Install completed successfully!"
