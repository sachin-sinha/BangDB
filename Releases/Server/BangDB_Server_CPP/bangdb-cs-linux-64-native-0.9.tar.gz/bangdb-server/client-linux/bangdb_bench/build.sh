g++ -D_FILE_OFFSET_BITS=64 -Wall -O3 -obench bench.cpp -lpthread -lbangdb-client
