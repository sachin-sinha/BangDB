#!/bin/sh
#
#

BANGDB_CLIENT=bangdb-client
SYS_LIB_DIR=/usr/local/lib
DEST_INCLUDE_DIR=/usr/local/include

read -p 'Do you want to uninstall bangdb(y/n)? : ' YN
if [ "$YN" == 'n' ]; then
echo "exiting..."
exit
fi

rm -rf $DEST_INCLUDE_DIR/$BANGDB_CLIENT
echo "headers deleted from the sys local include dir"

rm $SYS_LIB_DIR/libbangdb-client.so*
echo "removed the soft link to the lib.so"
echo "Uninstall completed successfully!, you may manually delete the data dir when needed"






