To run the test, do following;

1. Open the solution (This is for win vista and beyond)
2. Edit the path string in the program.cs to point it to the directory 
   where you have kept the downloaded dlls and config file
3. Edit the reference and add the BangDB-CSharp.dll
4. Build and run

You can further add edit the test cases to suit your need.
Enjoy!