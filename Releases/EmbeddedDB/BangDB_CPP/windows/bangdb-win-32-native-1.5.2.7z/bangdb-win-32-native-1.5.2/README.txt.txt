 ****************************************************************************************

****************************************************************************************



	---------	======  ======   || 	  ======   ======  ====== 

	|	|	  ||    |    |   ||	  |	  ||	     ||
	
	|----	|         ||    |    |   ||	  |====	  |	     ||		

	|   |	| 	  ||    |  \\|   ||	  |	  ||	     ||
	
	---------	======  ====\\   ======	  ======   ======    ||

	


	||===\        /\ 	||\    ||   /=====\   ||====\    ||===\
	
	||   ||	     //\\	|| \   ||   |         ||    ||   ||   ||
	
	||===       //  \\	||  \  ||   |   ====  ||    ||	 ||=== 
	
	||   ||	   //====\\	||   \ ||   |      /  ||    ||   ||   ||

	||===/    //      \\	||    \||   \=====/   ||====/    ||===/




****************************************************************************************

****************************************************************************************



-------------
Release Note:

-------------



This is version 1.5.2 of the BangDB Embedded Flavor. This is a stable release candidate version and can be used in production or any environment as required.
Following additions have been made to 1.5.2 release compared to its earlier version;

a. Multi Table Types - Normal Table, Wide Table, Primitive Table

    Normal Table - key value store with value as opaque entity
    Wide Table - document store, value as json doc, create index on fields, query accordingly
    Primitive Table - for primitive key and value types, more performance and resource optimized

b. Multi Indexing - create index on the fly or let db create on auto mode as defined
c. json data support and parser
d. Composite key support, index on composite keys
e. Built in abstraction for RealTime data analysis;

    Store, process and query data, all in sub second fashion
    Same get, put API for all analysis, abstraction takes care of all other details
    Results are stored in processed fashion hence responds to query instantly
    Counting - Absolute, Probablistic, Unique, Non-unique
    topk - (query top k items group by 'field')
    Sliding Window - spanned and slotted, handle huge amount of data in sliding window using humble commodity machine

f. Native support for opaque, string, int, long data type (for better performance for native data types)
g. App logger as handy tool for user to log application related info using BangDB logger. The logger is
   supported natively by the BangDB which provided high performance and durability of the log. BangDB also
   logs its own error messages using the logger. However, user can use the config param to set logging using
   the logger or to syslog(for linux) or simply flush to stdout/stderr
h. BangDB now installs several signal handlers to handle the db/app/machine crash or any other shutdown gracefully
i. Fixes for performance related and other bugs
j. Many more config parameters in the bangdb.config file

k. Memory usage optimization for scan operations. Users can use pre allocated memory to run scan which improves 
   the overall memory usage
l. The APIs for scan and other get and put for user defined pre allocated memory
m. Bugs in scan for non unique keys in some corner case scenario
n. Addition of static lib for bangdb in the package

Please see detailed feature list for the release at www.iqlect.com/developer.php

Please note that this version is not backward compatible hence the previous version(s) of BangDB should be uninstalled or removed if earlier installed


The zip file (bangdb-[win]-[32/64]bits-[build]-[version].7z) contains following;
a. bangdbwin.dll
b. bangdbwin.lib
c. bangdbwin.exp
d. README
e. bangdb.config
f. include/headers
g. TestBangDB-CPP - folder which contains test project

uncompress the file and keep the stuff in your application directory [or you can register the dlls as well, but not required]

Please see the developer section at www.iqlect.com/developer.php or product whitepaper for more information on 
BangDB and getting started for quckly start bulding applications.

BangDB is supported for windows vista and onwards

For detailed information on building app with BangDB, please go to the BangDb Manual at www.iqlect.com/developer.php

Enjoy!