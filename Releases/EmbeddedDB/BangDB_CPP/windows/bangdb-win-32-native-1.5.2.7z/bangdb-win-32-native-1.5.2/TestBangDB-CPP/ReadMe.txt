========================================================================
    CONSOLE APPLICATION : TestBangDB-CPP Project Overview
========================================================================

To run the test, simply open the project solution, build and run.

But to do from scratch, here are the details;


The files are useful to run benchmark for bangdb. Typical get/put operations can be performed.
This may also help in undersanding the usage of bangdb API.

TO run the tests;
1. Download BangDB 1.5 for Native Windows
2. Create a project and add include dir of the downloaded BangDB 1.4
3. Point to the bangdb lib
4. Add the test files present in this download (test_common.h, TestBangDB-CPP.h and cpp)
5. Build the project
6. Run with command line arguments like following;

exename <num_threads> <num_items> <put/get/all/overlap> [factor(optional define only with overlap)]

example; To test put for 1M items with 4 threads use following;

exename 4 1000000 put

etc...

Enjoy!