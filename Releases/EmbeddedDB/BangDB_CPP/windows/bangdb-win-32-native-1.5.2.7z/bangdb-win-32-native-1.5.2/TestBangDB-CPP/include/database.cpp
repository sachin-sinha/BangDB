#include "database.h"
namespace bangdb
{
database::database(char *dbname, char* configpath, db_transaction_type transaction_type, char *dbpath)
{
	if(dbname == NULL)
		err_exit("dbname can't be null, quitting");

	_dbname = new char[strlen(dbname) + 1];
	memcpy_s(_dbname, strlen(dbname) + 1, dbname, strlen(dbname));
	_dbname[strlen(dbname)] = '\0';

	_db = GetDatabase(dbname, configpath, (int)transaction_type, dbpath);
}

database::~database()
{

}

table *database::gettable(char *tableName, bangdb_open_type flag, table_env *tenv)
{
	HANDLE tbl = NULL;
	tbl = GetTable(_db, tableName, (int)flag, tenv ? tenv->_tenv : NULL);
	
	if(tbl == NULL)
	{
		err_out("Error in getting table");
		return NULL;
	}
	return new table(tbl, tableName);
}

wideTable *database::getWideTable(char *name, bangdb_open_type openflag, table_env *tenv)
{
	HANDLE tbl = GetWideTable(_db, name, openflag, tenv ? tenv->_tenv : NULL);
	if(!tbl)
	{
		err_out("Error in getting wide table");
		return NULL;
	}
	return new wideTable(tbl, name);
}

table *database::getPrimitiveTable(char *name, bangdb_primitive_data_type dataType, bangdb_open_type openflag, table_env *tenv)
{
	HANDLE tbl = GetPrimitiveTable(_db, name, dataType, openflag, tenv ? tenv->_tenv : NULL);
	if(!tbl)
	{
		err_out("Error in getting primitive table");
		return NULL;
	}
	return new table(tbl, name);
}

void database::begin_transaction(bangdb_txn *txn)
{
	return Begin_Transaction(_db, (HANDLE)txn->txn);
}
long long database::commit_transaction(bangdb_txn *txn)
{
	return Commit_Transaction(_db, (HANDLE)txn->txn);
}
void database::abort_transaction(bangdb_txn *txn)
{
	Abort_Transaction(_db, (HANDLE)txn->txn);
}

void database::closedatabase(bangdb_close_type flag)
{
	if(_db != NULL)
		CloseDatabase(_db, (int)flag);
	if(_dbname != NULL)
		delete[] _dbname;
	//FreeHandle(&_db);
	_db = NULL;
	_dbname = NULL;
}

int database::closetable(table *tbl, bangdb_close_type flag)
{
	int ret = CloseTableHandle(_db, tbl->_table, (int)flag);
	FreeHandle(&tbl->_table);
	return ret;
}

int database::closetable(wideTable *tbl, bangdb_close_type tblclose)
{
	int r = CloseWideTableHandle(_db, tbl->_wtbl, tblclose);
	FreeHandle(&tbl->_wtbl);
	return r;
}
}