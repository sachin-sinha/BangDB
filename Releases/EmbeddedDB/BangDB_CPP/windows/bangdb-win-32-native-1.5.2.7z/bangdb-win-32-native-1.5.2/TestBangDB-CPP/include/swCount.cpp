#include "swCount.h"
namespace bangdb
{
swCount::swCount(int swTime, int swExpiry, bangdb_count_type countType)
{
	_swc = CreateSWCount(swTime, swExpiry, countType, SLIDING_WINDOW_SPAN);
}

void swCount::add(char *s, int len)
{
	AddSWCount(_swc, s, len, SLIDING_WINDOW_SPAN);
}

int swCount::list(int span, int **count_list, int *size)
{
	return ListSWCount(_swc, span, count_list, size, SLIDING_WINDOW_SPAN);
}

int swCount::count()
{
	return CountSWCount(_swc, SLIDING_WINDOW_SPAN);
}

int swCount::count(int span)
{
	return CountSpanSWCount(_swc, span, SLIDING_WINDOW_SPAN);
}

void swCount::foldSlots()
{
	FoldSlotsSWCount(_swc, SLIDING_WINDOW_SPAN);
}

void swCount::reset()
{
	ResetSWCount(_swc, SLIDING_WINDOW_SPAN);
}

void swCount::Close()
{
	CloseSWCount(_swc, SLIDING_WINDOW_SPAN);
	FreeHandle(&_swc);
}

swCount::~swCount()
{

}
}