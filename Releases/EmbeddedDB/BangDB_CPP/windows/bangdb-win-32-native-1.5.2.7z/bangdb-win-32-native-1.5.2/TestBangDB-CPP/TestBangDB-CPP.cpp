// TestBangDB-CPP.cpp : Defines the entry point for the console application.
//

#include "TestBangdb-CPP.h"

int main(int argc, char* argv[])
{
	if(argc < 4)
	{
		printf("----------------------------------------------------------------------------\n");
		printf("usage: bangdb_bench <num_threads> <num_items> <put/get/all/overlap> [factor(optional define only with overlap)]\n");
		printf("----------------------------------------------------------------------------\n");
		printf("running the default test, trying to put and get 500,000 items using 4 threads\n");
		bangdb_bench(4, 500000, "all", 0);
		exit(0);
	}
	int factor = 0;
	if(strncmp(argv[3], "overlap", 7) == 0)
	{
		if(argc != 5)
		{
			printf("please provide factor for the overlap\n");
			exit(0);
		}
		factor = atoi(argv[4]);
	}

	bangdb_bench(atoi(argv[1]), atoi(argv[2]), argv[3], factor);
	
	return 0;
}

