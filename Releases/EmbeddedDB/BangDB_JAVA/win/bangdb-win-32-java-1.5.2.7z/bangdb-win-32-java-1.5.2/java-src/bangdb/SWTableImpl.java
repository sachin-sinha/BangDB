package bangdb;

public class SWTableImpl implements SWTable {
	
	public native long init(long ptdb, String tableName, TableEnv tenv, int ttlsec, int archive);
	
	public native void addIndex(String idxName, TableEnv tenv, long ptswtbl);

	public native void initialize(long ptswtbl);

	public native int put(String str, int len, int iop, long ptswtbl);

	public native int put(String str, int len, String idx, String idxKey, long ptswtbl);

	public native ResultSet scan(int period, long ptswtbl);

	public native ResultSet scan(int period, int lag, long ptswtbl);

	public native ResultSet scanFull(long ptswtbl);

	public native ResultSet scanRemaining(long fromTime, int lag, long ptswtbl);

	public native void close(long ptswtbl);
/* */
	public native long getConnection(long ptswtbl);

	public native long getActiveConnection(long ptswtbl);

	public native long getPassiveConnection(long ptswtbl);

	public native int getTTLSec(long ptswtbl);
/* */
	public long ptswtbl;
	

	public SWTableImpl(DatabaseImpl db, String tableName, TableEnv tenv, int ttlsec, boolean archive) {
		ptswtbl = init(db.ptdb, tableName, tenv, ttlsec, archive ? 1 : 0);
	}

	@Override
	public WideConnectionImpl getConnection() {
		return new WideConnectionImpl(getConnection(ptswtbl));
	}

	@Override
	public WideConnectionImpl getActiveConnection() {
		return new WideConnectionImpl(getActiveConnection(ptswtbl));
	}

	@Override
	public WideConnectionImpl getPassiveConnection() {
		return new WideConnectionImpl(getPassiveConnection(ptswtbl));
	}

	@Override
	public int getTTLSec() {
		return getTTLSec(ptswtbl);
	}

	@Override
	public void addIndex(String idxName, TableEnv tenv) {
		addIndex(idxName, tenv, ptswtbl);
	}

	@Override
	public void initialize() {
		initialize(ptswtbl);
	}

	@Override
	public int put(String str, InsertOptions iop) {
		return put(str, str.length(), iop.ordinal(), ptswtbl);
	}

	@Override
	public int put(String str, String idx, String idxKey) {
		return put(str, str.length(), idx, idxKey, ptswtbl);
	}

	@Override
	public ResultSet scan(int period) {
		return scan(period, ptswtbl);
	}

	@Override
	public ResultSet scan(int period, int lag) {
		return scan(period, lag, ptswtbl);
	}

	@Override
	public ResultSet scanFull() {
		return scanFull(ptswtbl);
	}

	@Override
	public ResultSet scanRemaining(long fromTime, int lag) {
		return scanRemaining(fromTime, lag, ptswtbl);
	}

	@Override
	public void close() {
		close(ptswtbl);
	}
}
