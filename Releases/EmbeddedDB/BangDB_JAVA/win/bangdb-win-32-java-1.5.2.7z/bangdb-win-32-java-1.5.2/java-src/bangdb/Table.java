package bangdb;

public interface Table {
	public String getName();
	    
	public Connection getConnection();

	public PrimConnection getPrimConnection();

	public int getTableType();
	
	public int closeConnection(Connection conn);
	   
	public void dumpData();

	public int getIndexType();
	   
	public int closeTable(DBClose tableClose); 
	 
	public int simpleClose();
}
