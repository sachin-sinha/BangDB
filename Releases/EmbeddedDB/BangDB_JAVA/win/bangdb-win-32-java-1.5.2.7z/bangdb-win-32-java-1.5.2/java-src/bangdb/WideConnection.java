package bangdb;

public interface WideConnection {

	public long putDoc(String jsonStr);

	public long putDoc(String key, String jsonStr, InsertOptions flag);

	public long putDoc(long key, String jsonStr, InsertOptions flag);

	public ResultSet scanDoc(String idxName, String skey, String ekey, ScanFilter sf);

	public ResultSet scanDoc(String idxName, long skey, long ekey, ScanFilter sf);

public ResultSet scanDoc(String idxName, byte[] skey, byte[] ekey, ScanFilter sf);

public ResultSet scanDoc(String idxName, String skey, String ekey, ScanFilter sf, DataVar dv);

public ResultSet scanDoc(String idxName, long skey, long ekey, ScanFilter sf, DataVar dv);

public ResultSet scanDoc(String idxName, byte[] skey, byte[] ekey, ScanFilter sf, DataVar dv);

	public long put(String key, String val, String idxName, String idxVal);

	public long put(String key, byte[] val, String idxName, String idxVal);

	public long put(byte[] key, String val, String idxName, String idxVal);

	public long put(long key, String val, String idxName, String idxVal);

	public long put(long key, byte[] val, String idxName, String idxVal);

	public ResultSet scan(String idxName, String skey, String ekey, ScanFilter sf);

public ResultSet scan(String idxName, String skey, String ekey, ScanFilter sf, DataVar dv);

public ResultSet scan(String idxName, byte[] skey, byte[] ekey, ScanFilter sf, DataVar dv);

	public String getStr(long key);

	public byte[] getByte(long key);

	public long del(long key);

	public ResultSet scan(long skey, long ekey, ScanFilter sf);

	public long count(long skey, long ekey, ScanFilter sf);


    public long put(byte[] key, byte[] val, String index_name, byte[] index_val);

    public long put(String key, String val, InsertOptions flag) ;

    public long put(byte[] key, byte[] val, InsertOptions flag);

    public long put(String key, String val, InsertOptions flag, Transaction txn);

    public long put(byte[] key, byte[] val, InsertOptions flag, Transaction txn);

	public long put(long key, String val, InsertOptions flag);

	public long put(long key, byte[] val, InsertOptions flag);

	public long put(long key, byte[] val, InsertOptions flag, Transaction txn);


    public ResultSet scan(String idxName, byte[] skey, byte[] ekey, ScanFilter sf);

    public ResultSet scan(String skey, String ekey, ScanFilter sf);

    public ResultSet scan(byte[] skey, byte[] ekey, ScanFilter sf);

    public ResultSet scan(String skey, String ekey, Transaction txn, ScanFilter sf);

    public ResultSet scan(byte[] skey, byte[] ekey, Transaction txn, ScanFilter sf);

	public ResultSet scan(long skey, long ekey, Transaction txn, ScanFilter sf);


public ResultSet scanDv(String skey, String ekey, ScanFilter sf, DataVar dv);

public ResultSet scanDv(byte[] skey, byte[] ekey, ScanFilter sf, DataVar dv);

public ResultSet scanDv(long skey, long ekey, ScanFilter sf, DataVar dv);

public ResultSet scanDv(String skey, String ekey, Transaction txn, ScanFilter sf, DataVar dv);

public ResultSet scanDv(byte[] skey, byte[] ekey, Transaction txn, ScanFilter sf, DataVar dv);

public ResultSet scanDv(long skey, long ekey, Transaction txn, ScanFilter sf, DataVar dv);

	    
    public String get(String key);
    
    public byte[] get(byte[] key, Transaction txn);
    
    public String get(String key, Transaction txn);

    public byte[] get(byte[] key);

public int get(long key, DataVar dv);

public int get(long key, DataVar dv, Transaction txn);
    
    
    public long del(String key);

    public long del(byte[] key); 
    
    public long del(String key, Transaction txn);
                         
    public long del(byte[] key, Transaction txn);  

	public long del(long key, Transaction txn);

    
    public long count(String skey, String ekey, ScanFilter sf);

    public long count(byte[] skey, byte[] ekey, ScanFilter sf);

    public long count();


    public void setAutoCommit(boolean flag);                       
                                                 
    public int closeConnection();
}
