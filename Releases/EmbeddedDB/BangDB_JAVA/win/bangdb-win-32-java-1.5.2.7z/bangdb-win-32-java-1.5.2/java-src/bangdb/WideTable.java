package bangdb;

public interface WideTable {

	public int addIndex_str(String idx_name, int idx_size, boolean allowDuplicates);

	public int addIndex_num(String idx_name, boolean allowDuplicates);

	public int addIndex(String idx_name, TableEnv tenv);

	public int dropIndex(String idxName);

	public String getName();
	    
	public WideConnection getConnection();
	
	public int closeAllConnections();
	   
	public void dumpData();

	public int getIndexType();
	   
	public int closeTable(DBClose tableClose); 
	 
	public int simpleClose();
}
