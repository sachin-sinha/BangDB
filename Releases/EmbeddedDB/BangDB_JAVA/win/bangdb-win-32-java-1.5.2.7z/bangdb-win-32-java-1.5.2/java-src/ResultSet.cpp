#include "bangdb_ResultSetImpl.h"
#include "database.h"
#include "resultset.h"
#include "iostream"
using namespace std;
using namespace bangdb;

JNIEXPORT jbyteArray JNICALL Java_bangdb_ResultSetImpl_GetNextKey (JNIEnv *env, jobject obj, jlong ptrs)
{
	resultset *rs = (resultset*)ptrs;
	FDT *k = rs->getNextKey();
	jbyteArray retv = env->NewByteArray(k->length);
	env->SetByteArrayRegion(retv, 0, k->length, (const jbyte*)k->data);
	return  retv;
	//don't delete the k as user may again want to look at it
	//only Clear() would free all the memory related to resultset
}

JNIEXPORT jlong JNICALL Java_bangdb_ResultSetImpl_GetNextKeyLong (JNIEnv *env, jobject obj, jlong ptrs)
{
	return (jlong)(((resultset*)ptrs)->getNextKeyLong());
}

JNIEXPORT jbyteArray JNICALL Java_bangdb_ResultSetImpl_GetNextVal (JNIEnv *env, jobject obj, jlong ptrs)
{
	resultset *rs = (resultset*)ptrs;
	FDT *v = rs->getNextVal();
	jbyteArray retv = env->NewByteArray(v->length);
	env->SetByteArrayRegion(retv, 0, v->length, (const jbyte*)v->data);
	return retv;
	//don't delete the v as user may again want to look at it
	//only Clear() would free all the memory related to resultset
}

JNIEXPORT jstring JNICALL Java_bangdb_ResultSetImpl_getNextValStr
  (JNIEnv *env, jobject obj, jlong ptrs)
{
	return env->NewStringUTF(((resultset*)ptrs)->getNextValStr());
}

JNIEXPORT jlong JNICALL Java_bangdb_ResultSetImpl_GetNextValLong (JNIEnv *env, jobject obj, jlong ptrs)
{
	return (jlong)(((resultset*)ptrs)->getNextValLong());
}

JNIEXPORT jstring JNICALL Java_bangdb_ResultSetImpl_getNextKeyStr
  (JNIEnv *env, jobject obj, jlong ptrs)
{
	return env->NewStringUTF(((resultset*)ptrs)->getNextKeyStr());
}

JNIEXPORT jboolean JNICALL Java_bangdb_ResultSetImpl_HasNext (JNIEnv *env, jobject obj, jlong ptrs)
{
	return ((resultset*)ptrs)->hasNext();
}

JNIEXPORT void JNICALL Java_bangdb_ResultSetImpl_MoveNext (JNIEnv *env, jobject obj, jlong ptrs)
{
	((resultset*)ptrs)->moveNext();
}

JNIEXPORT jint JNICALL Java_bangdb_ResultSetImpl_Size (JNIEnv *env, jobject obj, jlong ptrs)
{
	return ((resultset*)ptrs)->count();
}

JNIEXPORT void JNICALL Java_bangdb_ResultSetImpl_Begin (JNIEnv *env, jobject obj, jlong ptrs)
{
	((resultset*)ptrs)->begin();
}

JNIEXPORT void JNICALL Java_bangdb_ResultSetImpl_beginReverse
  (JNIEnv *env, jobject obj, jlong ptrs)
{
	((resultset*)ptrs)->begin_reverse();
}

JNIEXPORT void JNICALL Java_bangdb_ResultSetImpl_Clear (JNIEnv *env, jobject obj, jlong ptrs)
{
	resultset *rs = (resultset*)ptrs;
	rs->clear();
	delete rs;
}

JNIEXPORT jboolean JNICALL Java_bangdb_ResultSetImpl_MoreDataToCome
  (JNIEnv *env, jobject obj, jlong ptrs)
{
	return ((resultset*)ptrs)->moreDataToCome();
}

JNIEXPORT jbyteArray JNICALL Java_bangdb_ResultSetImpl_LastEvaluatedKey
  (JNIEnv *env, jobject obj, jlong ptrs)
{
	resultset *rs = (resultset*)ptrs;
	FDT *k = rs->lastEvaluatedKey();
	if(k)
	{
		jbyteArray retv = env->NewByteArray(k->length);
		env->SetByteArrayRegion(retv, 0, k->length, (const jbyte*)k->data);
		k->free();
		delete k;
		return  retv;	
	}
	return NULL;
}

JNIEXPORT jlong JNICALL Java_bangdb_ResultSetImpl_LastEvaluatedKeyLong
  (JNIEnv *env, jobject obj, jlong ptrs)
{
	return (jlong)(((resultset*)ptrs)->lastEvaluatedKeyLong());
}

JNIEXPORT jbyteArray JNICALL Java_bangdb_ResultSetImpl_SearchValue__JLjava_lang_String_2
  (JNIEnv *env, jobject obj, jlong ptrs, jstring key)
{
	resultset *rs = (resultset*)ptrs;
	jboolean iscopy;
	const char* _key = env->GetStringUTFChars(key, &iscopy);
	FDT *k = new FDT((void*)_key, strlen(_key));
	FDT *v = rs->searchVal(k);
	jbyteArray retv = NULL;
	if(v)
	{
		retv = env->NewByteArray(v->length);
		env->SetByteArrayRegion(retv, 0, v->length, (const jbyte*)v->data);
	}
	env->ReleaseStringUTFChars(key, _key);
	delete k;
	return retv;
}

JNIEXPORT jbyteArray JNICALL Java_bangdb_ResultSetImpl_SearchValue__J_3B
  (JNIEnv *env, jobject obj, jlong ptrs, jbyteArray key)
{
	resultset *rs = (resultset*)ptrs;
	jboolean iscopy;
	void *_key = env->GetByteArrayElements(key, &iscopy);
	jint klen = env->GetArrayLength(key);
	FDT *k = new FDT((void*)_key, klen);
	FDT *v = rs->searchVal(k);
	jbyteArray retv = NULL;
	if(v)
	{
		retv = env->NewByteArray(v->length);
		env->SetByteArrayRegion(retv, 0, v->length, (const jbyte*)v->data);
	}
	env->ReleaseByteArrayElements(key, (jbyte*)_key, 0);
	delete k;
	return retv;
}

JNIEXPORT void JNICALL Java_bangdb_ResultSetImpl_addDoc
  (JNIEnv *env, jobject obj, jlong prs1, jstring orderBy, jlong ptrs)
{
	jboolean iscopy;
	const char* _orderBy = NULL;
	if(orderBy)
		_orderBy = env->GetStringUTFChars(orderBy, &iscopy);
	resultset *rs1 = (resultset*)prs1;
	resultset *rs = (resultset*)ptrs;
	rs->add_doc(rs1, (char*)_orderBy);
	if(_orderBy)
		env->ReleaseStringUTFChars(orderBy, _orderBy);
}

JNIEXPORT void JNICALL Java_bangdb_ResultSetImpl_add
  (JNIEnv *env, jobject obj, jlong prs1, jlong ptrs)
{
	((resultset*)ptrs)->add((resultset*)prs1);
}

JNIEXPORT void JNICALL Java_bangdb_ResultSetImpl_append
  (JNIEnv *env, jobject obj, jlong prs1, jlong ptrs)
{
	((resultset*)ptrs)->append((resultset*)prs1);
}

JNIEXPORT void JNICALL Java_bangdb_ResultSetImpl_intersect
  (JNIEnv *env, jobject obj, jlong prs1, jlong ptrs)
{
	((resultset*)ptrs)->intersect((resultset*)prs1);
}

JNIEXPORT jint JNICALL Java_bangdb_ResultSetImpl_data_1size
  (JNIEnv *env, jobject obj, jlong ptrs)
{
	return ((resultset*)ptrs)->size();
}
