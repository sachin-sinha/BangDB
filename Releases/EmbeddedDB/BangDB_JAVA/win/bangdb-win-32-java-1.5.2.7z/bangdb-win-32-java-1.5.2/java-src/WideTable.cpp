#include "database.h"
#include "bangdb_WideTableImpl.h"
#include "wideTable.h"
#include "wideConnection.h"
#include "iostream"
using namespace std;
using namespace bangdb;

JNIEXPORT jint JNICALL Java_bangdb_WideTableImpl_addIndex_1str
  (JNIEnv *env, jobject obj, jstring idxName, jint idxSize, jboolean allowDuplicates, jlong pttb)
{
	jboolean iscopy;
	wideTable *tb = (wideTable *) pttb;
	const char *idx_name = env->GetStringUTFChars(idxName, &iscopy);
	jint r = tb->addIndex_str((char*)idx_name, (int)idxSize, (bool)allowDuplicates);
	env->ReleaseStringUTFChars(idxName, idx_name);
	return r;
}

JNIEXPORT jint JNICALL Java_bangdb_WideTableImpl_addIndex_1num
  (JNIEnv *env, jobject obj, jstring idxName, jboolean allowDuplicates, jlong pttb)
{
	jboolean iscopy;
	wideTable *tb = (wideTable *) pttb;
	const char *idx_name = env->GetStringUTFChars(idxName, &iscopy);
	jint r = tb->addIndex_num((char*)idx_name, (bool)allowDuplicates);
	env->ReleaseStringUTFChars(idxName, idx_name);
	return r;
}

JNIEXPORT jint JNICALL Java_bangdb_WideTableImpl_addIndex
  (JNIEnv *env, jobject obj, jstring idxName, jobject tenv, jlong pttb)
{
	table_env te;
	if(tenv != NULL)
	{
		jclass envcls = env->GetObjectClass(tenv);
		jmethodID mid_thint = env->GetMethodID(envcls, "getTableSizeHintOrdinal", "()S");
		jmethodID mid_dbt = env->GetMethodID(envcls, "getDBTypeOrdinal", "()S");
		jmethodID mid_idxt = env->GetMethodID(envcls, "getIndexTypeOrdinal", "()S");
		jmethodID mid_ksz = env->GetMethodID(envcls, "getKeySizeByte", "()S");
		jmethodID mid_logtp = env->GetMethodID(envcls, "getLogTypeOrdinal", "()S");
		jmethodID mid_lsz = env->GetMethodID(envcls, "getLogSizeMB", "()S");
		jmethodID mid_lst = env->GetMethodID(envcls, "getLogStateOrdinal", "()S");
		jmethodID mid_acm = env->GetMethodID(envcls, "getAutocommitStateOrdinal", "()S");
		jmethodID mid_tbltp = env->GetMethodID(envcls, "getTableTypeOrdinal", "()S");
		jmethodID mid_keytp = env->GetMethodID(envcls, "getKeyTypeOrdinal", "()S");
		jmethodID mid_sortm = env->GetMethodID(envcls, "getSortMethodOrdinal", "()S");
		jmethodID mid_sortd = env->GetMethodID(envcls, "getSortDirectionOrdinal", "()S");
		jmethodID mid_adup = env->GetMethodID(envcls, "getAllowDuplicatesOrdinal", "()S");

		if(mid_thint == 0 || mid_dbt == 0 || mid_idxt == 0 || mid_ksz == 0 || mid_lsz == 0 || mid_lst == 0 || mid_acm == 0
			|| mid_tbltp == 0 || mid_keytp == 0 || mid_sortm == 0 || mid_sortd == 0 || mid_logtp == 0 || mid_adup == 0)		
			return -1;

		jshort thint = env->CallShortMethod(tenv, mid_thint);
		jshort dbt = env->CallShortMethod(tenv, mid_dbt);
		jshort idxt = env->CallShortMethod(tenv, mid_idxt);
		jshort ksz = env->CallShortMethod(tenv, mid_ksz);
		jshort logtp = env->CallShortMethod(tenv, mid_logtp);
		jshort lsz = env->CallShortMethod(tenv, mid_lsz);
		jshort lst = env->CallShortMethod(tenv, mid_lst);
		jshort acm = env->CallShortMethod(tenv, mid_acm);	
		jshort tbltp = env->CallShortMethod(tenv, mid_tbltp);	
		jshort keytp = env->CallShortMethod(tenv, mid_keytp);	
		jshort sortm = env->CallShortMethod(tenv, mid_sortm);	
		jshort sortd = env->CallShortMethod(tenv, mid_sortd);	
		jshort adup = env->CallShortMethod(tenv, mid_adup);

		te.set_table_size_hint(thint);
		if(dbt != -1)
			te.set_persist_type(dbt);
		if(idxt != -1)
			te.set_idx_type(idxt);
		if(ksz != -1)
			te.set_key_size_byte(ksz);
		if(logtp != -1)
			te.set_log_type(logtp);
		if(lsz != -1)
			te.set_log_size_mb(lsz);
		if(lst != -1)
			te.set_log_state(lst);
		if(acm != -1)
			te.set_autocommit_state(acm);
		if(tbltp != -1)
			te.set_table_type(tbltp);
		if(keytp != -1)
			te.set_key_type(keytp);
		if(sortm != -1)
			te.set_sort_method(sortm);
		if(sortd != -1)
			te.set_sort_dirction(sortd);
		if(adup != -1)
			te.set_allow_duplicate(adup);
		te.set_config_vars();
	}

	jboolean iscopy;
	wideTable *tb = (wideTable *) pttb;
	const char *idx_name = env->GetStringUTFChars(idxName, &iscopy);
	jint r = tb->addIndex_num((char*)idx_name, &te);
	env->ReleaseStringUTFChars(idxName, idx_name);
	return r;
}

JNIEXPORT jint JNICALL Java_bangdb_WideTableImpl_dropIndex
  (JNIEnv *env, jobject obj, jstring idxName, jlong pttb)
{
	jboolean iscopy;
	wideTable *tb = (wideTable *) pttb;
	const char *idx_name = env->GetStringUTFChars(idxName, &iscopy);
	jint r = tb->dropIndex((char*)idx_name);
	env->ReleaseStringUTFChars(idxName, idx_name);
	return r;
}

JNIEXPORT jint JNICALL Java_bangdb_WideTableImpl_closeAllConnections
  (JNIEnv *env, jobject obj, jlong pttb)
{
	return ((wideTable *)pttb)->closeAllConnections();
}

JNIEXPORT jlong JNICALL Java_bangdb_WideTableImpl_init (JNIEnv *env, jobject obj, jstring rname, jshort openflg, jobject tenv) 
{
/*
    jboolean iscopy;
    const char *r_name = env->GetStringUTFChars(rname, &iscopy);
    wideTable *tb = new wideTable((char*)r_name, (SHORT_T) openflg, NULL, NULL);
    env->ReleaseStringUTFChars(rname,  r_name);
    jlong pttb = (jlong) tb;
    return pttb;
  */
	return -1;  
}

JNIEXPORT jstring JNICALL Java_bangdb_WideTableImpl_getname(JNIEnv *env, jobject, jlong pttb)
{
       wideTable *tb = (wideTable *) pttb;
       char *tbname = tb->getname();
       jstring tablebname = env->NewStringUTF(tbname);
       return tablebname;
}

JNIEXPORT jobject JNICALL Java_bangdb_WideTableImpl_getconnection (JNIEnv *env, jobject obj, jlong pttb)
{
    wideTable *tbl =(wideTable *) pttb;
    wideConnection *conn = tbl->getconnection();
    jclass connClass = env->FindClass("bangdb/WideConnectionImpl");
    jmethodID midConstructor = env->GetMethodID(connClass, "<init>", "(J)V");
    jobject connObject = env->NewObject(connClass, midConstructor, (jlong)conn);
    return connObject;
}
/*
JNIEXPORT jint JNICALL Java_bangdb_WideTableImpl_closeconnection (JNIEnv *env, jobject obj, jobject connobj, jlong pttb)
{
    wideTable *tb =(wideTable *) pttb;
    jclass cl = env->GetObjectClass(connobj);
    jfieldID fld = env->GetFieldID(cl, "ptwconn", "J");
    jlong ptconn = env->GetLongField(connobj, fld);
    connection *conn = (connection *) ptconn;
    jint ret = (jint) tb->closeconnection(conn);
    delete conn;
    return ret;
}
*/
JNIEXPORT void JNICALL Java_bangdb_WideTableImpl_dumpdata (JNIEnv *env, jobject obj, jlong pttb)
{
    wideTable *tb =(wideTable *) pttb;    
    tb->dumpdata();
}

JNIEXPORT jint JNICALL Java_bangdb_WideTableImpl_getindextype (JNIEnv *env, jobject obj, jlong pttb)
{
    wideTable *tb =(wideTable *) pttb; 
    return (jint) tb->getindextype();
}

JNIEXPORT void JNICALL Java_bangdb_WideTableImpl_printstats (JNIEnv *env, jobject obj, jlong pttb)
{
/*
   wideTable *tb =(wideTable *) pttb;
   tb->printstats();
*/
}

JNIEXPORT jint JNICALL Java_bangdb_WideTableImpl_closetable (JNIEnv *env, jobject obj, jlong pttb, jshort tableclose)
{
    wideTable *tb =(wideTable *) pttb;
    jint ret = (jint) tb->closetable((bangdb_close_type)tableclose); 
    delete tb;
    return ret; 
}

JNIEXPORT jint JNICALL Java_bangdb_WideTableImpl_simple_1close (JNIEnv *env, jobject obj, jlong pttb)
{
	return 0;
/*
    wideTable *tb =(wideTable *) pttb;
    return (jint) tb->simple_close();
*/
} 
