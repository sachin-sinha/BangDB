/*
 * bangdbtxn.cpp
 *
 *  Created on: 14-Oct-2014
 *      Author: sachin
 */

#include "bangdbtxn.h"
namespace bangdb
{
bangdb_txn::bangdb_txn()
{
	txn = GetNewTransaction();
}

bangdb_txn::~bangdb_txn()
{
	if(!txn)
		return;
	if(IsTransactionActive(txn))
		BangDB_Logger("The transaction was not committed or aborted before deleting the transaction");
	FreeHandle(&txn);
	txn = NULL;
}

bool bangdb_txn::is_active()
{
	return IsTransactionActive(txn) > 0 ? true : false;
}
}