/*
 * primConnection.h
 *
 *  Created on: 30-Jul-2014
 *      Author: sachin
 */

#ifndef PRIMCONNECTION_H_
#define PRIMCONNECTION_H_

#include "connection.h"
namespace bangdb
{
class connection;
class bangdb_txn;

class primConnection {
public:
	primConnection(HANDLE _conn);

	int get(LONG_T key, LONG_T *val);

	int get(int key, int *val);

	int get(FDT *key, LONG_T *val);

	int get(const char *key, LONG_T *val);

	FILEOFF_T put(LONG_T key, LONG_T val, insert_options flag);

	FILEOFF_T put(int key, int val, insert_options flag);

	FILEOFF_T put(const char *key, LONG_T val, insert_options flag);

	FILEOFF_T put(FDT *key, LONG_T val, insert_options flag);

	FILEOFF_T del(const char *key);

	FILEOFF_T del(FDT *key);

	FILEOFF_T del(LONG_T key);

	FILEOFF_T del(int key);

	resultset* scan(const char *skey, const char *ekey, scan_filter *sf = NULL);

	resultset* scan(FDT *skey, FDT *ekey, scan_filter *sf = NULL);

	resultset* scan(LONG_T skey, LONG_T ekey, scan_filter *sf = NULL);

	resultset* scan(int skey, int ekey, scan_filter *sf = NULL);

	LONG_T count(const char *skey, const char *ekey, scan_filter *sf = NULL);

	LONG_T count(FDT *skey, FDT *ekey, scan_filter *sf = NULL);

	LONG_T count();

	LONG_T count(LONG_T skey, LONG_T ekey, scan_filter *sf = NULL);

	LONG_T count(int skey, int ekey, scan_filter *sf = NULL);

	void set_autocommit(bool flag);

	SHORT_T getdbtype();

	SHORT_T getidxtype();

	int closeconnection();

	virtual ~primConnection();

private:
	HANDLE conn;
};
}
#endif /* PRIMCONNECTION_H_ */
