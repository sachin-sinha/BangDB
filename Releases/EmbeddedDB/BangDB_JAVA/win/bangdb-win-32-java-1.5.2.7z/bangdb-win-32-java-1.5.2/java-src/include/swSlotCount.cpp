#include "swSlotCount.h"
namespace bangdb
{
swSlotCount::swSlotCount(int swTime, int swExpiry, bangdb_count_type countType)
{
	_swsc = CreateSWCount(swTime, swExpiry, countType, SLIDING_WINDOW_UNIT);
}

void swSlotCount::add(char *s, int len)
{
	AddSWCount(_swsc, s, len, SLIDING_WINDOW_UNIT);
}

int swSlotCount::list(int span, int **count_list, int *size)
{
	return ListSWCount(_swsc, span, count_list, size, SLIDING_WINDOW_UNIT);
}

int swSlotCount::count()
{
	return CountSWCount(_swsc, SLIDING_WINDOW_UNIT);
}

int swSlotCount::count(int span)
{
	return CountSpanSWCount(_swsc, span, SLIDING_WINDOW_UNIT);
}

void swSlotCount::foldSlots()
{
	FoldSlotsSWCount(_swsc, SLIDING_WINDOW_UNIT);
}

void swSlotCount::reset()
{
	ResetSWCount(_swsc, SLIDING_WINDOW_UNIT);
}

void swSlotCount::Close()
{
	CloseSWCount(_swsc, SLIDING_WINDOW_UNIT);
	FreeHandle(&_swsc);
}

swSlotCount::~swSlotCount()
{

}
}