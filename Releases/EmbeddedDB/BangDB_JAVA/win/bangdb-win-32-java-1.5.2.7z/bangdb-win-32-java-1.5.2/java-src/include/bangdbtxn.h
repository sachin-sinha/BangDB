/*
 * bangdbtxn.h
 *
 *  Created on: 14-Oct-2014
 *      Author: sachin
 */

#ifndef BANGDBTXN_H_
#define BANGDBTXN_H_

#include "database.h"

namespace bangdb
{

class database;
class connection;
class wideConnection;
class primConnection;

class bangdb_txn {
public:
	bangdb_txn();
	bool is_active();
	virtual ~bangdb_txn();
private:
	HANDLE txn;
	friend class database;
	friend class connection;
	friend class wideConnection;
	friend class primConnection;
};
}
#endif /* BANGDBTXN_H_ */
