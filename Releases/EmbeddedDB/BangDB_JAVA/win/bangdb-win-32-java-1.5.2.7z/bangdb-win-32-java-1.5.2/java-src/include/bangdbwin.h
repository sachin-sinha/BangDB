// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the BANGDBWIN_EXPORTS
// symbol defined on the command line. This symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// BANGDBWIN_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef BANGDBWIN_EXPORTS
#define BANGDBWIN_API __declspec(dllexport)
#else
#define BANGDBWIN_API __declspec(dllimport)
#endif

#ifndef NULL
#define NULL 0
#endif

typedef void* HANDLE;
extern "C"
{	
//table_env
BANGDBWIN_API HANDLE GetTableEnv();
BANGDBWIN_API void ResetTableEnv(HANDLE tenv);
BANGDBWIN_API void Set_persist_type(HANDLE tenv, int persist_type);
BANGDBWIN_API void Set_idx_type(HANDLE tenv, int BTREE_EXTHASH);
BANGDBWIN_API void Set_table_type(HANDLE tenv, int _table_type);
BANGDBWIN_API void Set_key_size_byte(HANDLE tenv, int key_size);
BANGDBWIN_API void Set_log_size_mb(HANDLE tenv, int log_size_mb);
BANGDBWIN_API void Set_table_size_hint(HANDLE tenv, int TINY_SMALL_NORMAL_BIG);
BANGDBWIN_API void Set_log_state(HANDLE tenv, int is_log_on);
BANGDBWIN_API void Set_log_type(HANDLE tenv, int log_type);
BANGDBWIN_API void Set_autocommit_state(HANDLE tenv, int is_autocommit_on);
BANGDBWIN_API void Set_sort_method(HANDLE tenv, int sort_method);
BANGDBWIN_API void Set_sort_dirction(HANDLE tenv, int sort_direction);
BANGDBWIN_API void Set_key_type(HANDLE tenv, int key_type);
BANGDBWIN_API void Set_primitive_data_type(HANDLE tenv, int data_type);
BANGDBWIN_API void Set_table_subtype(HANDLE tenv, int sub_type);
BANGDBWIN_API void Set_allow_duplicate(HANDLE tenv, int allowDuplicate);
BANGDBWIN_API void Set_config_vars(HANDLE tenv);
BANGDBWIN_API int Get_persist_type(HANDLE tenv);
BANGDBWIN_API int Get_idx_type(HANDLE tenv);
BANGDBWIN_API int Get_table_type(HANDLE tenv);
BANGDBWIN_API int Get_key_size_byte(HANDLE tenv);
BANGDBWIN_API int Get_log_size_mb(HANDLE tenv);
BANGDBWIN_API int Get_table_size_hint(HANDLE tenv);
BANGDBWIN_API int Get_log_type(HANDLE tenv);
BANGDBWIN_API int Get_log_state(HANDLE tenv);
BANGDBWIN_API int Get_autocommit_state(HANDLE tenv);
BANGDBWIN_API int Get_sort_method(HANDLE tenv);
BANGDBWIN_API int Get_sort_direction(HANDLE tenv);
BANGDBWIN_API int Get_key_type(HANDLE tenv);
BANGDBWIN_API int Get_sort_id(HANDLE tenv);
BANGDBWIN_API int Get_primitive_data_type(HANDLE tenv);
BANGDBWIN_API int Get_table_subtype(HANDLE tenv);
BANGDBWIN_API int Get_allow_duplicate(HANDLE tenv);

//db method
BANGDBWIN_API HANDLE GetDatabase(char *db_name, char *configpath = NULL, int transaction_type = 0, char *dbpath = NULL, char *logPath = NULL);
BANGDBWIN_API HANDLE GetTable(HANDLE db, char *tbl_name, int flag, HANDLE tenv);
BANGDBWIN_API HANDLE GetWideTable(HANDLE db, char *tbl_name, int flag, HANDLE tenv);
BANGDBWIN_API HANDLE GetPrimitiveTable(HANDLE db, char *tbl_name, int primitive_data_type, int flag, HANDLE tenv);
BANGDBWIN_API int	 CloseTable(HANDLE db, char *tbl_name, int flag);
BANGDBWIN_API int	 CloseTableHandle(HANDLE db, HANDLE tbl, int flag);
BANGDBWIN_API int	 CloseWideTableHandle(HANDLE db, HANDLE widetbl, int flag);
BANGDBWIN_API void	 CloseDatabase(HANDLE db, int flag);
BANGDBWIN_API void	 CleanUp(HANDLE db);
BANGDBWIN_API HANDLE	 GetDBName(HANDLE db);

//txn API
BANGDBWIN_API HANDLE GetNewTransaction();
BANGDBWIN_API void Begin_Transaction(HANDLE db, HANDLE txn);
BANGDBWIN_API long long Commit_Transaction(HANDLE db, HANDLE txn);
BANGDBWIN_API void Abort_Transaction(HANDLE db, HANDLE txn);
BANGDBWIN_API int IsTransactionActive(HANDLE txn);

//table method (for table and primitivetable)
BANGDBWIN_API HANDLE GetConnection(HANDLE tbl);
BANGDBWIN_API HANDLE GetPrimConnection(HANDLE tbl);
BANGDBWIN_API int	 DumpData(HANDLE tbl);
BANGDBWIN_API char*  GetTableName(HANDLE tbl);
BANGDBWIN_API int	 CloseThisTable(HANDLE tbl, int flag);
BANGDBWIN_API int	 GetTablePersistType(HANDLE tbl);
BANGDBWIN_API int	 GetTableType(HANDLE tbl);
BANGDBWIN_API int	 GetIndexType(HANDLE tbl);
BANGDBWIN_API int	 CloseTableConnection(HANDLE tbl, HANDLE conn);

//wide table method (for wide table)
BANGDBWIN_API HANDLE GetWideConnection(HANDLE wtbl);
BANGDBWIN_API int	 WideDumpData(HANDLE wtbl);
BANGDBWIN_API char*  GetWideTableName(HANDLE wtbl);
BANGDBWIN_API int	 CloseThisWideTable(HANDLE wtbl, int flag);
BANGDBWIN_API int	 GetWideIndexType(HANDLE wtbl);
BANGDBWIN_API int	 AddIndex(HANDLE wtbl, char *idxName, HANDLE tenv);
BANGDBWIN_API int	 AddIndex_Str(HANDLE wtbl, char *idxName, int idxSize, int allowDuplicates);
BANGDBWIN_API int	 AddIndex_Num(HANDLE wtbl, char *idxName, int allowDuplicates);
BANGDBWIN_API int	 DropIndex(HANDLE wtbl, char *idxName);
BANGDBWIN_API int    CloseAllWideConnections(HANDLE wtbl);

//DataVar methods
BANGDBWIN_API HANDLE GetDataVar();
BANGDBWIN_API HANDLE GetDataVarOfSize(int size);
BANGDBWIN_API int GetDataVarBufLen(HANDLE dv);
BANGDBWIN_API void SetDataVarBufLen(HANDLE dv, int len);
BANGDBWIN_API int GetDataVarDataLen(HANDLE dv);
BANGDBWIN_API void SetDataVarDataLen(HANDLE dv, int len);
BANGDBWIN_API int GetDataVarOffset(HANDLE dv);
BANGDBWIN_API void SetDataVarOffset(HANDLE dv, int offt);
BANGDBWIN_API int GetDataVarFlag(HANDLE dv);
BANGDBWIN_API void SetDataVarFlag(HANDLE dv, int flag);
BANGDBWIN_API void ReadDataVarBuf(HANDLE dv, int len, HANDLE *rbuf, int *rbuflen);
BANGDBWIN_API void ReadDataVarData(HANDLE dv, int len, HANDLE *rdata, int *rdatalen);
BANGDBWIN_API void WriteDataVarBuf(HANDLE dv, HANDLE wbuf, int wbuflen);
BANGDBWIN_API void FreeDataVar(HANDLE dv);

//connection method
BANGDBWIN_API int	 Get(HANDLE conn, HANDLE key, int klen, HANDLE *oval, int *ovlen);
BANGDBWIN_API int	 GetAdvanced(HANDLE conn, char *key, int klen, HANDLE *dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag);
BANGDBWIN_API long long	 Put(HANDLE conn, HANDLE key, int klen, HANDLE val, int vlen, int insertOption);
BANGDBWIN_API long long	 PutAdvanced(HANDLE conn, char *key, int keylen, HANDLE dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag, int insertOption);
BANGDBWIN_API long long	 PutByte_Long(HANDLE conn, long long key, HANDLE val, int vallen, int insertOption);
BANGDBWIN_API long long	 Del(HANDLE conn, HANDLE key, int klen);
BANGDBWIN_API long long	 Del_Long(HANDLE conn, long long key);
BANGDBWIN_API HANDLE Scan(HANDLE conn, HANDLE skey, int sklen, HANDLE ekey, int eklen, HANDLE sf);
BANGDBWIN_API HANDLE Scan_Long(HANDLE conn, long long skey, long long ekey, HANDLE sf);
BANGDBWIN_API long long Count(HANDLE conn, HANDLE skey, int sklen, HANDLE ekey, int eklen, HANDLE sf);
BANGDBWIN_API long long Count_LONG(HANDLE conn, long long skey, long long ekey, HANDLE sf);
BANGDBWIN_API int	 Get_Tran(HANDLE conn, HANDLE key, int klen, HANDLE *oval, int *ovlen, HANDLE txn);
BANGDBWIN_API long long	 Put_Tran(HANDLE conn, HANDLE key, int klen, HANDLE val, int vlen, int insertOption, HANDLE txn);
BANGDBWIN_API long long	 PutAdvanced_Tran(HANDLE conn, char *key, int keylen, HANDLE dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag, int insertOption, HANDLE txn);
BANGDBWIN_API long long	 Del_Tran(HANDLE conn, HANDLE key, int klen, HANDLE txn);
BANGDBWIN_API HANDLE Scan_Tran(HANDLE conn, HANDLE skey, int sklen, HANDLE ekey, int eklen, HANDLE txn, HANDLE sf);
BANGDBWIN_API void SetAutoCommit(HANDLE conn, int flag);
BANGDBWIN_API int	 GetPersistType(HANDLE conn);
BANGDBWIN_API int	 GetIdxType(HANDLE conn);
BANGDBWIN_API int	 CloseConnection(HANDLE conn);
//added new APIs in 1.5.2
BANGDBWIN_API long long CountAll(HANDLE conn);
BANGDBWIN_API int	 GetAdvancedTran(HANDLE conn, char *key, int klen, HANDLE *dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag, HANDLE txn);
BANGDBWIN_API int	 Del_Long_Tran(HANDLE conn, long long key, HANDLE txn);
BANGDBWIN_API HANDLE Scan_Long_Tran(HANDLE conn, long long skey, long long ekey, HANDLE txn, HANDLE sf);
BANGDBWIN_API int	 GetAdvancedLong(HANDLE conn, long long key, HANDLE *dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag);
BANGDBWIN_API int	 GetAdvancedLongTran(HANDLE conn, long long key, HANDLE *dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag, HANDLE txn);
BANGDBWIN_API long long	 PutByte_Long_Tran(HANDLE conn, long long key, HANDLE val, int vallen, int insertOption, HANDLE txn);
BANGDBWIN_API int	 Get_Long_Str(HANDLE conn, long long key, HANDLE *val, int *vallen);
BANGDBWIN_API HANDLE Scan_DV(HANDLE conn, HANDLE skey, int sklen, HANDLE ekey, int eklen, HANDLE sf, HANDLE dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag);
BANGDBWIN_API HANDLE Scan_DV_Tran(HANDLE conn, HANDLE skey, int sklen, HANDLE ekey, int eklen, HANDLE txn, HANDLE sf, HANDLE dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag);
BANGDBWIN_API HANDLE Scan_DV_Long(HANDLE conn, long long skey, long long ekey, HANDLE sf, HANDLE dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag);
BANGDBWIN_API HANDLE Scan_DV_Long_Tran(HANDLE conn, long long skey, long long ekey, HANDLE txn, HANDLE sf, HANDLE dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag);

//primConnection method
BANGDBWIN_API int	 GetPrim(HANDLE conn, long long key, long long *val);
BANGDBWIN_API int	 GetPrimInt(HANDLE conn, int key, int *val);
BANGDBWIN_API int	 GetPrim_Str(HANDLE conn, char *key, int keylen, long long *val);
BANGDBWIN_API int	 GetPrim_Byte(HANDLE conn, HANDLE key, int keylen, long long *val);
BANGDBWIN_API long long	 PutPrim(HANDLE conn, long long key, long long val, int insertOption);
BANGDBWIN_API long long	 PutPrim_Str(HANDLE conn, char *key, int klen, long long val, int insertOption);
BANGDBWIN_API long long	 PutPrim_Byte(HANDLE conn, HANDLE key, int klen, long long val, int insertOption);
BANGDBWIN_API long long	 DelPrim_Str(HANDLE conn, char *key, int keylen);
BANGDBWIN_API long long	 DelPrim_Byte(HANDLE conn, HANDLE key, int keylen);
BANGDBWIN_API long long	 DelPrim_Long(HANDLE conn, long long key);
BANGDBWIN_API HANDLE ScanPrim_Long(HANDLE conn, long long skey, long long ekey, HANDLE sf);
BANGDBWIN_API HANDLE ScanPrim_Str(HANDLE conn, char* skey, int skeylen, char *ekey, int ekeylen, HANDLE sf);
BANGDBWIN_API HANDLE ScanPrim_Byte(HANDLE conn, HANDLE skey, int skeylen, HANDLE ekey, int ekeylen, HANDLE sf);
BANGDBWIN_API long long CountPrim_Long(HANDLE conn, long long skey, long long ekey, HANDLE sf);
BANGDBWIN_API long long CountPrim_Str(HANDLE conn, char* skey, int skeylen, char *ekey, int ekeylen, HANDLE sf);
BANGDBWIN_API long long CountPrim_Byte(HANDLE conn, HANDLE skey, int skeylen, HANDLE ekey, int ekeylen, HANDLE sf);
BANGDBWIN_API long long CountPrim(HANDLE conn);
BANGDBWIN_API void SetAutoCommitPrim(HANDLE conn, int flag);
BANGDBWIN_API int	 GetPrimPersistType(HANDLE conn);
BANGDBWIN_API int	 GetPrimIdxType(HANDLE conn);
BANGDBWIN_API int	 ClosePrimConnection(HANDLE conn);

//wide connection method
BANGDBWIN_API int	 GetW(HANDLE wconn, char *key, int klen, HANDLE *oval, int *ovlen);
//BANGDBWIN_API int	 GetPrimW(HANDLE wconn, long long key, long long *val);
BANGDBWIN_API int	 Get_LongW(HANDLE wconn, long long key, HANDLE *val, int *vallen);
BANGDBWIN_API long long	 PutW(HANDLE wconn, HANDLE key, int klen, HANDLE val, int vlen, int insertOption);
BANGDBWIN_API long long	 Put_LongW(HANDLE wconn, long long key, HANDLE val, int vallen, int insertOption);
BANGDBWIN_API long long	 DelW(HANDLE wconn, HANDLE key, int klen);
BANGDBWIN_API long long	 Del_longW(HANDLE wconn, long long key);
BANGDBWIN_API HANDLE ScanW(HANDLE wconn, HANDLE skey, int sklen, HANDLE ekey, int eklen, HANDLE sf);
BANGDBWIN_API HANDLE Scan_TranW(HANDLE wconn, HANDLE skey, int sklen, HANDLE ekey, int eklen, HANDLE txn, HANDLE sf);
BANGDBWIN_API HANDLE Scan_LongW(HANDLE wconn, long long skey, long long ekey, HANDLE sf);
BANGDBWIN_API long long CountW(HANDLE wconn, HANDLE skey, int sklen, HANDLE ekey, int eklen, HANDLE sf);
BANGDBWIN_API long long Count_LongW(HANDLE wconn, long long skey, long long ekey, HANDLE sf);
BANGDBWIN_API long long Put_Doc(HANDLE wconn, char *json_str);
BANGDBWIN_API long long	 Put_Doc_Long(HANDLE wconn, long long key, char *json_str, int insertOption);
BANGDBWIN_API long long	 Put_Doc_Str(HANDLE wconn, char *key, char *json_str, int insertOption);
BANGDBWIN_API long long	 PutWIdx(HANDLE wconn, HANDLE key, int klen, HANDLE val, int vlen, char *idxName, HANDLE idxVal, int idxLen);
BANGDBWIN_API long long	 PutWIdxLong(HANDLE wconn, long long key, HANDLE val, int vlen, char *idxName, HANDLE idxVal, int idxLen);
BANGDBWIN_API HANDLE ScanWIdx(HANDLE wconn, char *idxName, HANDLE skey, int sklen, HANDLE ekey, int eklen, HANDLE sf);
BANGDBWIN_API HANDLE Scan_Doc_Idx(HANDLE wconn, char *idxName, char *skey, int sklen, char *ekey, int eklen, HANDLE sf);
BANGDBWIN_API HANDLE Scan_Doc_Idx_Long(HANDLE wconn, char *idxName, long long skey, long long ekey, HANDLE sf);

BANGDBWIN_API int	 Get_TranW(HANDLE wconn, HANDLE key, int klen, HANDLE *oval, int *ovlen, HANDLE txn);
BANGDBWIN_API long long	 Put_TranW(HANDLE wconn, HANDLE key, int klen, HANDLE val, int vlen, int insertOption, HANDLE txn);
BANGDBWIN_API long long	 Del_TranW(HANDLE wconn, HANDLE key, int klen, HANDLE txn);

BANGDBWIN_API void SetAutoCommitW(HANDLE wconn, int flag);
BANGDBWIN_API int	 GetPersistTypeW(HANDLE wconn);
BANGDBWIN_API int	 GetIdxTypeW(HANDLE wconn);
BANGDBWIN_API int	 CloseConnectionW(HANDLE wconn);

//new api 1.5.2
BANGDBWIN_API long long CountAllW(HANDLE wconn);
BANGDBWIN_API long long	 Put_Long_TranW(HANDLE wconn, long long key, HANDLE val, int vallen, int insertOption, HANDLE txn);
BANGDBWIN_API HANDLE Scan_Long_TranW(HANDLE wconn, long long skey, long long ekey, HANDLE txn, HANDLE sf);
BANGDBWIN_API long long	 Del_long_TranW(HANDLE wconn, long long key, HANDLE txn);
BANGDBWIN_API HANDLE Scan_DVW(HANDLE conn, HANDLE skey, int sklen, HANDLE ekey, int eklen, HANDLE sf, HANDLE dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag);
BANGDBWIN_API HANDLE Scan_DV_TranW(HANDLE conn, HANDLE skey, int sklen, HANDLE ekey, int eklen, HANDLE txn, HANDLE sf, HANDLE dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag);
BANGDBWIN_API HANDLE Scan_DV_LongW(HANDLE conn, long long skey, long long ekey, HANDLE sf, HANDLE dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag);
BANGDBWIN_API HANDLE Scan_DV_Long_TranW(HANDLE conn, long long skey, long long ekey, HANDLE txn, HANDLE sf, HANDLE dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag);
BANGDBWIN_API HANDLE Scan_Doc_Idx_Long_DV(HANDLE wconn, char *idxName, long long skey, long long ekey, HANDLE sf, HANDLE dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag);
BANGDBWIN_API HANDLE Scan_Doc_Idx_DV(HANDLE wconn, char *idxName, HANDLE skey, int sklen, HANDLE ekey, int eklen, HANDLE sf, HANDLE dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag);
BANGDBWIN_API HANDLE ScanWIdx_DV(HANDLE wconn, char *idxName, HANDLE skey, int sklen, HANDLE ekey, int eklen, HANDLE sf, HANDLE dat_buf, int dat_buf_len, int *dat_len, int dat_offt, int *errflag);
BANGDBWIN_API HANDLE GetMainConn(HANDLE wconn);

//resultset method (for scan)
BANGDBWIN_API int GetNextKey(HANDLE rs, HANDLE *key, int *keylen);
BANGDBWIN_API long long GetNextKeyLong(HANDLE rs);
BANGDBWIN_API int GetNextKeyStr(HANDLE rs, char **key);
BANGDBWIN_API int GetNextVal(HANDLE rs, HANDLE *val, int *vallen);
BANGDBWIN_API long long GetNextValLong(HANDLE rs);
BANGDBWIN_API int GetNextValStr(HANDLE rs, char **val);

BANGDBWIN_API void Add_Doc(HANDLE rs1, HANDLE rs2, char *OrderBy);
BANGDBWIN_API void Add(HANDLE rs1, HANDLE rs2);
BANGDBWIN_API void Append(HANDLE rs1, HANDLE rs2);
BANGDBWIN_API void Intersect(HANDLE rs1, HANDLE rs2);

BANGDBWIN_API void Begin(HANDLE rs);
BANGDBWIN_API void BeginReverse(HANDLE rs);
BANGDBWIN_API int HasNext(HANDLE rs);
BANGDBWIN_API void MoveNext(HANDLE rs);
BANGDBWIN_API int RSCount(HANDLE rs);
BANGDBWIN_API int Size(HANDLE rs);

BANGDBWIN_API void Clear(HANDLE rs);
BANGDBWIN_API void LastEvaluatedKey(HANDLE rs, HANDLE *k, int *klen);
BANGDBWIN_API long long LastEvaluatedKeyLong(HANDLE rs);
BANGDBWIN_API int MoreDataToCome(HANDLE rs);
BANGDBWIN_API void SearchValue(HANDLE rs, HANDLE k, int klen, HANDLE *v, int *vlen);

BANGDBWIN_API int RSDataSize(HANDLE rs);

//topk
BANGDBWIN_API HANDLE CreateTopk(char *topkName, int swSizeSec, int k, int desc, char *uniqueBy);
BANGDBWIN_API void	 Put_topk(HANDLE tk, long score, char *data, int datalen, char *uniqueParam);
BANGDBWIN_API HANDLE GetTopk(HANDLE tk, int k = 0);
BANGDBWIN_API void	GetTopkJson(HANDLE tk, char **jstr, int k = 0);
BANGDBWIN_API void	CloseTopk(HANDLE tk);

//swTable
BANGDBWIN_API HANDLE CreateSWTable(HANDLE db, char *tableName, HANDLE tenv, int ttlsec, int archive);
BANGDBWIN_API void AddIndexSWTable(HANDLE swtbl, char *idxName, HANDLE tenv);
BANGDBWIN_API int InitSWTable(HANDLE swtbl);
BANGDBWIN_API HANDLE GetConnectionSWTable(HANDLE swtbl);
BANGDBWIN_API HANDLE GetActiveConnectionSWTable(HANDLE swtbl);
BANGDBWIN_API HANDLE GetPassiveConnectionSWTable(HANDLE swtbl);
BANGDBWIN_API int	 PutSWTable(HANDLE swtbl, char *str, int len, int insertOption);
BANGDBWIN_API int	 PutSWTableIdx(HANDLE swtbl, char *str, int len, char *idx, char *idxkey, int idxkeylen);
BANGDBWIN_API HANDLE ScanSWTable(HANDLE swtbl, int period);
BANGDBWIN_API HANDLE ScanLagSWTable(HANDLE swtbl, int period, int lag);
BANGDBWIN_API HANDLE ScanFullSWTable(HANDLE swtbl);
BANGDBWIN_API HANDLE ScanRemainingSWTable(HANDLE swtbl, long long from_time, int lag);
BANGDBWIN_API int	 GetTTLSWTable(HANDLE swtbl);
BANGDBWIN_API int	 NeedPassiveSWTable(HANDLE swtbl, int windowsec);
BANGDBWIN_API void	 CloseSWTable(HANDLE swtbl);

//swCount & swSlotCount
BANGDBWIN_API HANDLE CreateSWCount(int swTime, int swExpiry, int countType, int swtype);
BANGDBWIN_API void	 AddSWCount(HANDLE swcount, char *s, int len, int swtype);
BANGDBWIN_API int	 ListSWCount(HANDLE swcount, int span, int **count_list, int *size, int swtype);
BANGDBWIN_API int	 CountSWCount(HANDLE swcount, int swtype);
BANGDBWIN_API int	 CountSpanSWCount(HANDLE swcount, int span, int swtype);
BANGDBWIN_API void	 FoldSlotsSWCount(HANDLE swcount, int swtype);
BANGDBWIN_API void	 ResetSWCount(HANDLE swcount, int swtype);
BANGDBWIN_API void	 CloseSWCount(HANDLE swcount, int swtype);

//swEntityCount
BANGDBWIN_API HANDLE  CreateSWEntityCount(char *entityName, int swTime, int swExpiry, int nEntity);
BANGDBWIN_API int	  InitSWEntityCount(HANDLE swentity);
BANGDBWIN_API int	  AddSWEntity(HANDLE swentity, char *entityName, char *s, int len);
BANGDBWIN_API void	  AddCreateSWEntity(HANDLE swentoty, char *entityName, int enamelen, char *s, int len, int swType, int countType);
BANGDBWIN_API int	  CountSWEntity(HANDLE swentity, char *entityName);
BANGDBWIN_API int	  CountSpanEntity(HANDLE swentity, char *entityName, int span);
BANGDBWIN_API void	  ListCountSWEntity(HANDLE swentity, char **list);
BANGDBWIN_API void	  ListCount2SWEntity(HANDLE swentity, char **list);
BANGDBWIN_API void	  CreateEntitySW(HANDLE swentity, char *name, int namelen, int swType, int countType);
BANGDBWIN_API void	  RemoveEntitySW(HANDLE swentity, char *name);
BANGDBWIN_API int	  ShouldExitSWEntity(HANDLE swentity);
BANGDBWIN_API void	  ShutDownSWEntity(HANDLE swentity);

//swTableUnit
BANGDBWIN_API HANDLE CreateSWTableUnit(HANDLE db, char *tableName, HANDLE tenv, int ttlsec);
BANGDBWIN_API void AddIndexSWTableUnit(HANDLE _swtu, char *idxName, HANDLE tenv);
BANGDBWIN_API int CreateTableSWTableUnit(HANDLE _swtu);
BANGDBWIN_API HANDLE GetConnectionSWTanleUnit(HANDLE _swtu);
BANGDBWIN_API void CloseSWTableUnit(HANDLE _swtu, int flag);
BANGDBWIN_API unsigned long long GetCreateTimeStamp(HANDLE _swtu);
BANGDBWIN_API void StartSWTableUnit(HANDLE _swtu);
BANGDBWIN_API int HasExpiredSWTableUnit(HANDLE _swtu);
BANGDBWIN_API int ShouldSwitchSWTableUnit(HANDLE _swtu);
BANGDBWIN_API int IsStartedSWTableUnit(HANDLE _swtu);

//timestamp
BANGDBWIN_API unsigned long long GetCurrentTimeMicroSec();
BANGDBWIN_API unsigned long long GetCurrentTimeMilliSec();
BANGDBWIN_API unsigned long long UniqueTimeStampMicroSec();
BANGDBWIN_API unsigned long long UniqueTimeStampMilliSec();
BANGDBWIN_API unsigned long long GetCurTime();
BANGDBWIN_API unsigned long long SubTime(long nsec);
BANGDBWIN_API unsigned long long AddTime(long nsec);
BANGDBWIN_API unsigned long long UniqueTimeStamp();
BANGDBWIN_API unsigned long long ConvertTimeUnit(long nsec);
BANGDBWIN_API unsigned long long GetLagTime(unsigned long long from_time);

//composite
BANGDBWIN_API char *MakeComposite_long_long(unsigned long long k1, unsigned long long k2);
BANGDBWIN_API char *MakeComposite_str_str(char *k1, char *k2);
BANGDBWIN_API char *MakeComposite_str_str2(char *k1, int l1, char *k2, int l2);
BANGDBWIN_API char *MakeComposite_long_str(unsigned long long k1, char *k2);
BANGDBWIN_API char *MakeComposite_long_str2(unsigned long long k1, char *k2, int l2);
BANGDBWIN_API char *MakeComposite_str_long(char *k1, unsigned long long k2);
BANGDBWIN_API char *MakeComposite_str_long2(char *k1, int l1, unsigned long long k2);
BANGDBWIN_API char *MakeComposite(char *k, ...);

//Misc
BANGDBWIN_API long long	 KeyComp(char *k1, int l1, char *k2, int l2, int sortid);
BANGDBWIN_API void Bangdb_print_error(int errnum);
BANGDBWIN_API void Bangdb_print_last_error();
BANGDBWIN_API void	 FreeBytes(HANDLE val);
BANGDBWIN_API void   FreeHandle(HANDLE *h);
BANGDBWIN_API int	 TestPerf(int a, int b);
BANGDBWIN_API void	BangDB_Logger(const char *fmt, ...);
BANGDBWIN_API void BangDB_Logger_Init(const char *dbpath, const char *name, int log_mem_sz_mb, int log_type);
BANGDBWIN_API void BangDB_Logger_Close();
}