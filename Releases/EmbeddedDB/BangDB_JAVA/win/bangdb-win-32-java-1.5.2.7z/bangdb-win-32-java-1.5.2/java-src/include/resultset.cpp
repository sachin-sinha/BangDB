#include "resultset.h"
namespace bangdb
{
resultset::resultset(HANDLE rs)
{
	_rs = rs;
}

resultset::~resultset()
{
}

void resultset::add_doc(resultset *rs, char *orderBy)
{
	Add_Doc(_rs, rs->_rs, orderBy);
}

void resultset::add(resultset *rs)
{
	Add(_rs, rs->_rs);
}

void resultset::append(resultset *rs)
{
	Append(_rs, rs->_rs);
}

void resultset::intersect(resultset *rs)
{
	Intersect(_rs, rs->_rs);
}

FDT *resultset::getNextKey()
{
	void *k = NULL; int l;
	if(GetNextKey(_rs, &k, &l) < 0)
		return NULL;
	return new FDT(k, l);
}

int resultset::getNextKeyInt()
{
	return GetNextKeyLong(_rs);
}

LONG_T resultset::getNextKeyLong()
{
	return GetNextKeyLong(_rs);
}

char *resultset::getNextKeyStr()
{
	char *res = NULL;
	if(GetNextKeyStr(_rs, &res) < 0)
	{
		if(res)
			FreeBytes(res);
		return NULL;
	}
	return res;
}

FDT *resultset::getNextVal()
{
	void *v = NULL; int l;
	if(GetNextVal(_rs, &v, &l) < 0)
	{
		if(v)
			FreeBytes(v);
		return NULL;
	}
	return new FDT(v, l);
}

int resultset::getNextValInt()
{
	return GetNextValLong(_rs);
}

LONG_T resultset::getNextValLong()
{
	return GetNextValLong(_rs);
}

char *resultset::getNextValStr()
{
	char *res = NULL;
	if(GetNextValStr(_rs, &res) < 0)
	{
		if(res)
			FreeBytes(res);
		return NULL;
	}
	return res;
}

/*please ensure to set the key->length to actual allocated buffer length before calling the function*/
int resultset::getNextKey(FDT* key)
{
	void *v = NULL; int l;
	
	int ret = GetNextKey(_rs, &v, &l);
	if (ret == 0) {
		key->length = (key->length >= (unsigned int)l) ? l : key->length;
		memcpy(key->data, v, key->length);
	}

	return ret;
}

/*please ensure to set the data->length to actual allocated buffer length before calling the function*/
int resultset::getNextVal(FDT* data)
{
	void *v = NULL; int l;
	
	int ret = GetNextVal(_rs, &v, &l);
	if (ret == 0) {
		data->length = (data->length >= (unsigned int)l) ? l : data->length;
		memcpy(data->data, v, data->length);
	}

	return ret;
}

bool resultset::hasNext()
{
	return HasNext(_rs)?true:false;
}

void resultset::moveNext()
{
	MoveNext(_rs);
}

int resultset::size()
{
	return Size(_rs);
}

int resultset::dataSize()
{
	return RSDataSize(_rs);
}

void resultset::begin()
{
	Begin(_rs);
}

void resultset::begin_reverse()
{
	BeginReverse(_rs);
}

void resultset::clear()
{
	if(_rs != NULL)
		Clear(_rs);
	//delete _rs;
	FreeHandle(&_rs);
	_rs = NULL;
}

FDT *resultset::lastEvaluatedKey()
{
	void *k; int klen;
	LastEvaluatedKey(_rs, &k, &klen);

	if(k == NULL)
		return NULL;

	FDT *v = new FDT(k, klen);
	v->set_dll_alloc();
	return v;
}
LONG_T resultset::lastEvaluatedKeyLong()
{
	return LastEvaluatedKeyLong(_rs);
}
bool resultset::moreDataToCome()
{
	return MoreDataToCome(_rs)==1?true:false;
}

int resultset::count()
{
	return RSCount(_rs);
}

FDT *resultset::searchVal(FDT *key)
{
	void *data; int dlen = 0;
	SearchValue(_rs, key->data, key->length, &data, &dlen);
	if(data == NULL)
		return NULL;

	FDT *v = new FDT(data, dlen);
	v->set_dll_alloc();
	return v;
}
}