#include "primConnection.h"
namespace bangdb
{
primConnection::primConnection(HANDLE _conn)
{
	conn = _conn;
}

int primConnection::get(LONG_T key, LONG_T *val)
{
	return GetPrim(conn, key, val);
}

int primConnection::get(int key, int *val)
{
	LONG_T v;
	int rv = GetPrim(conn, key, &v);
	*val = v;
	return rv;
}

int primConnection::get(FDT *key, LONG_T *val)
{
	return GetPrim_Byte(conn, key->data, key->length, val);
}

int primConnection::get(const char *key, LONG_T *val)
{
	return GetPrim_Str(conn, (char*)key, strlen(key), val);
}

FILEOFF_T primConnection::put(LONG_T key, LONG_T val, insert_options flag)
{
	return PutPrim(conn, key, val, flag);
}

FILEOFF_T primConnection::put(int key, int val, insert_options flag)
{
	return PutPrim(conn, key, val, flag);
}

FILEOFF_T primConnection::put(const char *key, LONG_T val, insert_options flag)
{
	return PutPrim_Str(conn, (char*)key, strlen(key), val, flag);
}

FILEOFF_T primConnection::put(FDT *key, LONG_T val, insert_options flag)
{
	return PutPrim_Byte(conn, key->data, key->length, val, flag);
}

FILEOFF_T primConnection::del(const char *key)
{
	return DelPrim_Str(conn, (char*)key, strlen(key)); 
}

FILEOFF_T primConnection::del(FDT *key)
{
	return DelPrim_Byte(conn, key->data, key->length); 
}

FILEOFF_T primConnection::del(LONG_T key)
{
	return DelPrim_Long(conn, key);
}

FILEOFF_T primConnection::del(int key)
{
	return DelPrim_Long(conn, key);
}

resultset* primConnection::scan(const char *skey, const char *ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	int sklen = skey?(int)strlen(skey):0;
	int eklen = ekey?(int)strlen(ekey):0;
	HANDLE rs = ScanPrim_Str(conn, (char*)skey, sklen, (char*)ekey, eklen, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}

resultset* primConnection::scan(FDT *skey, FDT *ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	void *s = skey?skey->data:NULL;
	int slen = skey?skey->length:0;
	void *e = ekey?ekey->data:NULL;
	int elen = ekey?ekey->length:0;
	HANDLE rs = ScanPrim_Byte(conn, s, slen, e, elen, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}

resultset* primConnection::scan(LONG_T skey, LONG_T ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE rs = ScanPrim_Long(conn, skey, ekey, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}

resultset* primConnection::scan(int skey, int ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE rs = ScanPrim_Long(conn, skey, ekey, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}

LONG_T primConnection::count(const char *skey, const char *ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	int sklen = skey?(int)strlen(skey):0;
	int eklen = ekey?(int)strlen(ekey):0;
	return CountPrim_Str(conn, (char*)skey, sklen, (char*)ekey, eklen, (HANDLE)sf);
}

LONG_T primConnection::count(FDT *skey, FDT *ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	void *s = skey?skey->data:NULL;
	int slen = skey?skey->length:0;
	void *e = ekey?ekey->data:NULL;
	int elen = ekey?ekey->length:0;
	return CountPrim_Byte(conn, s, slen, e, elen, (HANDLE)sf);
}

LONG_T primConnection::count()
{
	return CountPrim(conn);
}

LONG_T primConnection::count(LONG_T skey, LONG_T ekey, scan_filter *sf)
{
	return CountPrim_Long(conn, skey, ekey, (HANDLE)sf);
}

LONG_T primConnection::count(int skey, int ekey, scan_filter *sf)
{
	return CountPrim_Long(conn, skey, ekey, (HANDLE)sf);
}

void primConnection::set_autocommit(bool flag)
{
	SetAutoCommitPrim(conn, flag ? 1 : 0);
}

SHORT_T primConnection::getdbtype()
{
	return (short)GetPrimPersistType(conn);
}

SHORT_T primConnection::getidxtype()
{
	return GetPrimIdxType(conn);
}

int primConnection::closeconnection()
{
	int rv = ClosePrimConnection(conn);
	FreeHandle(&conn);
	return rv;
}

primConnection::~primConnection()
{
}
}