#include "wideConnection.h"
namespace bangdb
{
wideConnection::wideConnection(HANDLE wconn)
{
	_wconn = wconn;
}

FILEOFF_T wideConnection::put(FDT *key, FDT *val, const char* index_name, FDT *index_val)
{
	return PutWIdx(_wconn, key->data, key->length, val->data, val->length, (char*)index_name, index_val->data, index_val->length);
}

FILEOFF_T wideConnection::put(LONG_T key, FDT *val, const char* index_name, FDT *index_val)
{
	return PutWIdxLong(_wconn, key, val->data, val->length, (char*)index_name, index_val->data, index_val->length);
}

resultset *wideConnection::scan(const char *index_name, FDT *skey, FDT *ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE res = ScanWIdx(_wconn, (char*)index_name, skey ? skey->data : NULL, skey ? skey->length : 0, ekey ? ekey->data : NULL, ekey ? ekey->length : 0, (HANDLE)sf);
	if(!res)
		return NULL;
	return new resultset(res);
}

resultset *wideConnection::scan(const char *index_name, const char *skey, const char *ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE res = ScanWIdx(_wconn, (char*)index_name, (HANDLE)skey, skey ? strlen(skey) : 0, (HANDLE)ekey, ekey ? strlen(ekey) : 0, (HANDLE)sf);
	if(!res)
		return NULL;
	return new resultset(res);
}

resultset *wideConnection::scan(const char *index_name, const char *skey, const char *ekey, scan_filter *sf, DATA_VAR *dv)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE res = ScanWIdx_DV(_wconn, (char*)index_name, (HANDLE)skey, skey ? strlen(skey) : 0, (HANDLE)ekey, ekey ? strlen(ekey) : 0, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!res)
		return NULL;
	return new resultset(res);
}

resultset *wideConnection::scan(const char *index_name, FDT *skey, FDT *ekey, scan_filter *sf, DATA_VAR *dv)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE res = ScanWIdx_DV(_wconn, (char*)index_name, skey ? skey->data : NULL, skey ? skey->length : 0, ekey ? ekey->data : NULL, ekey ? ekey->length : 0, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!res)
		return NULL;
	return new resultset(res);
}

resultset *wideConnection::scan_doc(const char *index_name, FDT *skey, FDT *ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE res = Scan_Doc_Idx(_wconn, (char*)index_name, skey ? (char*)skey->data : NULL, skey ? skey->length : 0, ekey ? (char*)ekey->data : NULL, ekey ? ekey->length : 0, (HANDLE)sf);
	if(!res)
		return NULL;
	return new resultset(res);
}

resultset *wideConnection::scan_doc(const char *index_name, const char *skey, const char *ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE res = Scan_Doc_Idx(_wconn, (char*)index_name, (char*)skey, skey ? strlen(skey) : 0, (char*)ekey, ekey ? strlen(ekey) : 0, (HANDLE)sf);
	if(!res)
		return NULL;
	return new resultset(res);
}

resultset *wideConnection::scan_doc(const char *index_name, LONG_T skey, LONG_T ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE res = Scan_Doc_Idx_Long(_wconn, (char*)index_name, skey, ekey, (HANDLE)sf);
	if(!res)
		return NULL;
	return new resultset(res);
}

resultset *wideConnection::scan_doc(const char *index_name, FDT *skey, FDT *ekey, scan_filter *sf, DATA_VAR *dv)
{
	HANDLE rs = Scan_Doc_Idx_DV(_wconn, (char*)index_name, skey ? skey->data : NULL, skey ? skey->length : 0, ekey ? ekey->data : NULL, ekey ? ekey->length : 0, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

resultset *wideConnection::scan_doc(const char *index_name, LONG_T skey, LONG_T ekey, scan_filter *sf, DATA_VAR *dv)
{
	HANDLE rs = Scan_Doc_Idx_Long_DV(_wconn, (char*)index_name, skey, ekey, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

resultset *wideConnection::scan_doc(const char *index_name, const char *skey, const char *ekey, scan_filter *sf, DATA_VAR *dv)
{
	HANDLE rs = Scan_Doc_Idx_DV(_wconn, (char*)index_name, (HANDLE)skey, skey ? strlen(skey) : 0, (HANDLE)ekey, ekey ? strlen(ekey) : 0, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

/*
resultset *wideConnection::scan_doc(char *json_filter, int json_filter_len)
{
	
}
*/
FILEOFF_T wideConnection::put_doc(const char *key, const char *json_str, insert_options flag)
{
	return Put_Doc_Str(_wconn, (char*)key, (char*)json_str, flag);
}

FILEOFF_T wideConnection::put_doc(LONG_T key, const char *json_str, insert_options flag)
{
	return Put_Doc_Long(_wconn, key, (char*)json_str, flag);
}

FILEOFF_T wideConnection::put_doc(const char *json_str)
{
	return Put_Doc(_wconn, (char*)json_str);
}
LONG_T wideConnection::count()
{
	return count((FDT*)NULL, (FDT*)NULL);
}
void wideConnection::set_autocommit(bool flag)
{
	SetAutoCommitW(_wconn, flag ? 1 : 0);
}
bangdb_persist_type wideConnection::getpersisttype()
{
	return (bangdb_persist_type)GetPersistTypeW(_wconn);
}
bangdb_index_type wideConnection::getidxtype()
{
	return (bangdb_index_type)GetIdxTypeW(_wconn);
}
int wideConnection::closeconnection()
{
	int ret = CloseConnectionW(_wconn);
	FreeHandle(&_wconn);
	return ret;
}
wideConnection::~wideConnection()
{

}
char *wideConnection::get(const char *key, bangdb_txn *txn_handle)
{
	char *val = NULL;
	int len;
	if(Get_TranW(_wconn, (HANDLE)key, strlen(key), (void**)&val, &len, txn_handle->txn) < 0)
	{
		if(val)
			FreeBytes(val);
		return NULL;
	}
	return val;
}

FDT *wideConnection::get(FDT *key, bangdb_txn *txn_handle)
{
	void *val = NULL;
	int len;
	if(Get_TranW(_wconn, (char*)key->data, key->length, &val, &len, txn_handle->txn) < 0)
		return NULL;
	FDT *v = new FDT(val, len);
	v->set_dll_alloc();
	return v;
}

char *wideConnection::get(const char *key)
{
	char *val = NULL;
	int len;
	if(GetW(_wconn, (char*)key, strlen(key), (void**)&val, &len) < 0)
	{
		if(val)
			FreeBytes(val);
		return NULL;
	}
	return val;
}

FDT *wideConnection::get(FDT *key)
{
	void *val = NULL;
	int len;
	if(GetW(_wconn, (char*)key->data, key->length, &val, &len) < 0)
		return NULL;
	FDT *v = new FDT(val, len);
	v->set_dll_alloc();
	return v;
}

//int wideConnection::get_long(LONG_T key, LONG_T *val);

FDT *wideConnection::get(LONG_T key)
{
	void *val; int vlen;
	if(Get_LongW(_wconn, key, &val, &vlen) < 0)
		return NULL;
	FDT *v = new FDT(val, vlen);
	v->set_dll_alloc();
	return v;
}

int wideConnection::get(const char *key, int keylen, DATA_VAR *data)
{
	HANDLE _conn = GetMainConn(_wconn);
	if(!_conn)
		return -1;
	return GetAdvanced(_conn, (char*)key, keylen, (HANDLE*)&data->data_buf, data->data_buf_len, &data->data_len, data->data_offt, &data->flag);
}

int wideConnection::get(const char *key, int keylen, DATA_VAR *data, bangdb_txn *txn_handle)
{
	HANDLE _conn = GetMainConn(_wconn);
	if(!_conn)
		return -1;
	return GetAdvancedTran(_conn, (char*)key, keylen, (HANDLE*)&data->data_buf, data->data_buf_len, &data->data_len, data->data_offt, &data->flag, txn_handle->txn);
}

int wideConnection::get(LONG_T key, DATA_VAR *data)
{
	HANDLE _conn = GetMainConn(_wconn);
	if(!_conn)
		return -1;
	return GetAdvancedLong(_conn, key, &(data->data_buf), data->data_buf_len, &(data->data_len), data->data_offt, &(data->flag));
}

int wideConnection::get(LONG_T key, DATA_VAR *data, bangdb_txn *txn_handle)
{
	HANDLE _conn = GetMainConn(_wconn);
	if(!_conn)
		return -1;
	return GetAdvancedLongTran(_conn, key, &(data->data_buf), data->data_buf_len, &(data->data_len), data->data_offt, &(data->flag), txn_handle->txn);
}

FILEOFF_T wideConnection::put(const char *key, int keylen, DATA_VAR *val, insert_options flag)
{
	HANDLE _conn = GetMainConn(_wconn);
	if(!_conn)
		return -1;
	return PutAdvanced(_conn, (char*)key, keylen, val->data_buf, val->data_buf_len, &val->data_len, val->data_offt, &val->flag, flag);
}

FILEOFF_T wideConnection::put(const char *key, int keylen, DATA_VAR *val, insert_options flag, bangdb_txn *txn_handle)
{
	HANDLE _conn = GetMainConn(_wconn);
	if(!_conn)
		return -1;
	return PutAdvanced_Tran(_conn, (char*)key, keylen, val->data_buf, val->data_buf_len, &val->data_len, val->data_offt, &val->flag, flag, txn_handle->txn);
}

FILEOFF_T wideConnection::put(const char *key, const char *val, insert_options flag, bangdb_txn *txn_handle)
{
	return Put_TranW(_wconn, (HANDLE)key, strlen(key), (HANDLE)val, strlen(val), flag, txn_handle->txn);
}

FILEOFF_T wideConnection::put(FDT *key, FDT *val, insert_options flag, bangdb_txn *txn_handle)
{
	return Put_TranW(_wconn, key->data, key->length, val->data, val->length, flag, txn_handle->txn);
}

FILEOFF_T wideConnection::put(const char *key, const char *val, insert_options flag)
{
	return PutW(_wconn, (HANDLE)key, strlen(key), (HANDLE)val, strlen(val), flag);
}

FILEOFF_T wideConnection::put(FDT *key, FDT *val, insert_options flag)
{
	return PutW(_wconn, key->data, key->length, val->data, val->length, flag);
}

FILEOFF_T wideConnection::put(LONG_T key, FDT *val, insert_options flag)
{
	return Put_LongW(_wconn, key, val->data, val->length, flag);
}

FILEOFF_T wideConnection::put(LONG_T key, FDT *val, insert_options flag, bangdb_txn *txn_handle)
{
	return Put_Long_TranW(_wconn, key, val->data, val->length, flag, txn_handle->txn);
}

FILEOFF_T wideConnection::put(LONG_T key, const char *val, insert_options flag)
{
	return Put_LongW(_wconn, key, (HANDLE)val, strlen(val), flag);
}

FILEOFF_T wideConnection::put(LONG_T key, const char *val, insert_options flag, bangdb_txn *txn)
{
	return Put_Long_TranW(_wconn, key, (HANDLE)val, strlen(val), flag, (HANDLE)txn->txn);
}

FILEOFF_T wideConnection::del(const char *key, bangdb_txn *txn_handle)
{
	return Del_TranW(_wconn, (HANDLE)key, strlen(key), txn_handle->txn);
}
	
FILEOFF_T wideConnection::del(FDT *key, bangdb_txn *txn_handle)
{
	return Del_TranW(_wconn, key->data, key->length, txn_handle->txn);
}

FILEOFF_T wideConnection::del(const char *key)
{
	return DelW(_wconn, (HANDLE)key, strlen(key));
}

FILEOFF_T wideConnection::del(FDT *key)
{
	return DelW(_wconn, key->data, key->length);
}

FILEOFF_T wideConnection::del(LONG_T key)
{
	return Del_longW(_wconn, key);
}

FILEOFF_T wideConnection::del(LONG_T key, bangdb_txn *txn)
{
	return Del_long_TranW(_wconn, key, (HANDLE)txn->txn);
}

FILEOFF_T wideConnection::del(int key)
{
	return Del_longW(_wconn, (long long)key);
}

resultset *wideConnection::scan(const char *skey, const char *ekey, bangdb_txn *txn_handle, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	int sklen = skey?(int)strlen(skey):0;
	int eklen = ekey?(int)strlen(ekey):0;
	HANDLE rs = Scan_TranW(_wconn, (HANDLE)skey, sklen, (HANDLE)ekey, eklen, txn_handle->txn, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}

resultset *wideConnection::scan(FDT *skey, FDT *ekey, bangdb_txn *txn_handle, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	void *s = skey?skey->data:NULL;
	int slen = skey?skey->length:0;
	void *e = ekey?ekey->data:NULL;
	int elen = ekey?ekey->length:0;
	HANDLE rs = Scan_TranW(_wconn, s, slen, e, elen, txn_handle->txn, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}

resultset *wideConnection::scan(const char *skey, const char *ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	int sklen = skey?(int)strlen(skey):0;
	int eklen = ekey?(int)strlen(ekey):0;
	HANDLE rs = ScanW(_wconn, (HANDLE)skey, sklen, (HANDLE)ekey, eklen, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}

resultset *wideConnection::scan(FDT *skey, FDT *ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	void *s = skey?skey->data:NULL;
	int slen = skey?skey->length:0;
	void *e = ekey?ekey->data:NULL;
	int elen = ekey?ekey->length:0;
	HANDLE rs = ScanW(_wconn, s, slen, e, elen, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}

resultset *wideConnection::scan(LONG_T skey, LONG_T ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE rs = Scan_LongW(_wconn, skey, ekey, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}

resultset *wideConnection::scan(LONG_T skey, LONG_T ekey, bangdb_txn *txn, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE rs = Scan_Long_TranW(_wconn, skey, ekey, (HANDLE)txn->txn, (HANDLE)sf);
	if(rs == NULL)
		return NULL;
	resultset *RS = new resultset(rs);
	return RS;
}

resultset* wideConnection::scan(const char *skey, const char *ekey, bangdb_txn *txn_handle, scan_filter *sf, DATA_VAR *dv)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE rs = Scan_DV_TranW(_wconn, (HANDLE)skey, skey ? strlen(skey) : 0, (HANDLE)ekey, ekey ? strlen(ekey) : 0, txn_handle->txn, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

resultset* wideConnection::scan(FDT *skey, FDT *ekey, bangdb_txn *txn_handle, scan_filter *sf, DATA_VAR *dv)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE rs = Scan_DV_TranW(_wconn, skey ? skey->data : NULL, skey ? skey->length : 0, ekey ? ekey->data : NULL, ekey ? ekey->length : 0, txn_handle->txn, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

resultset* wideConnection::scan(LONG_T skey, LONG_T ekey, bangdb_txn *txn_handle, scan_filter *sf, DATA_VAR *dv)
{
	HANDLE rs = Scan_DV_Long_TranW(_wconn, skey, ekey, (HANDLE)txn_handle->txn, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

resultset* wideConnection::scan(const char *skey, const char *ekey, scan_filter *sf, DATA_VAR *dv)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE rs = Scan_DVW(_wconn, (HANDLE)skey, skey ? strlen(skey) : 0, (HANDLE)ekey, ekey ? strlen(ekey) : 0, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

resultset* wideConnection::scan(FDT *skey, FDT *ekey, scan_filter *sf, DATA_VAR *dv)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	HANDLE rs = Scan_DVW(_wconn, skey ? skey->data : NULL, skey ? skey->length : 0, ekey ? ekey->data : NULL, ekey ? ekey->length : 0, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

resultset* wideConnection::scan(LONG_T skey, LONG_T ekey, scan_filter *sf, DATA_VAR *dv)
{
	HANDLE rs = Scan_DV_LongW(_wconn, skey, ekey, (HANDLE)sf, dv->data_buf, dv->data_buf_len, &dv->data_len, dv->data_offt, &dv->flag);
	if(!rs)
		return NULL;
	return new resultset(rs);
}

LONG_T wideConnection::count(const char *skey, const char *ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	int sklen = skey?(int)strlen(skey):0;
	int eklen = ekey?(int)strlen(ekey):0;
	return CountW(_wconn, (HANDLE)skey, sklen, (HANDLE)ekey, eklen, (HANDLE)sf);
}

LONG_T wideConnection::count(FDT *skey, FDT *ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	void *s = skey?skey->data:NULL;
	int slen = skey?skey->length:0;
	void *e = ekey?ekey->data:NULL;
	int elen = ekey?ekey->length:0;
	return CountW(_wconn, s, slen, e, elen, (HANDLE)sf);
}

LONG_T wideConnection::count(LONG_T skey, LONG_T ekey, scan_filter *sf)
{
	scan_filter _sf;
	if(!sf)
		sf = &_sf;
	return Count_LongW(_wconn, skey, ekey, (HANDLE)sf);
}
}