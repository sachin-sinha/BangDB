#include "bangdb_DatabaseImpl.h"
#include "database.h"
#include "iostream"
using namespace std;
using namespace bangdb;

JNIEXPORT jlong JNICALL Java_bangdb_DatabaseImpl_init
  (JNIEnv *env, jobject obj, jstring databasename, jstring configPath, jshort transaction_type, jstring dbPath, jstring dbLogPath)
{
    jboolean iscopy; 
    const char *dtname, *_configPath = NULL, *_dbPath = NULL, *_dbLogPath = NULL; 
    dtname = env->GetStringUTFChars(databasename, &iscopy);
	if(configPath != NULL)
	    _configPath = env->GetStringUTFChars(configPath, &iscopy); 
	if(dbPath != NULL)
	    _dbPath = env->GetStringUTFChars(dbPath, &iscopy);  
	if(dbLogPath != NULL)
	   _dbLogPath = env->GetStringUTFChars(dbLogPath, &iscopy);  
    /*
    const char *ht = env->GetStringUTFChars(host, &iscopy);
    const char *pt = env->GetStringUTFChars(port, &iscopy);
    const char *uname = env->GetStringUTFChars(usrname, &iscopy);
    const char * password = env->GetStringUTFChars( pwd, &iscopy);
    */
    //database *db = new database ((char*)dtname, (char*)ht, (char*)pt, (char*)uname, (char*)password);
    database *db = new database ((char*)dtname, (char*)_configPath, (db_transaction_type)transaction_type, (char*)_dbPath, (char*)_dbLogPath);
    	
    env->ReleaseStringUTFChars(databasename, dtname);
    env->ReleaseStringUTFChars(configPath, _configPath);
    env->ReleaseStringUTFChars(dbPath, _dbPath);
    env->ReleaseStringUTFChars(dbLogPath, _dbLogPath);

    jlong ptdb = (jlong)db;
    return ptdb;
}

JNIEXPORT jobject JNICALL Java_bangdb_DatabaseImpl_gettable (JNIEnv *env, jobject obj, jstring name, jshort openflag, jobject tenv, jlong ptdb)
{
	table_env te;
	if(tenv != NULL)
	{
		jclass envcls = env->GetObjectClass(tenv);
		jmethodID mid_thint = env->GetMethodID(envcls, "getTableSizeHintOrdinal", "()S");
		jmethodID mid_dbt = env->GetMethodID(envcls, "getDBTypeOrdinal", "()S");
		jmethodID mid_idxt = env->GetMethodID(envcls, "getIndexTypeOrdinal", "()S");
		jmethodID mid_ksz = env->GetMethodID(envcls, "getKeySizeByte", "()S");
		jmethodID mid_logtp = env->GetMethodID(envcls, "getLogTypeOrdinal", "()S");
		jmethodID mid_lsz = env->GetMethodID(envcls, "getLogSizeMB", "()S");
		jmethodID mid_lst = env->GetMethodID(envcls, "getLogStateOrdinal", "()S");
		jmethodID mid_acm = env->GetMethodID(envcls, "getAutocommitStateOrdinal", "()S");
		jmethodID mid_tbltp = env->GetMethodID(envcls, "getTableTypeOrdinal", "()S");
		jmethodID mid_keytp = env->GetMethodID(envcls, "getKeyTypeOrdinal", "()S");
		jmethodID mid_sortm = env->GetMethodID(envcls, "getSortMethodOrdinal", "()S");
		jmethodID mid_sortd = env->GetMethodID(envcls, "getSortDirectionOrdinal", "()S");
		jmethodID mid_adup = env->GetMethodID(envcls, "getAllowDuplicatesOrdinal", "()S");

		jmethodID mid_tblSubTpd = env->GetMethodID(envcls, "getTableSubTypeOrdinal", "()S");
		jmethodID mid_primDataTpd = env->GetMethodID(envcls, "getPrimitiveDataTypeOrdinal", "()S");

		if(mid_thint == 0 || mid_dbt == 0 || mid_idxt == 0 || mid_ksz == 0 || mid_lsz == 0 || mid_lst == 0 || mid_acm == 0
			|| mid_tbltp == 0 || mid_keytp == 0 || mid_sortm == 0 || mid_sortd == 0 || mid_logtp == 0 || mid_adup == 0)		
			return NULL;

		jshort thint = env->CallShortMethod(tenv, mid_thint);
		jshort dbt = env->CallShortMethod(tenv, mid_dbt);
		jshort idxt = env->CallShortMethod(tenv, mid_idxt);
		jshort ksz = env->CallShortMethod(tenv, mid_ksz);
		jshort logtp = env->CallShortMethod(tenv, mid_logtp);
		jshort lsz = env->CallShortMethod(tenv, mid_lsz);
		jshort lst = env->CallShortMethod(tenv, mid_lst);
		jshort acm = env->CallShortMethod(tenv, mid_acm);	
		jshort tbltp = env->CallShortMethod(tenv, mid_tbltp);	
		jshort keytp = env->CallShortMethod(tenv, mid_keytp);	
		jshort sortm = env->CallShortMethod(tenv, mid_sortm);	
		jshort sortd = env->CallShortMethod(tenv, mid_sortd);	
		jshort adup = env->CallShortMethod(tenv, mid_adup);

		jshort tblSubTpd = env->CallShortMethod(tenv, mid_tblSubTpd);
		jshort primDataTpd = env->CallShortMethod(tenv, mid_primDataTpd);

		te.set_table_size_hint(thint);
		if(dbt != -1)
			te.set_persist_type(dbt);
		if(idxt != -1)
			te.set_idx_type(idxt);
		if(ksz != -1)
			te.set_key_size_byte(ksz);
		if(logtp != -1)
			te.set_log_type(logtp);
		if(lsz != -1)
			te.set_log_size_mb(lsz);
		if(lst != -1)
			te.set_log_state(lst);
		if(acm != -1)
			te.set_autocommit_state(acm);
		if(tbltp != -1)
			te.set_table_type(tbltp);
		if(keytp != -1)
			te.set_key_type(keytp);
		if(sortm != -1)
			te.set_sort_method(sortm);
		if(sortd != -1)
			te.set_sort_dirction(sortd);
		if(adup != -1)
			te.set_allow_duplicate(adup);
		if(tblSubTpd != -1)
			te.set_table_subtype(tblSubTpd);
		if(primDataTpd != -1)
			te.set_primitive_data_type(primDataTpd);
		te.set_config_vars();
	}

    	jboolean iscopy;
    	const char *tb_name = env->GetStringUTFChars(name, &iscopy);
    	database *db= (database *)ptdb;

    	table *tb;
	if(tenv != NULL)
		tb = db->gettable((char*) tb_name, (bangdb_open_type)openflag, &te);
	else
		tb = db->gettable((char*) tb_name, (bangdb_open_type)openflag, NULL);		

	env->ReleaseStringUTFChars(name, tb_name);
    
	if(tb == NULL)
    		return NULL;
    	
    	jclass tableClass = env->FindClass("bangdb/TableImpl");
    	jfieldID fld = env->GetFieldID(tableClass, "pttb", "J");
    	jobject tableObject = env->AllocObject(tableClass);
    
    	env->SetLongField(tableObject, fld, (jlong)tb);
    	return tableObject; 
}

JNIEXPORT jobject JNICALL Java_bangdb_DatabaseImpl_getwidetable (JNIEnv *env, jobject obj, jstring name, jshort openflag, jobject tenv, jlong ptdb)
{
	table_env te;
	if(tenv != NULL)
	{
		jclass envcls = env->GetObjectClass(tenv);
		jmethodID mid_thint = env->GetMethodID(envcls, "getTableSizeHintOrdinal", "()S");
		jmethodID mid_dbt = env->GetMethodID(envcls, "getDBTypeOrdinal", "()S");
		jmethodID mid_idxt = env->GetMethodID(envcls, "getIndexTypeOrdinal", "()S");
		jmethodID mid_ksz = env->GetMethodID(envcls, "getKeySizeByte", "()S");
		jmethodID mid_logtp = env->GetMethodID(envcls, "getLogTypeOrdinal", "()S");
		jmethodID mid_lsz = env->GetMethodID(envcls, "getLogSizeMB", "()S");
		jmethodID mid_lst = env->GetMethodID(envcls, "getLogStateOrdinal", "()S");
		jmethodID mid_acm = env->GetMethodID(envcls, "getAutocommitStateOrdinal", "()S");
		jmethodID mid_tbltp = env->GetMethodID(envcls, "getTableTypeOrdinal", "()S");
		jmethodID mid_keytp = env->GetMethodID(envcls, "getKeyTypeOrdinal", "()S");
		jmethodID mid_sortm = env->GetMethodID(envcls, "getSortMethodOrdinal", "()S");
		jmethodID mid_sortd = env->GetMethodID(envcls, "getSortDirectionOrdinal", "()S");
		jmethodID mid_adup = env->GetMethodID(envcls, "getAllowDuplicatesOrdinal", "()S");
		
		jmethodID mid_tblSubTpd = env->GetMethodID(envcls, "getTableSubTypeOrdinal", "()S");
		jmethodID mid_primDataTpd = env->GetMethodID(envcls, "getPrimitiveDataTypeOrdinal", "()S");

		if(mid_thint == 0 || mid_dbt == 0 || mid_idxt == 0 || mid_ksz == 0 || mid_lsz == 0 || mid_lst == 0 || mid_acm == 0
			|| mid_tbltp == 0 || mid_keytp == 0 || mid_sortm == 0 || mid_sortd == 0 || mid_logtp == 0 || mid_adup == 0)		
			return NULL;


		jshort thint = env->CallShortMethod(tenv, mid_thint);
		jshort dbt = env->CallShortMethod(tenv, mid_dbt);
		jshort idxt = env->CallShortMethod(tenv, mid_idxt);
		jshort ksz = env->CallShortMethod(tenv, mid_ksz);
		jshort logtp = env->CallShortMethod(tenv, mid_logtp);
		jshort lsz = env->CallShortMethod(tenv, mid_lsz);
		jshort lst = env->CallShortMethod(tenv, mid_lst);
		jshort acm = env->CallShortMethod(tenv, mid_acm);	
		jshort tbltp = env->CallShortMethod(tenv, mid_tbltp);	
		jshort keytp = env->CallShortMethod(tenv, mid_keytp);	
		jshort sortm = env->CallShortMethod(tenv, mid_sortm);	
		jshort sortd = env->CallShortMethod(tenv, mid_sortd);	
		jshort adup = env->CallShortMethod(tenv, mid_adup);
		
		jshort tblSubTpd = env->CallShortMethod(tenv, mid_tblSubTpd);
		jshort primDataTpd = env->CallShortMethod(tenv, mid_primDataTpd);

		te.set_table_size_hint(thint);
		if(dbt != -1)
			te.set_persist_type(dbt);
		if(idxt != -1)
			te.set_idx_type(idxt);
		if(ksz != -1)
			te.set_key_size_byte(ksz);
		if(logtp != -1)
			te.set_log_type(logtp);
		if(lsz != -1)
			te.set_log_size_mb(lsz);
		if(lst != -1)
			te.set_log_state(lst);
		if(acm != -1)
			te.set_autocommit_state(acm);
		if(tbltp != -1)
			te.set_table_type(tbltp);
		if(keytp != -1)
			te.set_key_type(keytp);
		if(sortm != -1)
			te.set_sort_method(sortm);
		if(sortd != -1)
			te.set_sort_dirction(sortd);
		if(adup != -1)
			te.set_allow_duplicate(adup);
		if(tblSubTpd != -1)
			te.set_table_subtype(tblSubTpd);
		if(primDataTpd != -1)
			te.set_primitive_data_type(primDataTpd);
		te.set_config_vars();
	}

    	jboolean iscopy;
    	const char *tb_name = env->GetStringUTFChars(name, &iscopy);
    	database *db= (database *)ptdb;
    
    	wideTable *tb;
	if(tenv != NULL)
		tb = db->getWideTable((char*) tb_name, (bangdb_open_type)openflag, &te);
	else
		tb = db->getWideTable((char*) tb_name, (bangdb_open_type)openflag, NULL);		

	env->ReleaseStringUTFChars(name, tb_name);
    
	if(tb == NULL)
    		return NULL;
    	
    	jclass tableClass = env->FindClass("bangdb/WideTableImpl");
    	jfieldID fld = env->GetFieldID(tableClass, "ptwtb", "J");
    	jobject tableObject = env->AllocObject(tableClass);
    
    	env->SetLongField(tableObject, fld, (jlong)tb);
    	return tableObject; 
}

JNIEXPORT jobject JNICALL Java_bangdb_DatabaseImpl_getPrimitiveTable
  (JNIEnv *env, jobject obj, jstring name, jshort dataType, jshort openflag, jobject tenv, jlong ptdb)
{
	table_env te;
	if(tenv != NULL)
	{
		jclass envcls = env->GetObjectClass(tenv);
		jmethodID mid_thint = env->GetMethodID(envcls, "getTableSizeHintOrdinal", "()S");
		jmethodID mid_dbt = env->GetMethodID(envcls, "getDBTypeOrdinal", "()S");
		jmethodID mid_idxt = env->GetMethodID(envcls, "getIndexTypeOrdinal", "()S");
		jmethodID mid_ksz = env->GetMethodID(envcls, "getKeySizeByte", "()S");
		jmethodID mid_logtp = env->GetMethodID(envcls, "getLogTypeOrdinal", "()S");
		jmethodID mid_lsz = env->GetMethodID(envcls, "getLogSizeMB", "()S");
		jmethodID mid_lst = env->GetMethodID(envcls, "getLogStateOrdinal", "()S");
		jmethodID mid_acm = env->GetMethodID(envcls, "getAutocommitStateOrdinal", "()S");
		jmethodID mid_tbltp = env->GetMethodID(envcls, "getTableTypeOrdinal", "()S");
		jmethodID mid_keytp = env->GetMethodID(envcls, "getKeyTypeOrdinal", "()S");
		jmethodID mid_sortm = env->GetMethodID(envcls, "getSortMethodOrdinal", "()S");
		jmethodID mid_sortd = env->GetMethodID(envcls, "getSortDirectionOrdinal", "()S");
		jmethodID mid_adup = env->GetMethodID(envcls, "getAllowDuplicatesOrdinal", "()S");

		jmethodID mid_tblSubTpd = env->GetMethodID(envcls, "getTableSubTypeOrdinal", "()S");
		jmethodID mid_primDataTpd = env->GetMethodID(envcls, "getPrimitiveDataTypeOrdinal", "()S");

		if(mid_thint == 0 || mid_dbt == 0 || mid_idxt == 0 || mid_ksz == 0 || mid_lsz == 0 || mid_lst == 0 || mid_acm == 0
			|| mid_tbltp == 0 || mid_keytp == 0 || mid_sortm == 0 || mid_sortd == 0 || mid_logtp == 0 || mid_adup == 0)		
			return NULL;


		jshort thint = env->CallShortMethod(tenv, mid_thint);
		jshort dbt = env->CallShortMethod(tenv, mid_dbt);
		jshort idxt = env->CallShortMethod(tenv, mid_idxt);
		jshort ksz = env->CallShortMethod(tenv, mid_ksz);
		jshort logtp = env->CallShortMethod(tenv, mid_logtp);
		jshort lsz = env->CallShortMethod(tenv, mid_lsz);
		jshort lst = env->CallShortMethod(tenv, mid_lst);
		jshort acm = env->CallShortMethod(tenv, mid_acm);	
		jshort tbltp = env->CallShortMethod(tenv, mid_tbltp);	
		jshort keytp = env->CallShortMethod(tenv, mid_keytp);	
		jshort sortm = env->CallShortMethod(tenv, mid_sortm);	
		jshort sortd = env->CallShortMethod(tenv, mid_sortd);
		jshort adup = env->CallShortMethod(tenv, mid_adup);	

		jshort tblSubTpd = env->CallShortMethod(tenv, mid_tblSubTpd);
		jshort primDataTpd = env->CallShortMethod(tenv, mid_primDataTpd);

		te.set_table_size_hint(thint);
		if(dbt != -1)
			te.set_persist_type(dbt);
		if(idxt != -1)
			te.set_idx_type(idxt);
		if(ksz != -1)
			te.set_key_size_byte(ksz);
		if(logtp != -1)
			te.set_log_type(logtp);
		if(lsz != -1)
			te.set_log_size_mb(lsz);
		if(lst != -1)
			te.set_log_state(lst);
		if(acm != -1)
			te.set_autocommit_state(acm);
		if(tbltp != -1)
			te.set_table_type(tbltp);
		if(keytp != -1)
			te.set_key_type(keytp);
		if(sortm != -1)
			te.set_sort_method(sortm);
		if(sortd != -1)
			te.set_sort_dirction(sortd);
		if(adup != -1)
			te.set_allow_duplicate(adup);
		if(tblSubTpd != -1)
			te.set_table_subtype(tblSubTpd);
		if(primDataTpd != -1)
			te.set_primitive_data_type(primDataTpd);
		te.set_config_vars();
	}

    	jboolean iscopy;
    	const char *tb_name = env->GetStringUTFChars(name, &iscopy);
    	database *db= (database *)ptdb;
    
    	table *tb;
	if(tenv != NULL)
		tb = db->getPrimitiveTable((char*) tb_name, (bangdb_primitive_data_type)dataType, (bangdb_open_type)openflag, &te);
	else
		tb = db->getPrimitiveTable((char*) tb_name, (bangdb_primitive_data_type)dataType, (bangdb_open_type)openflag, NULL);

	env->ReleaseStringUTFChars(name, tb_name);
    
	if(tb == NULL)
    		return NULL;
    	
    	jclass tableClass = env->FindClass("bangdb/TableImpl");
    	jfieldID fld = env->GetFieldID(tableClass, "pttb", "J");
    	jobject tableObject = env->AllocObject(tableClass);
    
    	env->SetLongField(tableObject, fld, (jlong)tb);
    	return tableObject; 
}

JNIEXPORT void JNICALL Java_bangdb_DatabaseImpl_cleanup (JNIEnv *env, jobject obj, jlong ptdb) 
{
   database *db = (database*) ptdb; 
   if(db != NULL)
   {
       db->cleanup();
   }
}

JNIEXPORT jstring JNICALL Java_bangdb_DatabaseImpl_getdbname (JNIEnv *env, jobject obj, jlong ptdb) 
{
    database *db= (database *)ptdb; 
    const char * dbname =  db->getdbname();
    jstring databaseName = env->NewStringUTF(dbname); 
    return databaseName; 
}
 
JNIEXPORT jint JNICALL Java_bangdb_DatabaseImpl_closetable__Ljava_lang_String_2SJ (JNIEnv *env, jobject obj, jstring rname, jshort tbclose, jlong ptdb)
{
	/*
    database *db = (database *)ptdb;
    jboolean iscopy;
    const char *dbname = env->GetStringUTFChars(rname, &iscopy);
    jint r = (jint) db->closetable((char*)dbname, (bangdb_close_type)tbclose);
    env->ReleaseStringUTFChars(rname, dbname);
    return r;
	*/
	return -1;
} 

JNIEXPORT jint JNICALL Java_bangdb_DatabaseImpl_closetable__Lbangdb_Table_2SJ (JNIEnv *env, jobject obj, jobject tb, jshort tbclose, jlong ptdb) 
{
    database *db = (database *)ptdb;
    jclass cl = env->GetObjectClass(tb);
    jfieldID fld = env->GetFieldID(cl, "pttb", "J");
    jlong pttb = env->GetLongField(tb, fld); 
    table *tbl = (table *) pttb; 
    jint ret = (jint)db->closetable(tbl, (bangdb_close_type)tbclose);
    delete tbl;
    return ret;
}
JNIEXPORT jint JNICALL Java_bangdb_DatabaseImpl_closeTable
  (JNIEnv *env, jobject obj, jobject wtb, jshort wtbclose, jlong ptdb)
{
    database *db = (database *)ptdb;
    jclass cl = env->GetObjectClass(wtb);
    jfieldID fld = env->GetFieldID(cl, "ptwtb", "J");
    jlong ptwtb = env->GetLongField(wtb, fld); 
    wideTable *wtbl = (wideTable *) ptwtb; 
    jint ret = (jint)db->closetable(wtbl, (bangdb_close_type)wtbclose);
    delete wtbl;
    return ret;
}

JNIEXPORT void JNICALL Java_bangdb_DatabaseImpl_closedatabase (JNIEnv *env, jobject obj, jshort dbclose, jlong ptdb)
{
    database *db = (database *)ptdb;
    db->closedatabase((bangdb_close_type)dbclose);
    delete db;
}

JNIEXPORT jlong JNICALL Java_bangdb_DatabaseImpl_begin_1transaction
(JNIEnv *env, jobject obj, jlong ptdb, jlong pttxn)
{
	database *db = (database *)ptdb;
	if(pttxn == -999999)
	{
		bangdb_txn *txn = new bangdb_txn();
		pttxn = (jlong)txn;
	}

	db->begin_transaction((bangdb_txn*)pttxn);
	return (jlong)pttxn;
/*
	jclass txnClass = env->FindClass("bangdb/Transaction");
	jfieldID txfld = env->GetFieldID(txnClass, "pttxn", "J");
	jobject txnObject = env->AllocObject(txnClass);

	env->SetLongField(txnObject, txfld, (jlong)txn);
	return txnObject;
*/
}

JNIEXPORT jlong JNICALL Java_bangdb_DatabaseImpl_commit_1transaction  (JNIEnv *env, jobject obj, jlong ptdb, jlong ptxn)
{
	if(ptxn == -999999)
		return -1;
	database *db = (database *)ptdb;
	jlong tid = db->commit_transaction((bangdb_txn*)ptxn);
	return tid;
}

JNIEXPORT void JNICALL Java_bangdb_DatabaseImpl_abort_1transaction  (JNIEnv *env, jobject obj, jlong ptdb, jlong ptxn)
{
	if(ptxn == -999999)
		return;
	database *db = (database *)ptdb;
	db->abort_transaction((bangdb_txn*)ptxn);
}

    
