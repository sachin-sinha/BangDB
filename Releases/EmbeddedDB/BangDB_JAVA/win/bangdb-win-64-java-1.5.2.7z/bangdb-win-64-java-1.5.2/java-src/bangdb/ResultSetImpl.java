package bangdb;

public class ResultSetImpl implements ResultSet {

	public native byte[] GetNextKey(long ptrs);
	public native long GetNextKeyLong(long ptrs);
	public native byte[] GetNextVal(long ptrs);
	public native long GetNextValLong(long ptrs);
	public native boolean HasNext(long ptrs);
	public native void MoveNext(long ptrs);
	public native int Size(long ptrs);
	public native void Begin(long ptrs);
	public native void Clear(long ptrs);
	public native boolean MoreDataToCome(long ptrs);
	public native byte[] LastEvaluatedKey(long ptrs);
	public native long LastEvaluatedKeyLong(long ptrs);
	public native byte[] SearchValue(long ptrs, String key);
	public native byte[] SearchValue(long ptrs, byte[] key);
	public native int data_size(long ptrs);

/* */
	public native void addDoc(long rs, String orderBy, long ptrs);

	public native void add(long rs, long ptrs);

	public native void append(long rs, long ptrs);

	public native void intersect(long rs, long ptrs);

	public native String getNextKeyStr(long ptrs);

	public native String getNextValStr(long ptrs);

	public native void beginReverse(long ptrs);
/* */

	public long ptrs;
	
	public ResultSetImpl(long rs){
		ptrs = rs;
	}

	@Override
	public void addDoc(ResultSetImpl rs, String orderBy) {
		addDoc(rs.ptrs, orderBy, ptrs);
	}

	@Override
	public void add(ResultSetImpl rs) {
		add(rs.ptrs, ptrs);
	}

	@Override
	public void append(ResultSetImpl rs) {
		append(rs.ptrs, ptrs);
	}

	@Override
	public void intersect(ResultSetImpl rs) {
		intersect(rs.ptrs, ptrs);
	}

	@Override
	public String getNextKeyStr() {
		return getNextKeyStr(ptrs);
	}
	
	@Override
	public String getNextValStr() {
		return getNextValStr(ptrs);
	}

	@Override
	public void beginReverse() {
		beginReverse(ptrs);
	}

	@Override
	public byte[] getNextKey() {
		return GetNextKey(ptrs);
	}

	@Override
	public long getNextKeyLong() {
		return GetNextKeyLong(ptrs);
	}

	@Override
	public byte[] getNextVal() {
		return GetNextVal(ptrs);
	}

	@Override
	public long getNextValLong() {
		return GetNextValLong(ptrs);
	}

	@Override
	public boolean hasNext() {
		return HasNext(ptrs);
	}

	@Override
	public void moveNext() {
		MoveNext(ptrs);
	}

	@Override
	public int count() {
		return Size(ptrs);
	}

	@Override
	public void begin() {
		Begin(ptrs);
	}

	@Override
	public void clear() {
		Clear(ptrs);
	}

	@Override
	public boolean moreDataToCome() {
		return MoreDataToCome(ptrs);
	}

	@Override
	public byte[] lastEvaluatedKey() {
		return	LastEvaluatedKey(ptrs);
	}

	@Override
	public long lastEvaluatedKeyLong() {
		return LastEvaluatedKeyLong(ptrs);
	}

	@Override
	public byte[] searchValue(String key) {
		return SearchValue(ptrs, key);
	}

	@Override
	public byte[] searchValue(byte[] key) {
		return SearchValue(ptrs, key);
	}

	@Override
	public int size() {
		return data_size(ptrs);
	}
}
