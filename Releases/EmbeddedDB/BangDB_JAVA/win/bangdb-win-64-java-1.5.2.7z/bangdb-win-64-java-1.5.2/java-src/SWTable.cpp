#include "bangdb_SWTableImpl.h"
#include "swTable.h"
using namespace bangdb;

JNIEXPORT jlong JNICALL Java_bangdb_SWTableImpl_init
  (JNIEnv *env, jobject obj, jlong ptdb, jstring tableName, jobject tenv, jint ttlsec, jint archive)
{
	jboolean iscopy; 
	table_env te;
	const char *tblname = env->GetStringUTFChars(tableName, &iscopy);
		
	if(tenv != NULL)
	{
		jclass envcls = env->GetObjectClass(tenv);
		jmethodID mid_thint = env->GetMethodID(envcls, "getTableSizeHintOrdinal", "()S");
		jmethodID mid_dbt = env->GetMethodID(envcls, "getDBTypeOrdinal", "()S");
		jmethodID mid_idxt = env->GetMethodID(envcls, "getIndexTypeOrdinal", "()S");
		jmethodID mid_ksz = env->GetMethodID(envcls, "getKeySizeByte", "()S");
		jmethodID mid_logtp = env->GetMethodID(envcls, "getLogTypeOrdinal", "()S");
		jmethodID mid_lsz = env->GetMethodID(envcls, "getLogSizeMB", "()S");
		jmethodID mid_lst = env->GetMethodID(envcls, "getLogStateOrdinal", "()S");
		jmethodID mid_acm = env->GetMethodID(envcls, "getAutocommitStateOrdinal", "()S");
		jmethodID mid_tbltp = env->GetMethodID(envcls, "getTableTypeOrdinal", "()S");
		jmethodID mid_keytp = env->GetMethodID(envcls, "getKeyTypeOrdinal", "()S");
		jmethodID mid_sortm = env->GetMethodID(envcls, "getSortMethodOrdinal", "()S");
		jmethodID mid_sortd = env->GetMethodID(envcls, "getSortDirectionOrdinal", "()S");

		jmethodID mid_tblSubTpd = env->GetMethodID(envcls, "getTableSubTypeOrdinal", "()S");
		jmethodID mid_primDataTpd = env->GetMethodID(envcls, "getPrimitiveDataTypeOrdinal", "()S");

		if(mid_thint == 0 || mid_dbt == 0 || mid_idxt == 0 || mid_ksz == 0 || mid_lsz == 0 || mid_lst == 0 || mid_acm == 0)
			return (jlong)NULL;

		jshort thint = env->CallShortMethod(tenv, mid_thint);
		jshort dbt = env->CallShortMethod(tenv, mid_dbt);
		jshort idxt = env->CallShortMethod(tenv, mid_idxt);
		jshort ksz = env->CallShortMethod(tenv, mid_ksz);
		jshort logtp = env->CallShortMethod(tenv, mid_logtp);
		jshort lsz = env->CallShortMethod(tenv, mid_lsz);
		jshort lst = env->CallShortMethod(tenv, mid_lst);
		jshort acm = env->CallShortMethod(tenv, mid_acm);	
		jshort tbltp = env->CallShortMethod(tenv, mid_tbltp);	
		jshort keytp = env->CallShortMethod(tenv, mid_keytp);	
		jshort sortm = env->CallShortMethod(tenv, mid_sortm);	
		jshort sortd = env->CallShortMethod(tenv, mid_sortd);	

		jshort tblSubTpd = env->CallShortMethod(tenv, mid_tblSubTpd);
		jshort primDataTpd = env->CallShortMethod(tenv, mid_primDataTpd);

		te.set_table_size_hint(thint);
		if(dbt != -1)
			te.set_persist_type(dbt);
		if(idxt != -1)
			te.set_idx_type(idxt);
		if(ksz != -1)
			te.set_key_size_byte(ksz);
		if(logtp != -1)
			te.set_log_type(logtp);
		if(lsz != -1)
			te.set_log_size_mb(lsz);
		if(lst != -1)
			te.set_log_state(lst);
		if(acm != -1)
			te.set_autocommit_state(acm);
		if(tbltp != -1)
			te.set_table_type(tbltp);
		if(keytp != -1)
			te.set_key_type(keytp);
		if(sortm != -1)
			te.set_sort_method(sortm);
		if(sortd != -1)
			te.set_sort_dirction(sortd);
		if(tblSubTpd != -1)
			te.set_table_subtype(tblSubTpd);
		if(primDataTpd != -1)
			te.set_primitive_data_type(primDataTpd);
		te.set_config_vars();
	}

	swTable *swtbl = new swTable((database*)ptdb, (char*)tblname, &te, (int)ttlsec, archive > 0 ? true : false);
	env->ReleaseStringUTFChars(tableName, tblname);
	jlong ptswtbl = (jlong)swtbl;
	return ptswtbl;
}

JNIEXPORT void JNICALL Java_bangdb_SWTableImpl_addIndex
  (JNIEnv *env, jobject obj, jstring idxName, jobject tenv, jlong ptswtbl)
{
	jboolean iscopy; 
	table_env te;
	const char *idxname = env->GetStringUTFChars(idxName, &iscopy);
		
	if(tenv != NULL)
	{
		jclass envcls = env->GetObjectClass(tenv);
		jmethodID mid_thint = env->GetMethodID(envcls, "getTableSizeHintOrdinal", "()S");
		jmethodID mid_dbt = env->GetMethodID(envcls, "getDBTypeOrdinal", "()S");
		jmethodID mid_idxt = env->GetMethodID(envcls, "getIndexTypeOrdinal", "()S");
		jmethodID mid_ksz = env->GetMethodID(envcls, "getKeySizeByte", "()S");
		jmethodID mid_logtp = env->GetMethodID(envcls, "getLogTypeOrdinal", "()S");
		jmethodID mid_lsz = env->GetMethodID(envcls, "getLogSizeMB", "()S");
		jmethodID mid_lst = env->GetMethodID(envcls, "getLogStateOrdinal", "()S");
		jmethodID mid_acm = env->GetMethodID(envcls, "getAutocommitStateOrdinal", "()S");
		jmethodID mid_tbltp = env->GetMethodID(envcls, "getTableTypeOrdinal", "()S");
		jmethodID mid_keytp = env->GetMethodID(envcls, "getKeyTypeOrdinal", "()S");
		jmethodID mid_sortm = env->GetMethodID(envcls, "getSortMethodOrdinal", "()S");
		jmethodID mid_sortd = env->GetMethodID(envcls, "getSortDirectionOrdinal", "()S");
		jmethodID mid_tblSubTpd = env->GetMethodID(envcls, "getTableSubTypeOrdinal", "()S");
		jmethodID mid_primDataTpd = env->GetMethodID(envcls, "getPrimitiveDataTypeOrdinal", "()S");

		if(mid_thint == 0 || mid_dbt == 0 || mid_idxt == 0 || mid_ksz == 0 || mid_lsz == 0 || mid_lst == 0 || mid_acm == 0)
			return;

		jshort thint = env->CallShortMethod(tenv, mid_thint);
		jshort dbt = env->CallShortMethod(tenv, mid_dbt);
		jshort idxt = env->CallShortMethod(tenv, mid_idxt);
		jshort ksz = env->CallShortMethod(tenv, mid_ksz);
		jshort logtp = env->CallShortMethod(tenv, mid_logtp);
		jshort lsz = env->CallShortMethod(tenv, mid_lsz);
		jshort lst = env->CallShortMethod(tenv, mid_lst);
		jshort acm = env->CallShortMethod(tenv, mid_acm);	
		jshort tbltp = env->CallShortMethod(tenv, mid_tbltp);	
		jshort keytp = env->CallShortMethod(tenv, mid_keytp);	
		jshort sortm = env->CallShortMethod(tenv, mid_sortm);	
		jshort sortd = env->CallShortMethod(tenv, mid_sortd);	
		jshort tblSubTpd = env->CallShortMethod(tenv, mid_tblSubTpd);
		jshort primDataTpd = env->CallShortMethod(tenv, mid_primDataTpd);

		te.set_table_size_hint(thint);
		if(dbt != -1)
			te.set_persist_type(dbt);
		if(idxt != -1)
			te.set_idx_type(idxt);
		if(ksz != -1)
			te.set_key_size_byte(ksz);
		if(logtp != -1)
			te.set_log_type(logtp);
		if(lsz != -1)
			te.set_log_size_mb(lsz);
		if(lst != -1)
			te.set_log_state(lst);
		if(acm != -1)
			te.set_autocommit_state(acm);
		if(tbltp != -1)
			te.set_table_type(tbltp);
		if(keytp != -1)
			te.set_key_type(keytp);
		if(sortm != -1)
			te.set_sort_method(sortm);
		if(sortd != -1)
			te.set_sort_dirction(sortd);
		if(tblSubTpd != -1)
			te.set_table_subtype(tblSubTpd);
		if(primDataTpd != -1)
			te.set_primitive_data_type(primDataTpd);
		te.set_config_vars();
	}

	swTable *swtbl = (swTable*)ptswtbl;
	swtbl->addIndex((char*)idxname, &te);
	env->ReleaseStringUTFChars(idxName, idxname);
}

JNIEXPORT void JNICALL Java_bangdb_SWTableImpl_initialize
  (JNIEnv *env, jobject obj, jlong ptswtbl)
{
	swTable *swtbl = (swTable*)ptswtbl;
	swtbl->initialize();
}

JNIEXPORT jint JNICALL Java_bangdb_SWTableImpl_put__Ljava_lang_String_2IIJ
  (JNIEnv *env, jobject obj, jstring str, jint len, jint iop, jlong ptswtbl)
{
	jboolean iscopy; 
	const char *_str = env->GetStringUTFChars(str, &iscopy);

	swTable *swtbl = (swTable*)ptswtbl;
	jint r = swtbl->put((char*)_str, (int)len, (insert_options)iop);

	env->ReleaseStringUTFChars(str, _str);
	return r;
}

JNIEXPORT jint JNICALL Java_bangdb_SWTableImpl_put__Ljava_lang_String_2ILjava_lang_String_2Ljava_lang_String_2J
  (JNIEnv *env, jobject obj, jstring str, jint len, jstring idx, jstring idxKey, jlong ptswtbl)
{
	jboolean iscopy; 
	const char *_str = env->GetStringUTFChars(str, &iscopy);
	const char *_idx = env->GetStringUTFChars(idx, &iscopy);
	const char *_idxkey = env->GetStringUTFChars(idxKey, &iscopy);

	swTable *swtbl = (swTable*)ptswtbl;
	jint r = swtbl->put((char*)_str, (int)len, (char*)_idx, (char*)_idxkey);

	env->ReleaseStringUTFChars(str, _str);
	env->ReleaseStringUTFChars(idx, _idx);
	env->ReleaseStringUTFChars(idxKey, _idxkey);

	return r;
}

JNIEXPORT jobject JNICALL Java_bangdb_SWTableImpl_scan__IJ
  (JNIEnv *env, jobject obj, jint period, jlong ptswtbl)
{
	swTable *swtbl = (swTable*)ptswtbl;
	resultset *rs = swtbl->scan((int)period);

	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
    	env->SetLongField(rsObject, fld, (jlong)rs);
    	return rsObject;
}

JNIEXPORT jobject JNICALL Java_bangdb_SWTableImpl_scan__IIJ
  (JNIEnv *env, jobject obj, jint period, jint lag, jlong ptswtbl)
{
	swTable *swtbl = (swTable*)ptswtbl;
	resultset *rs = swtbl->scan((int)period, (int)lag);

	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
    	env->SetLongField(rsObject, fld, (jlong)rs);
    	return rsObject;
}

JNIEXPORT jobject JNICALL Java_bangdb_SWTableImpl_scanFull
  (JNIEnv *env, jobject obj, jlong ptswtbl)
{
	swTable *swtbl = (swTable*)ptswtbl;
	resultset *rs = swtbl->scan_full();

	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
    	env->SetLongField(rsObject, fld, (jlong)rs);
    	return rsObject;
}

JNIEXPORT jobject JNICALL Java_bangdb_SWTableImpl_scanRemaining
  (JNIEnv *env, jobject obj, jlong fromTime, jint lag, jlong ptswtbl)
{
	swTable *swtbl = (swTable*)ptswtbl;
	resultset *rs = swtbl->scan_remaining((unsigned long)fromTime, (int)lag);

	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
    	env->SetLongField(rsObject, fld, (jlong)rs);
    	return rsObject;
}

JNIEXPORT void JNICALL Java_bangdb_SWTableImpl_close
  (JNIEnv *env, jobject obj, jlong ptswtbl)
{
	swTable *swtbl = (swTable*)ptswtbl;
	swtbl->Close();
	delete swtbl;
}

JNIEXPORT jlong JNICALL Java_bangdb_SWTableImpl_getConnection
  (JNIEnv *env, jobject obj, jlong ptswtbl)
{
	return (jlong)((swTable*)ptswtbl)->getConnection();
}

JNIEXPORT jlong JNICALL Java_bangdb_SWTableImpl_getActiveConnection
  (JNIEnv *env, jobject obj, jlong ptswtbl)
{
	return (jlong)((swTable*)ptswtbl)->getActiveConnection();
}

JNIEXPORT jlong JNICALL Java_bangdb_SWTableImpl_getPassiveConnection
  (JNIEnv *env, jobject obj, jlong ptswtbl)
{
	return (jlong)((swTable*)ptswtbl)->getPassiveConnection();
}

JNIEXPORT jint JNICALL Java_bangdb_SWTableImpl_getTTLSec
  (JNIEnv *env, jobject obj, jlong ptswtbl)
{
	return (jlong)((swTable*)ptswtbl)->getTTLSec();
}
