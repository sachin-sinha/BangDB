#include "bangdb_SWSlotCountImpl.h"
#include "swSlotCount.h"
using namespace bangdb;

/*
 * Class:     bangdb_SWSlotCountImpl
 * Method:    init
 * Signature: (IIS)J
 */
JNIEXPORT jlong JNICALL Java_bangdb_SWSlotCountImpl_init
 (JNIEnv *env, jobject obj, jint swTime, jint swExpiry, jshort swType)
{
	swSlotCount *swc = new swSlotCount((int)swTime, (int)swExpiry, (bangdb_count_type)swType);
	return (jlong)swc;
}

/*
 * Class:     bangdb_SWSlotCountImpl
 * Method:    add
 * Signature: (Ljava/lang/String;IJ)V
 */
JNIEXPORT void JNICALL Java_bangdb_SWSlotCountImpl_add
   (JNIEnv *env, jobject obj, jstring str, jint len, jlong ptswc)
{
	jboolean iscopy;
	const char *s = env->GetStringUTFChars(str, &iscopy);
	swSlotCount *swc = (swSlotCount*)ptswc;
	swc->add((char*)s, (int)len);
	env->ReleaseStringUTFChars(str, s);
}

/*
 * Class:     bangdb_SWSlotCountImpl
 * Method:    count
 * Signature: (J)I
 */
JNIEXPORT jint JNICALL Java_bangdb_SWSlotCountImpl_count__J
  (JNIEnv *env, jobject obj, jlong ptswc)
{
	return (jint)(((swSlotCount*)ptswc)->count());
}

/*
 * Class:     bangdb_SWSlotCountImpl
 * Method:    shutdown
 * Signature: (J)V
 */
JNIEXPORT void JNICALL Java_bangdb_SWSlotCountImpl_shutdown
  (JNIEnv *env, jobject obj, jlong ptswc)
{
	swSlotCount *swc = (swSlotCount*)ptswc;
	swc->Close();
	delete swc;
}
/*
 * Class:     bangdb_SWSlotCountImpl
 * Method:    count
 * Signature: (IJ)I
 */
JNIEXPORT jint JNICALL Java_bangdb_SWSlotCountImpl_count__IJ
  (JNIEnv *env, jobject obj, jint span, jlong ptswc)
{
	return (jint)(((swSlotCount*)ptswc)->count(span));
}

/*
 * Class:     bangdb_SWSlotCountImpl
 * Method:    list
 * Signature: (IJ)[I
 */
JNIEXPORT jintArray JNICALL Java_bangdb_SWSlotCountImpl_list
  (JNIEnv *env, jobject obj, jint span, jlong ptswc)
{
	int *l, size;
	if(((swSlotCount*)ptswc)->list(span, &l, &size) < 0)
		return NULL;
	if(size == 0)
		return NULL;
	jintArray jl = env->NewIntArray(size);
	env->SetIntArrayRegion(jl, 0, size, (const jint*)l);
	delete[] l;
	return jl;
}

/*
 * Class:     bangdb_SWSlotCountImpl
 * Method:    foldSlots
 * Signature: (J)V
 */
JNIEXPORT void JNICALL Java_bangdb_SWSlotCountImpl_foldSlots
  (JNIEnv *env, jobject obj, jlong ptswc)
{
	((swSlotCount*)ptswc)->foldSlots();
}

/*
 * Class:     bangdb_SWSlotCountImpl
 * Method:    reset
 * Signature: (J)V
 */
JNIEXPORT void JNICALL Java_bangdb_SWSlotCountImpl_reset
  (JNIEnv *env, jobject obj, jlong ptswc)
{
	((swSlotCount*)ptswc)->reset();
}

