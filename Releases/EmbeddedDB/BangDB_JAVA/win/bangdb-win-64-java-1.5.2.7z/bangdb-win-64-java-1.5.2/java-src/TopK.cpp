#include "bangdb_TopKImpl.h"
#include "topk.h"
using namespace bangdb;

JNIEXPORT jlong JNICALL Java_bangdb_TopKImpl_init
  (JNIEnv *env, jobject obj, jstring topkName, jint swSize, jint k, jint desc, jstring uniqueBy)
{
	jboolean iscopy;
	const char *topkname = env->GetStringUTFChars(topkName, &iscopy);
	const char *uniqueby = env->GetStringUTFChars(uniqueBy, &iscopy);

	topk *tk = new topk((char*)topkname, swSize, k, desc, (char*)uniqueby);

	env->ReleaseStringUTFChars(topkName, topkname);
	env->ReleaseStringUTFChars(uniqueBy, uniqueby);

	return (jlong)tk;
}

JNIEXPORT void JNICALL Java_bangdb_TopKImpl_put
  (JNIEnv *env, jobject obj, jlong score, jstring str, jint len, jstring uniqueBy, jlong pttopk)
{
	jboolean iscopy;
	const char *_str = env->GetStringUTFChars(str, &iscopy);
	const char *uniqueby = env->GetStringUTFChars(uniqueBy, &iscopy);

	topk *tk = (topk*)pttopk;
	tk->put((long)score, (char*)_str, len, (char*)uniqueby);

	env->ReleaseStringUTFChars(str, _str);
	env->ReleaseStringUTFChars(uniqueBy, uniqueby);
}

JNIEXPORT jstring JNICALL Java_bangdb_TopKImpl_getTopKJson
  (JNIEnv *env, jobject obj, jint k, jlong pttopk)
{
	topk *tk = (topk*)pttopk;
	char *str = tk->getTopKJson((int)k);
	jstring jstr = env->NewStringUTF(str);
	delete[] str;
	return jstr;
}

JNIEXPORT jobject JNICALL Java_bangdb_TopKImpl_getTopK
  (JNIEnv *env, jobject obj, jint k, jlong pttopk)
{
	resultset *rs = ((topk*)pttopk)->getTopK((int)k);
	
	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
    	env->SetLongField(rsObject, fld, (jlong)rs);
    	return rsObject;
}

JNIEXPORT void JNICALL Java_bangdb_TopKImpl_close
  (JNIEnv *env, jobject obj, jlong pttopk)
{
	topk *tk = (topk*)pttopk;
	tk->Close();
	delete tk;
}
