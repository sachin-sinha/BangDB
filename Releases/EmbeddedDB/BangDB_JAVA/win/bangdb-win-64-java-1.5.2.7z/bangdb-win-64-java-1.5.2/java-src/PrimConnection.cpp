#include "bangdb_PrimConnectionImpl.h"
#include "primConnection.h"
using namespace bangdb;

JNIEXPORT jobject JNICALL Java_bangdb_PrimConnectionImpl_get__IJ
  (JNIEnv *env, jobject obj, jint key, jlong ptprimconn)
{
	int val = 0;
	if(((primConnection *) ptprimconn)->get(key, &val) < 0)
		return NULL;
	
	jclass LongCls = env->FindClass("Ljava/lang/Integer;");
	jmethodID jmid = env->GetMethodID(LongCls, "<init>","(I)V");

	//create an Long Object with the long return value
	jobject LongObj = env->NewObject(LongCls,jmid,val);
	
	return LongObj;
}

JNIEXPORT jobject JNICALL Java_bangdb_PrimConnectionImpl_get__JJ
  (JNIEnv *env, jobject obj, jlong key, jlong ptprimconn)
{
	long val = 0;
	if(((primConnection *) ptprimconn)->get((LONG_T)key, (LONG_T*)&val) < 0)
		return NULL;
	
	jclass LongCls = env->FindClass("Ljava/lang/Long;");
	jmethodID jmid = env->GetMethodID(LongCls, "<init>","(J)V");

	//create an Long Object with the long return value
	jobject LongObj = env->NewObject(LongCls,jmid,val);
	
	return LongObj;
}

JNIEXPORT jobject JNICALL Java_bangdb_PrimConnectionImpl_get__Ljava_lang_String_2J
  (JNIEnv *env, jobject obj, jstring key, jlong ptprimconn)
{
	jboolean iscopy;
	long val = 0;
    	primConnection *conn = (primConnection *) ptprimconn;
    	const char * keychar = env->GetStringUTFChars(key, &iscopy);

	if(((primConnection *) ptprimconn)->get((char*)keychar, (LONG_T*)&val) < 0)
		return NULL;

	env->ReleaseStringUTFChars(key, keychar);

	jclass LongCls = env->FindClass("Ljava/lang/Long;");
	jmethodID jmid = env->GetMethodID(LongCls, "<init>","(J)V");

	//create an Long Object with the long return value
	jobject LongObj = env->NewObject(LongCls,jmid,val);
	
	return LongObj;
}

JNIEXPORT jobject JNICALL Java_bangdb_PrimConnectionImpl_get___3BJ
  (JNIEnv *env, jobject obj, jbyteArray keyarr, jlong ptprimconn)
{
	jboolean iscopy;
	primConnection *conn = (primConnection *)ptprimconn;
	void *key = env->GetByteArrayElements(keyarr, &iscopy);
	jint len = env->GetArrayLength(keyarr);
	FDT fk; fk.data = key; fk.length = len;
	LONG_T val = 0;

	if(((primConnection *) ptprimconn)->get(&fk, &val) < 0)
		return NULL;

	env->ReleaseByteArrayElements(keyarr, (jbyte*)key, 0);
	
	jclass LongCls = env->FindClass("Ljava/lang/Long;");
	jmethodID jmid = env->GetMethodID(LongCls, "<init>","(J)V");

	//create an Long Object with the long return value
	jobject LongObj = env->NewObject(LongCls,jmid,val);
	
	return LongObj;
}

JNIEXPORT jlong JNICALL Java_bangdb_PrimConnectionImpl_put__IISJ
  (JNIEnv *env, jobject obj, jint key, jint val, jshort flag, jlong ptprimconn)
{
	return ((primConnection*)ptprimconn)->put(key, val, (insert_options)flag);
}

JNIEXPORT jlong JNICALL Java_bangdb_PrimConnectionImpl_put__JJSJ
  (JNIEnv *env, jobject obj, jlong key, jlong val, jshort flag, jlong ptprimconn)
{
	return ((primConnection*)ptprimconn)->put((LONG_T)key, (LONG_T)val, (insert_options)flag);
}

JNIEXPORT jlong JNICALL Java_bangdb_PrimConnectionImpl_put__Ljava_lang_String_2JSJ
  (JNIEnv *env, jobject obj, jstring key, jlong val , jshort flag, jlong ptprimconn)
{
	jboolean iscopy;
	const char * keychar = env->GetStringUTFChars(key, &iscopy);
	jlong retval = ((primConnection*)ptprimconn)->put((char*)keychar, val, (insert_options)flag);
	env->ReleaseStringUTFChars(key, keychar);
	return retval;
}

JNIEXPORT jlong JNICALL Java_bangdb_PrimConnectionImpl_put___3BJSJ
  (JNIEnv *env, jobject obj, jbyteArray keyarr, jlong val, jshort flag, jlong ptprimconn)
{
	jboolean iscopy;
	void *key = env->GetByteArrayElements(keyarr, &iscopy);
	jint len = env->GetArrayLength(keyarr);
	FDT k;
	k.data = key;
	k.length = len;
	jlong retval = ((primConnection*)ptprimconn)->put(&k, val, (insert_options)flag);
	env->ReleaseByteArrayElements(keyarr, (jbyte*)key, 0);
	return retval;
}

JNIEXPORT jlong JNICALL Java_bangdb_PrimConnectionImpl_del__JJ
  (JNIEnv *env, jobject obj, jlong key, jlong ptprimconn)
{
	return ((primConnection*)ptprimconn)->del((LONG_T)key);
}

JNIEXPORT jlong JNICALL Java_bangdb_PrimConnectionImpl_del__Ljava_lang_String_2J
(JNIEnv *env, jobject obj, jstring key, jlong ptprimconn)
{
    	jboolean iscopy;
    	primConnection *conn = (primConnection *) ptprimconn;
    	const char * keychar = env->GetStringUTFChars(key, &iscopy);
    	jlong r = conn->del((char*)keychar);
    	env->ReleaseStringUTFChars(key, keychar);

    	return r;
}

JNIEXPORT jlong JNICALL Java_bangdb_PrimConnectionImpl_del___3BJ
(JNIEnv *env, jobject obj, jbyteArray keyarr, jlong ptprimconn)
{
	jboolean iscopy;
	primConnection *conn = (primConnection *)ptprimconn;
	void *key = env->GetByteArrayElements(keyarr, &iscopy);
	jint klen = env->GetArrayLength(keyarr);
	FDT fk; fk.data = key; fk.length = klen;
	jlong r = conn->del(&fk);
	env->ReleaseByteArrayElements(keyarr, (jbyte*)key, 0);

	return r;
}

JNIEXPORT jobject JNICALL Java_bangdb_PrimConnectionImpl_scan__JJJJ
  (JNIEnv *env, jobject obj, jlong skey, jlong ekey, jlong ptprimconn, jlong pscanf)
{
	resultset *rs = ((primConnection*)ptprimconn)->scan((LONG_T)skey, (LONG_T)ekey, (scan_filter*)pscanf);

	if(rs == NULL)
    		return NULL;
    
    	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
    	env->SetLongField(rsObject, fld, (jlong)rs);
    	return rsObject;
}


JNIEXPORT jobject JNICALL Java_bangdb_PrimConnectionImpl_scan__Ljava_lang_String_2ILjava_lang_String_2IJJ
 (JNIEnv *env, jobject obj, jstring skey, jint sklen, jstring ekey, jint eklen, jlong ptprimconn, jlong pscanf)
{
	primConnection *conn = (primConnection *)ptprimconn;
	const char *start_key = NULL, *end_key = NULL;
	FDT sk, ek;

	if(skey != NULL)
	{
		start_key = env->GetStringUTFChars(skey, 0);
		sk.data = (void*)start_key; sk.length = sklen;
	}
	if(ekey != NULL)
	{
		end_key = env->GetStringUTFChars(ekey, 0);
		ek.data = (void*)end_key; ek.length = eklen;
	}

    	resultset *rs = conn->scan(skey ? &sk : NULL, ekey ? &ek : NULL, (scan_filter*)pscanf);
    
	if(skey != NULL)
	{
    		env->ReleaseStringUTFChars(skey, start_key);
	}
	if(ekey != NULL)
	{
    		env->ReleaseStringUTFChars(ekey, end_key);
	}
    
    	if(rs == NULL)
    		return NULL;
    
    	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
    	env->SetLongField(rsObject, fld, (jlong)rs);
    	return rsObject;
}

JNIEXPORT jobject JNICALL Java_bangdb_PrimConnectionImpl_scan___3B_3BJJ
(JNIEnv *env, jobject obj, jbyteArray skey, jbyteArray ekey, jlong ptprimconn, jlong pscanf)
{
	primConnection *conn = (primConnection *)ptprimconn;
	void *start_key = NULL, *end_key = NULL;
	jint start_key_len = 0, end_key_len = 0;
	FDT fk, fv;

	if(skey != NULL)
	{
		start_key = env->GetByteArrayElements(skey, 0);
		start_key_len = env->GetArrayLength(skey);
		fk.data = start_key; fk.length = start_key_len;
	}
	if(ekey != NULL)
	{
		end_key = env->GetByteArrayElements(ekey, 0);
		end_key_len = env->GetArrayLength(ekey);
		fv.data = end_key; fv.length = end_key_len;
	}
	
	resultset *rs = conn->scan(skey ? &fk : NULL, ekey ? &fv : NULL, (scan_filter*)pscanf);
	
	if(skey != NULL)
		env->ReleaseByteArrayElements(skey, (jbyte*)start_key, 0);
	if(ekey != NULL)
		env->ReleaseByteArrayElements(ekey, (jbyte*)end_key, 0);
	
	if(rs == NULL)
		return NULL;
	
	jclass rsClass = env->FindClass("bangdb/ResultSetImpl");
    	jfieldID fld = env->GetFieldID(rsClass, "ptrs", "J");
    	jobject rsObject = env->AllocObject(rsClass);
    
   	 env->SetLongField(rsObject, fld, (jlong)rs);
   	 return rsObject;
}

JNIEXPORT jlong JNICALL Java_bangdb_PrimConnectionImpl_count__JJJJ
  (JNIEnv *env, jobject obj, jlong skey, jlong ekey, jlong pscanf, jlong ptprimconn)
{
	return ((primConnection*)ptprimconn)->count((LONG_T)skey, (LONG_T)ekey, (scan_filter*)pscanf);
}

JNIEXPORT jlong JNICALL Java_bangdb_PrimConnectionImpl_count__Ljava_lang_String_2ILjava_lang_String_2IJJ
  (JNIEnv *env, jobject obj, jstring skey, jint skeylen, jstring ekey, jint ekeylen, jlong pscanf, jlong ptprimconn)
{
	primConnection *conn = (primConnection *)ptprimconn;
	const char *start_key = NULL, *end_key = NULL;
	FDT sk, ek;

	if(skey != NULL)
	{
		start_key = env->GetStringUTFChars(skey, 0);
		sk.data = (void*)start_key; sk.length = skeylen;
	}
	if(ekey != NULL)
	{
		end_key = env->GetStringUTFChars(ekey, 0);
		ek.data = (void*)end_key; ek.length = ekeylen;
	}

	jlong ncount = conn->count(skey ? &sk : NULL, ekey ? &ek : NULL, (scan_filter*)pscanf);
    
	if(skey != NULL)
	{
    		env->ReleaseStringUTFChars(skey, start_key);
	}
	if(ekey != NULL)
	{
	    	env->ReleaseStringUTFChars(ekey, end_key);
	}
    
    	return ncount;
}

JNIEXPORT jlong JNICALL Java_bangdb_PrimConnectionImpl_count___3B_3BJJ
  (JNIEnv *env, jobject obj, jbyteArray skey, jbyteArray ekey, jlong pscanf, jlong ptprimconn)
{
	primConnection *conn = (primConnection *)ptprimconn;
	void *start_key = NULL, *end_key = NULL;
	jint start_key_len = 0, end_key_len = 0;
	FDT fk, fv;

	if(skey != NULL)
	{
		start_key = env->GetByteArrayElements(skey, 0);
		start_key_len = env->GetArrayLength(skey);
		fk.data = start_key; fk.length = start_key_len;
	}
	if(ekey != NULL)
	{
		end_key = env->GetByteArrayElements(ekey, 0);
		end_key_len = env->GetArrayLength(ekey);
		fv.data = end_key; fv.length = end_key_len;
	}

	jlong ncount = conn->count(skey ? &fk : NULL, ekey ? &fv : NULL, (scan_filter*)pscanf);
	
	if(skey != NULL)
		env->ReleaseByteArrayElements(skey, (jbyte*)start_key, 0);
	if(ekey != NULL)
		env->ReleaseByteArrayElements(ekey, (jbyte*)end_key, 0);
	
	return ncount;
}

JNIEXPORT jlong JNICALL Java_bangdb_PrimConnectionImpl_count__J
  (JNIEnv *env, jobject obj, jlong ptprimconn)
{
	primConnection *conn = (primConnection *)ptprimconn;
	return conn->count();
}

JNIEXPORT void JNICALL Java_bangdb_PrimConnectionImpl_setAutoCommit
  (JNIEnv *nv, jobject obj, jboolean flag, jlong ptprimconn)
{
	primConnection *conn = (primConnection *)ptprimconn;
	conn->set_autocommit(flag);
}

JNIEXPORT jint JNICALL Java_bangdb_PrimConnectionImpl_closeConnection 
(JNIEnv *env, jobject obj, jlong ptprimconn)
{
    primConnection *conn = (primConnection *) ptprimconn;
    jint ret = (jint)conn->closeconnection();
    delete conn;
    return ret;
}

