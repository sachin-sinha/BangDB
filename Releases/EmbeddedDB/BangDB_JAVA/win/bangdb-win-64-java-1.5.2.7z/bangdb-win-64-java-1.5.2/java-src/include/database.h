/*
 *  database.h
 *
 *  Author: sachin sinha
 *  bangdbwin library
 *
 *  Copyright (C) 2012 IQLECT All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are
 *  met:
 *
 *      * Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *      * Redistributions in binary form must reproduce the above
 *  copyright notice, this list of conditions and the following disclaimer
 *  in the documentation and/or other materials provided with the
 *  distribution.
 *
 *      * The names of its contributors may not be used to endorse or
 *  promote products derived from this software without specific prior
 *  written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef _DATABASE_H_
#define _DATABASE_H_

#include "table.h"
#include "wideTable.h"
#include "tableenv.h"
#include "bangdbtxn.h"

namespace bangdb
{

class table;
class wideTable;
class bangdb_txn;

class database
{
private:
	HANDLE _db;
	char *_dbname;
public:
	database(const char *databasename, const char *configpath = NULL, db_transaction_type transaction_type = DB_TRANSACTION_NONE, const char *dbpath = NULL, const char *dblogpath = NULL, bool _repl_done = false);

	table* gettable(char *name, bangdb_open_type openflag = OPENCREATE, table_env *tenv=NULL);

	wideTable* getWideTable(char *name, bangdb_open_type openflag = OPENCREATE, table_env *tenv=NULL);

	table* getPrimitiveTable(char *name, bangdb_primitive_data_type dataType = PRIMITIVE_LONG, bangdb_open_type openflag = OPENCREATE, table_env *tenv=NULL);

	void begin_transaction(bangdb_txn *txn);

	long long commit_transaction(bangdb_txn *txn);

	void abort_transaction(bangdb_txn *txn);

	void closedatabase(bangdb_close_type flag = DEFAULT);

	int closetable(table *tbl, bangdb_close_type flag = DEFAULT);

	int closetable(wideTable *tbl, bangdb_close_type tblclose = DEFAULT);

	const char *getdbname();

	void cleanup();

	~database();

	friend class swTable;
};
}
#endif