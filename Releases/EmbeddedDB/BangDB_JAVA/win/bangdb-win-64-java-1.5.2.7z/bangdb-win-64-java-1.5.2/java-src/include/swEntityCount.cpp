#include "swEntityCount.h"
namespace bangdb
{
swEntityCount::swEntityCount(char *entityName, int swTime, int swExpiry, int nEntity)
{
	_swec = CreateSWEntityCount(entityName, swTime, swExpiry, nEntity);
}

int swEntityCount::init()
{
	return InitSWEntityCount(_swec);
}

int swEntityCount::add(char *entityName, char *s, int len)
{
	return AddSWEntity(_swec, entityName, s, len);
}

void swEntityCount::add_create(char *entityName, char *s, int len, bangdb_window_type swType, bangdb_count_type countType)
{
	AddCreateSWEntity(_swec, entityName, strlen(entityName), s, len, swType, countType);
}

void swEntityCount::add_create(char *entityName, int EntityNameLen, char *s, int len, bangdb_window_type swType, bangdb_count_type countType)
{
	AddCreateSWEntity(_swec, entityName, EntityNameLen, s, len, swType, countType);
}

int swEntityCount::count(char *entityName)
{
	return CountSWEntity(_swec, entityName);
}

int swEntityCount::count(char *entityName, int span)
{
	return CountSpanEntity(_swec, entityName, span);
}

//returns json string containing list of all the counts for entities and overall count
//user should free the return memory using freeByte()
char* swEntityCount::list_count_json()
{
	char *list = NULL;
	ListCountSWEntity(_swec, &list);
	return list;
}

//returns items which have count greater than zero
//user should free the return memory using freeByte()
char *swEntityCount::list_count_str()
{
	char *list = NULL;
	ListCount2SWEntity(_swec, &list);
	return list;
}

void swEntityCount::createEntity(char *name, bangdb_window_type swType, bangdb_count_type countType)
{
	CreateEntitySW(_swec, name, strlen(name), swType, countType);
}

void swEntityCount::createEntity(char *name, int namelen, bangdb_window_type swType, bangdb_count_type countType)
{
	CreateEntitySW(_swec, name, namelen, swType, countType);
}

void swEntityCount::removeEntity(char *name)
{
	RemoveEntitySW(_swec, name);
}

bool swEntityCount::shouldExit()
{
	return ShouldExitSWEntity(_swec) == 0 ? false : true;
}

void swEntityCount::shutdown()
{
	ShutDownSWEntity(_swec);
	FreeHandle(&_swec);
}

swEntityCount::~swEntityCount()
{

}
}