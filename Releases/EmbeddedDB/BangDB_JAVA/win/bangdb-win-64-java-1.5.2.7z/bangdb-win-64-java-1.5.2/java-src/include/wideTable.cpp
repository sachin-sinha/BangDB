#include "wideTable.h"
namespace bangdb
{
wideTable::wideTable(HANDLE wtbl, char *name)
{
	_wtbl = wtbl;
	tblName = Strcpy(name);
}

int wideTable::addIndex_str(char *idx_name, int idx_size, bool allowDuplicates)
{
	return AddIndex_Str(_wtbl, idx_name, idx_size, allowDuplicates);
}

int wideTable::addIndex_num(char *idx_name, bool allowDuplicates)
{
	return AddIndex_Num(_wtbl, idx_name, allowDuplicates);
}

int wideTable::addIndex(char *idx_name, table_env *tenv)
{
	return AddIndex(_wtbl, idx_name, tenv->_tenv);
}

int wideTable::dropIndex(char *idx_name)
{
	return DropIndex(_wtbl, idx_name);
}

wideConnection* wideTable::getconnection()
{
	HANDLE wc = GetWideConnection(_wtbl);
	if(!wc)
		return NULL;
	return new wideConnection(wc);
}

int wideTable::closeAllConnections()
{
	return CloseAllWideConnections(_wtbl);
}

int wideTable::dumpdata(bool optimistics)
{
	return WideDumpData(_wtbl);
}

char* wideTable::getname()
{
	return GetWideTableName(_wtbl);
}

int wideTable::getindextype()
{
	return GetWideIndexType(_wtbl);
}

int wideTable::closetable(bangdb_close_type tableclose)
{
	int r = CloseThisWideTable(_wtbl, tableclose);
	FreeHandle(&_wtbl);
	delete[] tblName;
	return r;
}

wideTable::~wideTable()
{

}
}