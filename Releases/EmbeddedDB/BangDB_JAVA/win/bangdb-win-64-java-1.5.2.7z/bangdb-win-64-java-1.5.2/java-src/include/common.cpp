#include "common.h"
namespace bangdb
{
static void err_print(int errnoflag, int error, const char *fmt, va_list ap)
{
	int		errno_save, n;
    char    buf[MAXLINE+1];

	errno_save = errno;		/* value caller might want printed */

    vsnprintf_s(buf, MAXLINE, MAXLINE, fmt, ap);

	n = (int)strlen(buf);

    if (errnoflag)
       _snprintf_s(buf+n, n, MAXLINE-n, ": %d",errno_save);
    strcat_s(buf, "\n");

	
	fflush(stdout);		
	fputs(buf, stderr);
	fflush(stderr);
	
	return;
}


void err_out(const char *fmt, ...)
{
    va_list     ap;

    va_start(ap, fmt);
    err_print(1, errno, fmt, ap);
    va_end(ap);
}

void err_exit(const char *fmt, ...)
{
    va_list     ap;

    va_start(ap, fmt);
    err_print(1, errno, fmt, ap);
    va_end(ap);
    exit(1);
}

char *Strcpy(char *data)
{
	int l = (int)strlen(data);
	char *v = new char[l+1];
	memcpy(v, data, l);
	v[l] = 0;
	return v;
}

char *Strcpy(char *data, int len)
{
	char *v = new char[len+1];
	memcpy(v, data, len);
	v[len] = 0;
	return v;
}

void bangdb_print_error(int errnum)
{
	return Bangdb_print_error(errnum);
}

//ensure that no method is called before this
void bangdb_print_last_error()
{
	return Bangdb_print_last_error();
}
}