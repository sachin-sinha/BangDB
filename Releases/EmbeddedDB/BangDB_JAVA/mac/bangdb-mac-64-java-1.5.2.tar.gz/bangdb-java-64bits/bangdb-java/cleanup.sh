rm bangdb.jar
rm libbangdbjava.so*
rm bangdb/*.class
