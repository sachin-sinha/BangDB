#!/bin/bash
EXE_NAME="java -cp .:../bangdb.jar -Djava.library.path="../" testbangdb.TestMain"

echo "$EXE_NAME  $1 $2 $3 $4"
$EXE_NAME  $1 $2 $3 $4

