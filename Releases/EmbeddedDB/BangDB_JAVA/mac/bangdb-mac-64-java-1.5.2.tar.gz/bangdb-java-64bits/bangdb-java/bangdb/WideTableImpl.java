package bangdb;

public class WideTableImpl implements WideTable {

   	public native int addIndex_str(String idx_name, int idx_size, boolean allowDuplicates, long ptwtb);

	public native int addIndex_num(String idx_name, boolean allowDuplicates, long ptwtb);

	public native int addIndex(String idx_name, TableEnv tenv, long ptwtb);

	public native int dropIndex(String idxName, long ptwtb);

	public native int closeAllConnections(long ptwtb);

    public native long init(String rname, short openflg, TableEnv tenv);
    public native String getname(long ptwtb);
    //public native int init(String dbdir, long ptwtb);
    public native WideConnection getconnection(long ptwtb);
    //public native int closeconnection(WideConnection conn, long ptwtb);
    public native void dumpdata(long ptwtb);
    public native int getindextype(long ptwtb);
    public native void printstats(long ptwtb);
    public native int closetable(long ptwtb, short tableclose);
    public native int simple_close(long ptwtb);  
    public long ptwtb;

    public WideTableImpl(String rname, short openflg, TableEnv tenv) {
        //ptwtb = init(rname, openflg, tenv);
    }
	@Override
	public int addIndex_str(String idx_name, int idx_size, boolean allowDuplicates) {
		return addIndex_str(idx_name, idx_size, allowDuplicates, ptwtb);
	}

	@Override
	public int addIndex_num(String idx_name, boolean allowDuplicates) {
		return addIndex_num(idx_name, allowDuplicates, ptwtb);
	}

	@Override
	public int addIndex(String idx_name, TableEnv tenv) {
		return addIndex(idx_name, tenv, ptwtb);
	}
	
	@Override
	public int dropIndex(String idxName) {
		return dropIndex(idxName, ptwtb);
	}

	@Override	
	public int closeAllConnections() {
		return closeAllConnections(ptwtb);
	}
 
    @Override
    public String getName() {
       return getname(ptwtb);
    }
   
    @Override
    public WideConnection getConnection() {
        return getconnection(ptwtb);
    }

    @Override  
    public void dumpData() {
        dumpdata(ptwtb);
    }

    @Override
    public int getIndexType() {
        return getindextype(ptwtb);
    }

    @Override  
    public int closeTable(DBClose tableClose) {
	if(tableClose == null)
		tableClose = DBClose.DEFAULT;
        return closetable(ptwtb, (short)tableClose.ordinal());
    }

    @Override
    public int simpleClose() {
	throw new UnsupportedOperationException("method not implemented");
       //return simple_close(ptwtb); 
    } 
  
}
