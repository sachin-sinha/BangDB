package bangdb;

public interface TopK {

	public void put(long score, String data, int datlen, String uniqueParam);

	public String getTopKJson(int k);
/* */
	public ResultSet getTopK(int k);
/* */
	public void close();
}
