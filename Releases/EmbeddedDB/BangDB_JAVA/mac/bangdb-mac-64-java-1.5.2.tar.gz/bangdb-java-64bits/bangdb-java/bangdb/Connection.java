package bangdb;

public interface Connection {
/*
	public Long getPrim(long key);

	public Long getPrim(String key);

	public Long getPrim(byte[] key);
*/
	public String getStr(long key);

	public byte[] getByte(long key);

	public int get(String key, DataVar dv);

	public int get(byte[] key, DataVar dv);

public int get(long key, DataVar dv);
	    
    	public String get(String key);

    	public byte[] get(byte[] key);

    	public String get(String key, Transaction txn);

   	public byte[] get(byte[] key, Transaction txn);

	public int get(long key, DataVar dv, Transaction txn);


/*
	public long put(long key, long val, InsertOptions flag);

	public long put(String key, long val, InsertOptions flag);

	public long put(byte[] key, long val, InsertOptions flag);
*/

	public long put(long key, String val, InsertOptions flag);

	public long put(long key, byte[] val, InsertOptions flag);
    
    	public long put(String key, DataVar val, InsertOptions flag);

	public long put(byte[] key, DataVar val, InsertOptions flag);

	public long put(String key, DataVar val, InsertOptions flag, Transaction txn);

	public long put(byte[] key, DataVar val, InsertOptions flag, Transaction txn);

    	public long put(byte[] key, byte[] val, InsertOptions flag);

    	public long put(String key, String val, InsertOptions flag);

    	public long put(String key, String val, InsertOptions flag, Transaction txn);

    	public long put(byte[] key, byte[] val, InsertOptions flag, Transaction txn);

	public long put(long key, byte[] val, InsertOptions flag, Transaction txn);


	public long del(long key);
        
    	public long del(String key);

    	public long del(byte[] key); 

    	public long del(String key, Transaction txn);

    	public long del(byte[] key, Transaction txn);  

	public long del(long key, Transaction txn);
  
	
	public ResultSet scan(long skey, long ekey, ScanFilter sf);
    
    	public ResultSet scan(String skey, String ekey, ScanFilter sf);   

	public ResultSet scan(byte[] skey, byte[] ekey, ScanFilter sf);

    	public ResultSet scan(String skey, String ekey, Transaction txn, ScanFilter sf);   
    
    	public ResultSet scan(byte[] skey, byte[] ekey, Transaction txn, ScanFilter sf);

	public ResultSet scan(long skey, long ekey, Transaction txn, ScanFilter sf);

public ResultSet scan(String skey, String ekey, ScanFilter sf, DataVar dv);

public ResultSet scan(byte[] skey, byte[] ekey, ScanFilter sf, DataVar dv);

public ResultSet scan(long skey, long ekey, ScanFilter sf, DataVar dv);

public ResultSet scan(String skey, String ekey, Transaction txn, ScanFilter sf, DataVar dv);

public ResultSet scan(byte[] skey, byte[] ekey, Transaction txn, ScanFilter sf, DataVar dv);

public ResultSet scan(long skey, long ekey, Transaction txn, ScanFilter sf, DataVar dv);
    
  
	public long count(long skey, long ekey, ScanFilter sf);

    	public long count(String skey, String ekey, ScanFilter sf);

    	public long count(byte[] skey, byte[] ekey, ScanFilter sf);

    	public long count();


    	public void setAutoCommit(boolean flag);                    

    	public int closeConnection();
}
