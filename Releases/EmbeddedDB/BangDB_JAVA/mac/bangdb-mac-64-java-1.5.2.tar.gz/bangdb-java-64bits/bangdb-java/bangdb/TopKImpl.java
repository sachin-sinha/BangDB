package bangdb;

public class TopKImpl implements TopK {

	public native long init(String topkName, int swSizeSec, int k, int desc, String uniqueBy);

	public native void put(long score, String data, int datlen, String uniqueParam, long pttopk);

	public native String getTopKJson(int k, long pttopk);

	public native ResultSet getTopK(int k, long pttopk);

	public native void close(long pttopk);

	public long pttopk;

	public TopKImpl(String topkName, int swSizeSec, int k, boolean desc, String uniqueBy) {
		pttopk = init(topkName, swSizeSec, k, desc ? 1 : 0, uniqueBy);
	}

	@Override
	public void put(long score, String data, int datlen, String uniqueParam) {
		put(score, data, datlen, uniqueParam, pttopk);
	}

	@Override
	public String getTopKJson(int k) {
		return getTopKJson(k, pttopk);
	}

	@Override
	public ResultSet getTopK(int k) {
		return getTopK(k, pttopk);
	}

	@Override
	public void close() {
		close(pttopk);
	}
}
