package bangdb;

public interface ResultSet {

/* new API */		
	public void addDoc(ResultSetImpl rs, String orderBy);

	public void add(ResultSetImpl rs);

	public void append(ResultSetImpl rs);

	public void intersect(ResultSetImpl rs);

	public String getNextKeyStr();

	public String getNextValStr();

	public void beginReverse();
/* eof - new API */

	public byte[] getNextKey();

	public long getNextKeyLong();
	
	public byte[] getNextVal();

	public long getNextValLong();
	
	public boolean hasNext();
	
	public void moveNext();
	
	public int count();
	
	public void begin();
	
	public void clear();

	public boolean moreDataToCome();

	public byte[] lastEvaluatedKey();

	public long lastEvaluatedKeyLong();

	public byte[] searchValue(String key);

	public byte[] searchValue(byte[] key);

	public int size();

}
