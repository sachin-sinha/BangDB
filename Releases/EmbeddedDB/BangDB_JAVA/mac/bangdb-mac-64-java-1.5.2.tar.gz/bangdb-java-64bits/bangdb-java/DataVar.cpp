#include "bangdb_DataVar.h"
#include "database.h"
using namespace bangdb;

JNIEXPORT jlong JNICALL Java_bangdb_DataVar_init
  (JNIEnv *env, jobject obj, jint size)
{
	DATA_VAR *dv = new DATA_VAR();
	dv->data_buf_len = size;
	dv->data_buf = new char[size];
	return (jlong)dv;
}

/*
 * Class:     bangdb_DataVar
 * Method:    getBuffer
 * Signature: (J)[B
 */
JNIEXPORT jbyteArray JNICALL Java_bangdb_DataVar_getBuffer
  (JNIEnv *env, jobject obj, jlong pdv) 
{
	DATA_VAR *dv = (DATA_VAR*)pdv;
	jbyteArray retv = env->NewByteArray(dv->data_len);
	env->SetByteArrayRegion(retv, 0, dv->data_len, (const jbyte*)dv->data_buf);
	return retv;
}

/*
 * Class:     bangdb_DataVar
 * Method:    setBuffer
 * Signature: ([BJ)V
 */
JNIEXPORT void JNICALL Java_bangdb_DataVar_setBuffer
  (JNIEnv *env, jobject obj, jbyteArray data, jlong pdv)
{
	DATA_VAR *dv = (DATA_VAR*)pdv;
	int buf_len = env->GetArrayLength(data);
	void *buf = env->GetByteArrayElements(data, 0);
	int _copy_len = dv->data_buf_len < buf_len ? dv->data_buf_len : buf_len;
	dv->data_len = _copy_len;
	memcpy(dv->data_buf, buf, _copy_len);
	env->ReleaseByteArrayElements(data, (jbyte*)buf, 0);
}

/*
 * Class:     bangdb_DataVar
 * Method:    getBufferLength
 * Signature: (J)I
 */
JNIEXPORT jint JNICALL Java_bangdb_DataVar_getBufferLength
  (JNIEnv *env, jobject obj, jlong pdv)
{
	return ((DATA_VAR*)pdv)->data_buf_len;
}

/*
 * Class:     bangdb_DataVar
 * Method:    setBufferLength
 * Signature: (IJ)V
 */
JNIEXPORT void JNICALL Java_bangdb_DataVar_setBufferLength
  (JNIEnv *env, jobject obj, jint buf_len, jlong pdv)
{
	((DATA_VAR*)pdv)->data_buf_len = buf_len;
}

/*
 * Class:     bangdb_DataVar
 * Method:    getDataLength
 * Signature: (J)I
 */
JNIEXPORT jint JNICALL Java_bangdb_DataVar_getDataLength
  (JNIEnv *env, jobject obj, jlong pdv)
{
	return ((DATA_VAR*)pdv)->data_len;
}

/*
 * Class:     bangdb_DataVar
 * Method:    setDataLength
 * Signature: (IJ)V
 */
JNIEXPORT void JNICALL Java_bangdb_DataVar_setDataLength
  (JNIEnv *env, jobject obj, jint dlen, jlong pdv)
{
	((DATA_VAR*)pdv)->data_len = dlen;
}

/*
 * Class:     bangdb_DataVar
 * Method:    getDataOffset
 * Signature: (J)I
 */
JNIEXPORT jint JNICALL Java_bangdb_DataVar_getDataOffset
  (JNIEnv *env, jobject obj, jlong pdv)
{
	return ((DATA_VAR*)pdv)->data_offt;
}

/*
 * Class:     bangdb_DataVar
 * Method:    setDataOffset
 * Signature: (IJ)V
 */
JNIEXPORT void JNICALL Java_bangdb_DataVar_setDataOffset
  (JNIEnv *env, jobject obj, jint dofft, jlong pdv)
{
	((DATA_VAR*)pdv)->data_offt = dofft;
}

/*
 * Class:     bangdb_DataVar
 * Method:    getErrorFlag
 * Signature: (J)I
 */
JNIEXPORT jint JNICALL Java_bangdb_DataVar_getErrorFlag
  (JNIEnv *env, jobject obj, jlong pdv)
{
	return ((DATA_VAR*)pdv)->flag;
}

/*
 * Class:     bangdb_DataVar
 * Method:    setErrorFlag
 * Signature: (IJ)V
 */
JNIEXPORT void JNICALL Java_bangdb_DataVar_setErrorFlag
  (JNIEnv *env, jobject obj, jint eflag, jlong pdv)
{
	((DATA_VAR*)pdv)->flag = eflag;
}

/*
 * Class:     bangdb_DataVar
 * Method:    reset
 * Signature: (J)V
 */
JNIEXPORT void JNICALL Java_bangdb_DataVar_reset
  (JNIEnv *env, jobject obj, jlong pdv)
{
	((DATA_VAR*)pdv)->reset();
}

/*
 * Class:     bangdb_DataVar
 * Method:    clear
 * Signature: (J)V
 */
JNIEXPORT void JNICALL Java_bangdb_DataVar_clear
  (JNIEnv *env, jobject obj, jlong pdv)
{
	DATA_VAR *dv = (DATA_VAR*)pdv;
	delete[] (char*)(dv->data_buf);
	delete dv;
}

