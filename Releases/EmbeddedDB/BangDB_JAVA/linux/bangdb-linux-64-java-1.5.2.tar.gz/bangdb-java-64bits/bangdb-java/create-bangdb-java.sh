#!/bin/sh


JAVA_DIR=$JAVA_HOME
LIB_NAME=libbangdbjava.so.1.5.2
JAR_NAME=bangdb.jar
echo "checking the base java dir..."
if [ -d $JAVA_DIR ]; then
echo "java home is $JAVA_DIR"
else
echo "could not find the JAVA_HOME set, either java is not installed or JAVA_HOME enc var is not set"
echo "either set the env var JAVA_HOME or edit the file(this file) to provide the right path in JAVA_DIR var"
fi

JNI_MD_DIR=linux
#JNI_MD_DIR=darwin

echo "cleaning up..."

if [ -f $JAR_NAME ]; then
rm bangdb.jar
fi
if [ -f $LIB_NAME ]; then
rm libbangdbjava.so*
fi
rm bangdb/*.class

echo "compiling java files..."
javac bangdb/BangDBCountType.java
javac bangdb/BangDBDataOpsFlag.java
javac bangdb/BangDBKeyType.java
javac bangdb/BangDBPrimitiveDataType.java
javac bangdb/BangDBSortDirection.java
javac bangdb/BangDBSortMethod.java
javac bangdb/BangDBTableType.java
javac bangdb/BangDBWindowType.java
javac bangdb/ConnectionImpl.java
javac bangdb/Connection.java
javac bangdb/DatabaseImpl.java
javac bangdb/Database.java
javac bangdb/DataVar.java
javac bangdb/DBAccess.java
javac bangdb/DBClose.java
javac bangdb/IndexType.java
javac bangdb/InsertOptions.java
javac bangdb/LogType.java
javac bangdb/PersistType.java
javac bangdb/ResultSetImpl.java
javac bangdb/ResultSet.java
javac bangdb/ScanFilter.java
javac bangdb/ScanLimitBy.java
javac bangdb/ScanOperator.java
javac bangdb/SWCountImpl.java
javac bangdb/SWCount.java
javac bangdb/SWEntityCountImpl.java
javac bangdb/SWEntityCount.java
javac bangdb/SWSlotCountImpl.java
javac bangdb/SWSlotCount.java
javac bangdb/SWTableImpl.java
javac bangdb/SWTable.java
javac bangdb/TableEnv.java
javac bangdb/TableImpl.java
javac bangdb/Table.java
javac bangdb/TableSizeHint.java
javac bangdb/TopKImpl.java
javac bangdb/TopK.java
javac bangdb/Transaction.java
javac bangdb/TransactionType.java
javac bangdb/WideConnectionImpl.java
javac bangdb/WideConnection.java
javac bangdb/WideTableImpl.java
javac bangdb/WideTable.java
javac bangdb/BangDBCommon.java
javac bangdb/PrimConnectionImpl.java
javac bangdb/PrimConnection.java
javac bangdb/BangDBTableSubType.java


echo "creating the headers..."

javah -jni bangdb.BangDBCountType
javah -jni bangdb.BangDBDataOpsFlag
javah -jni bangdb.BangDBKeyType
javah -jni bangdb.BangDBPrimitiveDataType
javah -jni bangdb.BangDBSortDirection
javah -jni bangdb.BangDBSortMethod
javah -jni bangdb.BangDBTableType
javah -jni bangdb.BangDBWindowType
javah -jni bangdb.ConnectionImpl
javah -jni bangdb.Connection
javah -jni bangdb.DatabaseImpl
javah -jni bangdb.Database
javah -jni bangdb.DataVar
javah -jni bangdb.DBAccess
javah -jni bangdb.DBClose
javah -jni bangdb.IndexType
javah -jni bangdb.InsertOptions
javah -jni bangdb.LogType
javah -jni bangdb.PersistType
javah -jni bangdb.ResultSetImpl
javah -jni bangdb.ResultSet
javah -jni bangdb.ScanFilter
javah -jni bangdb.ScanLimitBy
javah -jni bangdb.ScanOperator
javah -jni bangdb.SWCountImpl
javah -jni bangdb.SWCount
javah -jni bangdb.SWEntityCountImpl
javah -jni bangdb.SWEntityCount
javah -jni bangdb.SWSlotCountImpl
javah -jni bangdb.SWSlotCount
javah -jni bangdb.SWTableImpl
javah -jni bangdb.SWTable
javah -jni bangdb.TableEnv
javah -jni bangdb.TableImpl
javah -jni bangdb.Table
javah -jni bangdb.TableSizeHint
javah -jni bangdb.TopKImpl
javah -jni bangdb.TopK
javah -jni bangdb.Transaction
javah -jni bangdb.TransactionType
javah -jni bangdb.WideConnectionImpl
javah -jni bangdb.WideConnection
javah -jni bangdb.WideTableImpl
javah -jni bangdb.WideTable
javah -jni bangdb.BangDBCommon
javah -jni bangdb.PrimConnectionImpl
javah -jni bangdb.PrimConnection
javah -jni bangdb.BangDBTableSubType


echo "creating jar files..."
jar -cvf bangdb.jar bangdb/Database.class bangdb/Table.class bangdb/Connection.class bangdb/DatabaseImpl.class bangdb/TableImpl.class bangdb/ConnectionImpl.class bangdb/DBClose.class bangdb/PersistType.class bangdb/IndexType.class bangdb/LogType.class bangdb/ResultSet.class bangdb/ResultSetImpl.class bangdb/DBAccess.class bangdb/InsertOptions.class bangdb/TransactionType.class bangdb/Transaction.class bangdb/TableEnv.class bangdb/TableSizeHint.class bangdb/ScanFilter.class bangdb/ScanOperator.class bangdb/ScanLimitBy.class bangdb/WideTable.class bangdb/WideTableImpl.class bangdb/WideConnection.class bangdb/WideConnectionImpl.class bangdb/SWCount.class bangdb/SWCountImpl.class bangdb/SWSlotCount.class bangdb/SWSlotCountImpl.class bangdb/SWTable.class bangdb/SWTableImpl.class bangdb/SWEntityCount.class bangdb/SWEntityCountImpl.class bangdb/TopK.class bangdb/TopKImpl.class bangdb/BangDBWindowType.class bangdb/BangDBCountType.class bangdb/BangDBKeyType.class bangdb/BangDBSortMethod.class bangdb/BangDBSortDirection.class bangdb/BangDBTableType.class bangdb/BangDBDataOpsFlag.class bangdb/BangDBPrimitiveDataType.class bangdb/DataVar.class bangdb/BangDBCommon.class bangdb/PrimConnectionImpl.class bangdb/PrimConnection.class bangdb/BangDBTableSubType.class

echo "creating lib..."
g++ -DFILE_OFFSET_BITS=64 -fPIC -shared -o $LIB_NAME -O3 *.cpp -lbangdb -I$JAVA_DIR/include -I$JAVA_DIR/include/$JNI_MD_DIR -I/usr/local/include/bangdb


if [ -f $JAR_NAME ]; then
if [ -f $LIB_NAME ]; then
ln -sf $LIB_NAME libbangdbjava.so
ln -sf libbangdbjava.so libbangdbjava.so.0
echo "**************************************************"
echo "the files have been created successfully!"
echo "please go to the bangdb_java_bench dir to run few sample tests"
echo "**************************************************"
fi
else
echo "----------------------------------------------------------------------"
echo "there were some errors. please check if the java is installed and JAVA_HOME env var is set"
echo "----------------------------------------------------------------------"
fi

