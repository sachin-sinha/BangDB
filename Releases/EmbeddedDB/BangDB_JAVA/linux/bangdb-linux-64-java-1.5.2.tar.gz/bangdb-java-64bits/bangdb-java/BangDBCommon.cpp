#include "bangdb_BangDBCommon.h"
#include "database.h"

using namespace bangdb;

JNIEXPORT void JNICALL Java_bangdb_BangDBCommon_bangdbLogger
  (JNIEnv *env, jclass obj, jstring str)
{
	const char *_str = env->GetStringUTFChars(str, 0);
	bangdb_logger(_str);
	env->ReleaseStringUTFChars(str, _str);
}

JNIEXPORT void JNICALL Java_bangdb_BangDBCommon_bangdb_1lasterror
  (JNIEnv *env, jclass obj)
{
	bangdb_print_last_error();
}
