rm testbangdb/*.class
