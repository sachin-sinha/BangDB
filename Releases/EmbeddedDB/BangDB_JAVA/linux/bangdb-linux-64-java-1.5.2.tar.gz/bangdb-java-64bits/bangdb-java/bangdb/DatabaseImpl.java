package bangdb;

public class DatabaseImpl implements Database {
    public native long init(String databasename,String configPath, short transaction_type, String dbPath, String dbLogPath);
    public native Table gettable(String name, short openflag, TableEnv tenv, long ptdb);
    public native WideTable getwidetable(String name, short openflag, TableEnv tenv, long ptdb);
	public native Table getPrimitiveTable(String name, short dataType, short openflag, TableEnv tenv, long ptdb);
	public native int closeTable(WideTable tbl, short dbclose, long ptdb);
    public native long begin_transaction(long ptdb, long pttxn);
    public native long commit_transaction(long ptdb, long txn);
    public native void abort_transaction(long ptdb, long txn);
    public native void cleanup(long ptdb);
    public native String getdbname(long ptdb);
    public native int closetable(String rname, short tbclose, long ptdb);
    public native int closetable(Table tbl, short tbclose, long ptdb);
    public native void closedatabase(short dbclose, long ptdb);
    public long ptdb; 

    public DatabaseImpl(String databasename, String configPath, TransactionType transaction_type, String dbPath, String dbLogPath) {
         ptdb = init(databasename, configPath, (short)transaction_type.ordinal(), dbPath, dbLogPath);
    }
   
    @Override
    public Table getTable(String name, DBAccess openflag, TableEnv tenv) {
        return gettable(name, (short)openflag.ordinal(), tenv, ptdb); 
    }

	@Override
	public Table getPrimitiveTable(String name, BangDBPrimitiveDataType dataType, DBAccess openflag, TableEnv tenv) {
		return getPrimitiveTable(name, (short)dataType.ordinal(), (short)openflag.ordinal(), tenv, ptdb);
	}
	
	@Override
    	public int closeTable(WideTable tbl, DBClose dbclose) {
		if(dbclose == null)
			dbclose = DBClose.DEFAULT;
		return closeTable(tbl, (short)dbclose.ordinal(), ptdb);
	}

    @Override
    public WideTable getWideTable(String name, DBAccess openflag, TableEnv tenv)
    {
	return getwidetable(name, (short)openflag.ordinal(), tenv, ptdb);
    }

    @Override
    public void beginTransaction(Transaction txn) {
	txn.pttxn = begin_transaction(ptdb, txn.pttxn);
    }
 
    @Override
    public long commitTransaction(Transaction txn) {
	return commit_transaction(ptdb, txn.pttxn);
    }

    @Override
    public void abortTransaction(Transaction txn) {
	abort_transaction(ptdb, txn.pttxn);
    }
   
    @Override
    public int closeTable(Table tbl, DBClose dbclose ) {
        //return closetable(tbl, (short)dbclose.ordinal(), ptdb);
	if(dbclose == null)
		dbclose = DBClose.DEFAULT;
	return tbl.closeTable(dbclose);
    }
   
    @Override
    public int closeTable(String rname, DBClose tbclose) {
	throw new UnsupportedOperationException("method not implemented");
        //return closetable(rname, (short)tbclose.ordinal(), ptdb);
    } 
   
    @Override	
    public void cleanup () { 
       cleanup(ptdb);
    }

    @Override
    public String getDBName() {
      return getdbname(ptdb);
    }
   
    @Override
    public void closeDatabase(DBClose dbclose) {
	if(dbclose == null)
		dbclose = DBClose.DEFAULT;
	closedatabase((short) dbclose.ordinal(), ptdb);		
    } 
}
