package bangdb;

public class PrimConnectionImpl implements PrimConnection {

	public native Integer get(int key, long ptprimconn);

	public native Long get(long key, long ptprimconn);

	public native Long get(String key, long ptprimconn);

	public native Long get(byte[] key, long ptprimconn);

	public native long put(int key, int val, short flag, long ptprimconn);

	public native long put(long key, long val, short flag, long ptprimconn);

	public native long put(String key, long val, short flag, long ptprimconn);

	public native long put(byte[] key, long val, short flag, long ptprimconn);

	public native long del(long key, long ptprimconn);
        
	public native long del(String key, long ptprimconn);

    	public native long del(byte[] key, long ptprimconn);

	public native ResultSet scan(long skey, long ekey, long ptprimconn, long pscanf);
    
    	public native ResultSet scan(String skey, int skeylen, String ekey, int ekeylen, long ptconn, long pscanf);   

	public native ResultSet scan(byte[] skey, byte[] ekey, long ptconn, long pscanf);

	public native long count(long skey, long ekey, long pscanf, long ptprimconn);

    	public native long count(String skey, int skeylen, String ekey, int ekeylen, long pscanf, long ptprimconn);

    	public native long count(byte[] skey, byte[] ekey, long pscanf, long ptprimconn);

    	public native long count(long ptprimconn);

    	public native void setAutoCommit(boolean flag, long ptprimconn);                    

    	public native int closeConnection(long ptprimconn);

	public long ptprimconn;

	public PrimConnectionImpl(long _ptprimconn) {
		ptprimconn = _ptprimconn;
	}

	@Override 
	public Integer get(int key) {
		return get(key, ptprimconn); 
	}

	@Override 
	public Long get(long key) {
		return get(key, ptprimconn); 
	}

	@Override
	public Long get(String key) {
		return get(key, ptprimconn);
	}

	@Override
	public Long get(byte[] key) {
		return get(key, ptprimconn);
	}

	@Override
	public long put(int key, int val, InsertOptions flag) {
		return put(key, val, (short)flag.ordinal(), ptprimconn);
	}

	@Override
	public long put(long key, long val, InsertOptions flag) {
		return put(key, val, (short)flag.ordinal(), ptprimconn);
	}

	@Override
	public long put(String key, long val, InsertOptions flag) {
		return put(key, val, (short)flag.ordinal(), ptprimconn);
	}

	@Override
	public long put(byte[] key, long val, InsertOptions flag) {
		return put(key, val, (short)flag.ordinal(), ptprimconn);
	}

	@Override
	public long del(long key) {
		return del(key, ptprimconn);
	}

	@Override        
	public long del(String key) {
		return del(key, ptprimconn);
	}

	@Override
    	public long del(byte[] key) {
		return del(key, ptprimconn);
	}

	@Override
	public ResultSet scan(long skey, long ekey, ScanFilter sf) {
		//sf.setFilter();
		return scan(skey, ekey, ptprimconn, sf.pscanf);
	}

	@Override    
    	public ResultSet scan(String skey, String ekey, ScanFilter sf) {
		int skeylen = (skey == null)?0:skey.length();
		int ekeylen = (ekey == null)?0:ekey.length();
		//sf.setFilter();
		return scan(skey, skeylen, ekey, ekeylen, ptprimconn, sf.pscanf);  
	}

	@Override
	public ResultSet scan(byte[] skey, byte[] ekey, ScanFilter sf) {
		//sf.setFilter();
		return scan(skey, ekey, ptprimconn, sf.pscanf);
	}

	@Override
	public long count(long skey, long ekey, ScanFilter sf) {
		//sf.setFilter();
		return count(skey, ekey, sf.pscanf, ptprimconn);
	}

	@Override
    	public long count(String skey, String ekey, ScanFilter sf) {
		int skeylen = (skey == null)?0:skey.length();
		int ekeylen = (ekey == null)?0:ekey.length(); 
		//sf.setFilter();
		return count(skey, skeylen, ekey, ekeylen, sf.pscanf, ptprimconn);
	}

	@Override
    	public long count(byte[] skey, byte[] ekey, ScanFilter sf) {
		//sf.setFilter();
		return count(skey, ekey, sf.pscanf, ptprimconn);
	}

	@Override
    	public long count() {
		return count(ptprimconn);
	}

	@Override
    	public void setAutoCommit(boolean flag) {
		setAutoCommit(flag, ptprimconn);
	}                 

	@Override
    	public int closeConnection() {
		return closeConnection(ptprimconn);
	}
}
