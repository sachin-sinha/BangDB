package bangdb;

public interface PrimConnection {

	public Integer get(int key);

	public Long get(long key);

	public Long get(String key);

	public Long get(byte[] key);

	public long put(int key, int val, InsertOptions flag);

	public long put(long key, long val, InsertOptions flag);

	public long put(String key, long val, InsertOptions flag);

	public long put(byte[] key, long val, InsertOptions flag);

	public long del(long key);
        
	public long del(String key);

    	public long del(byte[] key);

	public ResultSet scan(long skey, long ekey, ScanFilter sf);
    
    	public ResultSet scan(String skey, String ekey, ScanFilter sf);   

	public ResultSet scan(byte[] skey, byte[] ekey, ScanFilter sf);

	public long count(long skey, long ekey, ScanFilter sf);

    	public long count(String skey, String ekey, ScanFilter sf);

    	public long count(byte[] skey, byte[] ekey, ScanFilter sf);

    	public long count();

    	public void setAutoCommit(boolean flag);                    

    	public int closeConnection();
}
