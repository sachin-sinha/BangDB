package bangdb;

public enum BangDBTableSubType {
	NON_ANALYTICAL_TABLE,
	SW_TABLE,
	SW_ENTITY_COUNT_TABLE,
	SW_TOPK_TABLE,
	TABLE_SUB_TYPE_INVALID;

	public static BangDBTableSubType fromInt(int e) {
		switch(e) {
			case 0:
				return NON_ANALYTICAL_TABLE;
			case 1:
				return SW_TABLE;
			case 2:
				return SW_ENTITY_COUNT_TABLE;
			case 3:
				return SW_TOPK_TABLE;
			case 4:
				return TABLE_SUB_TYPE_INVALID;
		}
		return TABLE_SUB_TYPE_INVALID;
	}

	public static int toInt(int ordinal)
	{
		switch(ordinal)
		{
			case 0:
				return 0;
			case 1:
				return 1;
			case 2:
				return 2;
			case 3:
				return 3;
			case 4:
				return -1;
		}
		return -1;
	}

}
