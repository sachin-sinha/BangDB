package bangdb;

import java.io.UnsupportedEncodingException;

public class ConnectionImpl implements Connection {
        public native byte[] get(String key, int keylen, long ptconn);
	public native byte[] get( byte[] key, long ptconn);
	public native byte[] get(String key, int keylen, long ptconn, long pttxn);
	public native byte[] get( byte[] key, long ptconn, long pttxn);

/* begining of new APIS */
	public native Long   getPrim(long key, long ptconn);
	public native Long   getPrim(String key, long ptconn);
	public native Long   getPrim(byte[] key, long ptconn);
	public native String   	getStr(long key, long ptconn);
	public native byte[]   	getByte(long key, long ptconn);
	public native int	get_dv(String key, long dv, long ptconn);
	public native int	get_dv(byte[] key, long dv, long ptconn);
	public native int	get_dv(long key, long dv, long ptconn, long pttxn);
	public native long put(String key, long val, short flag, long ptconn);
	public native long put(byte[] key, long val, short flag, long ptconn);
	public native long put(long key, String val, short flag, long ptconn);
	public native long put(long key, byte[] val, short flag, long ptconn);
	public native long put(long key, long val, short flag, long ptconn);
    	public native long put_dv(String key, long dv, short flag, long ptconn);
	public native long put_dv(byte[] key, long dv, short flag, long ptconn);
	public native long put_dv(String key, long dv, short flag, long ptconn, long pttxn);
	public native long put_dv(byte[] key, long dv, short flag, long ptconn, long pttxn);
	public native long del(long key, long ptconn);

	public native long del(long key, long ptconn, long pttxn);

	public native ResultSet scan(long skey, long ekey, long ptconn, long pscanf);

	public native ResultSet scan(long skey, long ekey, long ptconn, long pttxn, long pscanf);

	public native long count(long skey, long ekey, long pscanf, long ptconn);	
/* end of new APIS */

        public native long put(String key, int klen, String val, int vlen, short flag, long ptconn);
	public native long put(byte[] key, byte[] val, short flag, long ptconn);
	public native long put(String key, int klen, String val, int vlen, short flag, long ptconn, long pttxn);
	public native long put(byte[] key, byte[] val, short flag, long ptconn, long pttxn);

	public native long put(long key, byte[] val, short flag, long ptconn, long pttxn);

        public native long del(String key, int klen, long ptconn);
	public native long del(byte[] del, long ptconn);
	public native long del(String key, int klen, long ptconn, long pttxn);
	public native long del(byte[] del, long ptconn, long pttxn);
	
        public native ResultSet Scan(String skey, int skeylen, String ekey, int ekeylen, long ptconn, long pscanf);
        public native ResultSet Scan(byte[] skey, byte[] ekey, long ptconn, long pscanf);    
        public native ResultSet Scan(String skey, int skeylen, String ekey, int ekeylen, long ptconn, long pttxn , long pscanf);
	public native ResultSet Scan(byte[] skey, byte[] ekey, long ptconn, long pttxn, long pscanf);
        
        public native int closeconnection(long ptconn);

	public native long Count(String skey, int skeylen, String ekey, int ekeylen, long pscanf, long ptconn);

	public native long Count(byte[] skey, byte[] ekey, long pscanf, long ptconn);

    	public native long Count(long ptconn);

	public native void SetAutoCommit(boolean flag, long ptconn);

public native int get_dvar(long key, long pdv, long ptconn);

public native ResultSet Scan_dvar(String skey, int skeylen, String ekey, int ekeylen, long pscanf, long pdv, long ptconn);  

public native ResultSet Scan_dvar(byte[] skey, byte[] ekey, long pscanf, long pdv, long ptconn);

public native ResultSet Scan_dvar(long skey, long ekey, long pscanf, long pdv, long ptconn);

public native ResultSet Scan_dvar(String skey, int skeylen, String ekey, int ekeylen, long pttxn, long pscanf, long pdv, long ptconn);

public native ResultSet Scan_dvar(byte[] skey, byte[] ekey,  long pttxn, long pscanf, long pdv, long ptconn);

public native ResultSet Scan_dvar(long skey, long ekey, long pttxn, long pscanf, long pdv, long ptconn);

        public long ptconn;
        
        public ConnectionImpl(long conn) {
            ptconn = conn;
        }
/*
	@Override 
	public Long getPrim(long key) {
		return getPrim(key, ptconn);
	}

	@Override 
	public Long getPrim(String key) {
		return getPrim(key, ptconn);
	}

	@Override 
	public Long getPrim(byte[] key) {
		return getPrim(key, ptconn);
	}
*/
	@Override 
	public String getStr(long key) {
		return getStr(key, ptconn);
	}

	@Override 
	public byte[] getByte(long key) {
		return getByte(key, ptconn);
	}

	@Override 
	public int get(String key, DataVar dv) {
		return get_dv(key, dv.pdv, ptconn);
	}

	@Override 
	public int get(byte[] key, DataVar dv) {
		return get_dv(key, dv.pdv, ptconn);
	}

@Override
public int get(long key, DataVar dv, Transaction txn) {
	return get_dv(key, dv.pdv, ptconn, txn.pttxn);
}
/*
	@Override
	public long put(long key, long val, InsertOptions flag) {
		return put(key, val, (short)flag.ordinal(), ptconn);
	}
	
	@Override
	public long put(String key, long val, InsertOptions flag) {
		return put(key, val, (short)flag.ordinal(), ptconn);
	}

	@Override
	public long put(byte[] key, long val, InsertOptions flag) {
		return put(key, val, (short)flag.ordinal(), ptconn);
	}
*/
	@Override
	public long put(long key, String val, InsertOptions flag) {
		return put(key, val, (short)flag.ordinal(), ptconn);
	}

	@Override
	public long put(long key, byte[] val, InsertOptions flag){
		return put(key, val, (short)flag.ordinal(), ptconn);
	}

	@Override    
    	public long put(String key, DataVar val, InsertOptions flag) {
		return put_dv(key, val.pdv, (short)flag.ordinal(), ptconn);
	}

	@Override
	public long put(byte[] key, DataVar val, InsertOptions flag) {
		return put_dv(key, val.pdv, (short)flag.ordinal(), ptconn);
	}

	@Override
	public long put(String key, DataVar val, InsertOptions flag, Transaction txn) {
		return put_dv(key, val.pdv, (short)flag.ordinal(), ptconn, txn.pttxn);
	}

	@Override
	public long put(byte[] key, DataVar val, InsertOptions flag, Transaction txn) {
		return put_dv(key, val.pdv, (short)flag.ordinal(), ptconn, txn.pttxn);
	}

	@Override
	public long del(long key) {
		return del(key, ptconn);
	}

	@Override
	public ResultSet scan(long skey, long ekey, ScanFilter sf) {
		//sf.setFilter();
		return scan(skey, ekey, ptconn, sf.pscanf);
	}

@Override
public ResultSet scan(long skey, long ekey, Transaction txn, ScanFilter sf) {
	//sf.setFilter();
	return scan(skey, ekey, ptconn, txn.pttxn, sf.pscanf);
}

	@Override
	public long count(long skey, long ekey, ScanFilter sf) {
		//sf.setFilter();
		return count(skey, ekey, sf.pscanf, ptconn);
	}

	@Override                                                         
	public byte[] get(byte[] key)
	{
 		return get(key, ptconn);
	}
                                                              
	@Override
	public long put(byte[] key, byte[] val, InsertOptions flag)
	{
 		return put(key, val, (short)flag.ordinal(), ptconn);
	}

@Override
public long put(long key, byte[] val, InsertOptions flag, Transaction txn) {
	return put(key, val, (short)flag.ordinal(), ptconn, txn.pttxn);
}
                                                              
	@Override
	public long del(byte[] key)
	{
 		return del(key, ptconn);
	}
                                 
	@Override                                                
	public ResultSet scan(byte[] skey, byte[] ekey, ScanFilter sf) {        
		//sf.setFilter();
 		return Scan(skey, ekey, ptconn, sf.pscanf);                 
	}        
 
        @Override
        public String get(String key) {
		if(key == null) return null;
		byte[] bv = get(key, key.length(), ptconn);
		if(bv == null) return null;
		String v = null;
		try{
	            v = new String(bv, "UTF8");
		}
		catch (UnsupportedEncodingException e) {
		    v = new String(bv);
		}
		return v;
        }
        
        @Override
        public long put(String key, String val, InsertOptions flag) {
		if(key == null || val == null) return -1;
           	return put(key, key.length(), val, val.length(), (short)flag.ordinal(), ptconn);
        } 
        
        @Override
        public long del(String key) {
		if(key == null) return -1;
            	return del(key, key.length(), ptconn);
        }

	@Override
	public ResultSet scan(String skey, String ekey, ScanFilter sf) {     
		int skeylen = (skey == null)?0:skey.length();
		int ekeylen = (ekey == null)?0:ekey.length();
		//sf.setFilter();
		return Scan(skey, skeylen, ekey, ekeylen, ptconn, sf.pscanf);                 
	}                                                        
	   
        @Override
        public byte[] get(byte[] key, Transaction txn)
        {
        	return get(key, ptconn, txn.pttxn);
        }
        
        @Override
        public long put(byte[] key, byte[] val, InsertOptions flag, Transaction txn)
        {
        	return put(key, val, (short)flag.ordinal(), ptconn, txn.pttxn);
        }
        
        @Override
        public long del(byte[] key, Transaction txn)
        {
        	return del(key, ptconn, txn.pttxn);
        }

@Override
public long del(long key, Transaction txn) {
	return del(key, ptconn, txn.pttxn);
}

	@Override                                                
	public ResultSet scan(byte[] skey, byte[] ekey, Transaction txn, ScanFilter sf) {        
		//sf.setFilter();
		return Scan(skey, ekey, ptconn, txn.pttxn, sf.pscanf);                 
	}                                                	

	@Override
	public String get(String key, Transaction txn) {
		if(key == null) return null;
		byte[] bv = get(key, key.length(), ptconn, txn.pttxn);
		if(bv == null) return null;
		String v = null;
		try{
		    v = new String(bv, "UTF8");
		}
		catch (UnsupportedEncodingException e) {
		     v = new String(bv);
		}
		return v;
	}

	@Override
	public long put(String key, String val, InsertOptions flag, Transaction txn) {
		if(key == null || val == null) return -1;
	    	return put(key, key.length(), val, val.length(), (short)flag.ordinal(), ptconn, txn.pttxn);
	} 

	@Override
	public long del(String key, Transaction txn) {
		if(key == null) return -1;
	    	return del(key, key.length(), ptconn, txn.pttxn);
	}
                                                             
	@Override
	public ResultSet scan(String skey, String ekey, Transaction txn, ScanFilter sf) {  
		int skeylen = (skey == null)?0:skey.length();
		int ekeylen = (ekey == null)?0:ekey.length(); 
		//sf.setFilter();     
		return Scan(skey, skeylen, ekey, ekeylen, ptconn, txn.pttxn, sf.pscanf);                 
	}                                                        
	
	@Override
	public int closeConnection() {
	    return closeconnection(ptconn);
	}	

	@Override
    	public long count(String skey, String ekey, ScanFilter sf)
	{
		int skeylen = (skey == null)?0:skey.length();
		int ekeylen = (ekey == null)?0:ekey.length(); 
		//sf.setFilter();
		return Count(skey, skeylen, ekey, ekeylen, sf.pscanf, ptconn);
	}

	@Override
    	public long count(byte[] skey, byte[] ekey, ScanFilter sf)
	{
		//sf.setFilter();
		return Count(skey, ekey, sf.pscanf, ptconn);
	}

	@Override
    	public long count()
	{
		return Count(ptconn);
	}

	@Override
	public void setAutoCommit(boolean flag)
	{
		SetAutoCommit(flag, ptconn);
	}
	
	/* new API */
	@Override
	public int get(long key, DataVar dv)
	{
		return get_dvar(key, dv.pdv, ptconn);
	}

	@Override
	public ResultSet scan(String skey, String ekey, ScanFilter sf, DataVar dv)
	{
		int skeylen = (skey == null)?0:skey.length();
		int ekeylen = (ekey == null)?0:ekey.length(); 
		//sf.setFilter();     
		return Scan_dvar(skey, skeylen, ekey, ekeylen, sf.pscanf, dv.pdv, ptconn);  
	}

	@Override
	public ResultSet scan(byte[] skey, byte[] ekey, ScanFilter sf, DataVar dv)
	{
		//sf.setFilter();
		return Scan_dvar(skey, ekey, sf.pscanf, dv.pdv, ptconn);
	}
	
	@Override
	public ResultSet scan(long skey, long ekey, ScanFilter sf, DataVar dv)
	{
		//sf.setFilter();
		return Scan_dvar(skey, ekey, sf.pscanf, dv.pdv, ptconn);
	}

	@Override
	public ResultSet scan(String skey, String ekey, Transaction txn, ScanFilter sf, DataVar dv)
	{
		int skeylen = (skey == null)?0:skey.length();
		int ekeylen = (ekey == null)?0:ekey.length(); 
		//sf.setFilter();     
		return Scan_dvar(skey, skeylen, ekey, ekeylen, txn.pttxn, sf.pscanf, dv.pdv, ptconn);  
	}

	@Override
	public ResultSet scan(byte[] skey, byte[] ekey, Transaction txn, ScanFilter sf, DataVar dv)
	{
		//sf.setFilter();
		return Scan_dvar(skey, ekey, txn.pttxn, sf.pscanf, dv.pdv, ptconn);
	}

	@Override
	public ResultSet scan(long skey, long ekey, Transaction txn, ScanFilter sf, DataVar dv)
	{
		//sf.setFilter();
		return Scan_dvar(skey, ekey, txn.pttxn, sf.pscanf, dv.pdv, ptconn);
	}
} 
      
