package bangdb;

public class TableEnv {
	private PersistType _dbtype;
	private IndexType _idxtype;
	private short _keySizeByte;
	private short _logSizeMB;
	private TableSizeHint _tableSizeHint;
	private short _isLogOn;
	private LogType _logType;
	private BangDBTableType _tblType;
	private short _is_autocommit_on;
	private BangDBKeyType _keyType;
	private BangDBSortMethod _sortMethod;
	private BangDBSortDirection _sortDirection;
	private short _allowDuplicates;
private BangDBTableSubType _tblSubType;
private BangDBPrimitiveDataType _primDataType;

	public TableEnv() {
		reset();
	}

	public TableEnv(TableSizeHint TINY_SMALL_NORMAL_BIG, PersistType dbtype, IndexType idxtype, short keySizeByte, boolean is_autocommit_on, boolean isLogOn, LogType logType, short logSizeMB) {
		_tableSizeHint = TINY_SMALL_NORMAL_BIG;
		_dbtype = dbtype;
		_idxtype = idxtype;
		_keySizeByte = keySizeByte;
		_is_autocommit_on = (short)(is_autocommit_on?1:0);
		_logSizeMB = logSizeMB;
		_logType = logType;
		_tblType = BangDBTableType.TABLE_TYPE_INVALID;
		_isLogOn = (short)(isLogOn?1:0);
		_keyType = BangDBKeyType.KEY_TYPE_INVALID;
		_sortMethod = BangDBSortMethod.SORT_METHOD_INVALID;
		_sortDirection = BangDBSortDirection.SORT_DIRECTION_INVALID;
		_tblSubType = BangDBTableSubType.NON_ANALYTICAL_TABLE;
		_primDataType = BangDBPrimitiveDataType.PRIMITIVE_STRING;
		_allowDuplicates = -1;
	}

	public void reset() {
		_tableSizeHint = TableSizeHint.BIG_TABLE_SIZE;
		_dbtype = PersistType.DBTYPE_INVALID;
		_idxtype = IndexType.IndexType_INVALID;
		_keySizeByte = -1;
		_is_autocommit_on = -1;
		_logSizeMB = -1;
		_logType = LogType.LogType_INVALID;
		_tblType = BangDBTableType.TABLE_TYPE_INVALID;
		_isLogOn = -1;
		_keyType = BangDBKeyType.KEY_TYPE_INVALID;
		_sortMethod = BangDBSortMethod.SORT_METHOD_INVALID;
		_sortDirection = BangDBSortDirection.SORT_DIRECTION_INVALID;
		_tblSubType = BangDBTableSubType.NON_ANALYTICAL_TABLE;
		_primDataType = BangDBPrimitiveDataType.PRIMITIVE_STRING;
		_allowDuplicates = -1;
	}
	
	public void setPersistType(PersistType dbtype) {
		_dbtype = dbtype;
	}

	public void setIndexType(IndexType idxtype) {
		_idxtype = idxtype;
	}

	public void setKeySizeByte(short keySizeByte) {
		_keySizeByte = keySizeByte;
	}

	public void setLogSizeMB(short logSizeMB) {
		_logSizeMB = logSizeMB;
	}

	public void setTableSizeHint(TableSizeHint TINY_SMALL_NORMAL_BIG) {
		_tableSizeHint = TINY_SMALL_NORMAL_BIG;
	}

	public void setLogState(boolean isLogOn) {
		_isLogOn = (short)(isLogOn?1:0);
	}

	public void setLogType(LogType logType) {
		_logType = logType;
	}

	public void setTableType(BangDBTableType tblType) {
		_tblType = tblType;
	}

public void setTableSubType(BangDBTableSubType tblSubType) {
	_tblSubType = tblSubType;
}

public void setPrimitiveDataType(BangDBPrimitiveDataType primDataType) {
	_primDataType = primDataType;
}

	public void setAutocommitState(boolean is_autocommit_on) {
		_is_autocommit_on = (short)(is_autocommit_on?1:0);
	}

	public void setKeyType(BangDBKeyType keyType) {
		_keyType = keyType;
	}

	public void setSortMethod(BangDBSortMethod sortMethod) {
		_sortMethod = sortMethod;
	}

	public void setSortDirection(BangDBSortDirection sortDirection) {
		_sortDirection = sortDirection;
	}

	public void setAllowDuplicates(boolean allowDuplicates) {
		_allowDuplicates = (short)(allowDuplicates ? 1 : 0);
	}

	public PersistType getPersistType() {
		return _dbtype;
	}

	public short getDBTypeOrdinal() {
		return (short)PersistType.toInt(_dbtype.ordinal());
	}

	public IndexType getIndexType() {
		return _idxtype;
	}

	public short getIndexTypeOrdinal() {
		return (short)IndexType.toInt(_idxtype.ordinal());
	}

	public short getKeySizeByte() {
		return _keySizeByte;
	}

	public short getLogSizeMB() {
		return _logSizeMB;
	}

	public TableSizeHint getTableSizeHint() {
		return _tableSizeHint;
	}

	public short getTableSizeHintOrdinal() {
		return (short)_tableSizeHint.ordinal();
	}

	public boolean getLogState() {
		return _isLogOn==1?true:false;
	}

	public LogType getLogType() {
		return _logType;
	}

	public short getLogTypeOrdinal() {
		return (short)LogType.toInt(_logType.ordinal());
	}

public short getTableSubTypeOrdinal() {
	return (short)BangDBTableSubType.toInt(_tblSubType.ordinal());
}

public short getPrimitiveDataTypeOrdinal() {
	return (short)BangDBPrimitiveDataType.toInt(_primDataType.ordinal());
}

public BangDBTableSubType getTableSubType() {
	return _tblSubType;
}

public BangDBPrimitiveDataType getPrimitiveDataType() {
	return _primDataType;
}

	public BangDBTableType getTableType() {
		return _tblType;
	}

	public short getTableTypeOrdinal() {
		return (short)BangDBTableType.toInt(_tblType.ordinal());
	}

	public short getLogStateOrdinal() {
		return _isLogOn;
	}

	public boolean getAutocommitState() {
		return _is_autocommit_on==1?true:false;
	}
		     
	public short getAutocommitStateOrdinal() {
		return _is_autocommit_on;
	}

	public BangDBKeyType getKeyType() {
		return _keyType;
	}

	public BangDBSortMethod getSortMethod() {
		return _sortMethod;
	}

	public BangDBSortDirection getSortDirection() {
		return _sortDirection;
	}

	public short getKeyTypeOrdinal() {
		return (short)BangDBKeyType.toInt(_keyType.ordinal());
	}

	public short getSortMethodOrdinal() {
		return (short)BangDBSortMethod.toInt(_sortMethod.ordinal());
		
	}

	public short getSortDirectionOrdinal() {
		return (short)BangDBSortDirection.toInt(_sortDirection.ordinal());
	}

	public boolean getAllowDuplicates() {
		return _allowDuplicates == 1 ? true : false;
	}

	public short getAllowDuplicatesOrdinal() {
		return _allowDuplicates;
	}

	public void tostring()
	{
		System.out.print("TableEnv details .....");
		System.out.print(" TableSizeHint  = " + getTableSizeHintOrdinal());
		System.out.print(", persisttype = " + getDBTypeOrdinal());
		System.out.print(", idxtype = " + getIndexTypeOrdinal());
		System.out.print(", keysize = " + getKeySizeByte());
		System.out.print(", logtype = " + getLogTypeOrdinal());
		System.out.print(", logsizemb = " + getLogSizeMB());
		System.out.print(", logstate = " + getLogStateOrdinal());
		System.out.print(", autocommit = " + getAutocommitStateOrdinal());
		System.out.print(", tabletype = " + getTableTypeOrdinal());
		System.out.print(", keytype = " + getKeyTypeOrdinal());
		System.out.print(", sortmethod = " + getSortMethodOrdinal());
		System.out.println(", sortdir = " + getSortDirectionOrdinal());	
	}
}	
