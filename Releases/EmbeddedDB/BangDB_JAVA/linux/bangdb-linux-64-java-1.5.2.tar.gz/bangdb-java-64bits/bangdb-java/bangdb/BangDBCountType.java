package bangdb;
public enum BangDBCountType {
	UNIQUE_COUNT,
	NON_UNIQUE_COUNT;

	public static BangDBCountType fromInt(int e) {
		switch(e) {
			case 0:
				return UNIQUE_COUNT;
			case 1:
				return NON_UNIQUE_COUNT;
		}
		return UNIQUE_COUNT;
	}

	public static int toInt(int ordinal)
	{
		switch(ordinal)
		{
			case 0:
				return 0;
			case 1:
				return 1;
		}
		return 0;
	}
}
