package bangdb;

import java.io.UnsupportedEncodingException;

public class WideConnectionImpl implements WideConnection {

	public native long put(byte[] key, byte[] val, String indexName, byte[] indexVal, long ptwconn);
	public native ResultSet scan(String indexName, byte[] skey, byte[] ekey, long ptwconn, long pscanf);

        public native byte[] get(String key, int keylen, long ptwconn);
        public native long put(String key, int klen, String val, int vlen, short flag, long ptwconn);
        public native long del(String key, int klen, long ptwconn);
        public native ResultSet Scan(String skey, int skeylen, String ekey, int ekeylen, long ptwconn, long pscanf);

        public native byte[] get( byte[] key, long ptwconn);
        public native long put(byte[] key, byte[] val, short flag, long ptwconn);
        public native long del(byte[] del, long ptwconn);
        public native ResultSet Scan(byte[] skey, byte[] ekey, long ptwconn, long pscanf);
        
        public native byte[] get(String key, int keylen, long ptwconn, long pttxn);
        public native long put(String key, int klen, String val, int vlen, short flag, long ptwconn, long pttxn);
        public native long del(String key, int klen, long ptwconn, long pttxn);
        public native ResultSet Scan(String skey, int skeylen, String ekey, int ekeylen, long ptwconn, long pttxn , long pscanf);

        public native byte[] get( byte[] key, long ptwconn, long pttxn);
        public native long put(byte[] key, byte[] val, short flag, long ptwconn, long pttxn);
        public native long del(byte[] del, long ptwconn, long pttxn);
        public native ResultSet Scan(byte[] skey, byte[] ekey, long ptwconn, long pttxn, long pscanf);

	public native long putDoc(String jsonStr, long ptwconn);

	public native long putDoc(String key, String jsonStr, short flag, long ptwconn);

	public native long putDoc(long key, String jsonStr, short flag, long ptwconn);

	public native ResultSet scanDoc(String idxName, String skey, String ekey, long ptwconn, long pscanf);

	public native ResultSet scanDoc(String idxName, long skey, long ekey, long ptwconn, long pscanf);

	public native long put(String key, String val, String idxName, String idxVal, long ptwconn);

	public native long put(String key, byte[] val, String idxName, String idxVal, long ptwconn);

	public native long put(byte[] key, String val, String idxName, String idxVal, long ptwconn);

	public native long put(long key, String val, String idxName, String idxVal, long ptwconn);

	public native long put(long key, byte[] val, String idxName, String idxVal, long ptwconn);

	public native ResultSet scan(String idxName, String skey, String ekey, long ptwconn, long pscanf);

	public native byte[] getStr(long key, long ptwconn);

	public native byte[] getByte(long key, long ptwconn);

	public native long del(long key, long ptwconn);

	public native long del(long key, long ptwconn, long pttxn);

	public native ResultSet scan(long skey, long ekey, long ptwconn, long pscanf);

	public native ResultSet scan(long skey, long ekey, long ptwconn, long pttxn, long pscanf);

	public native long count(long skey, long ekey, long pscanf, long ptwconn);

	public native long put(long key, String val, int flag, long ptwconn);

	public native long put(long key, byte[] val, int flag, long ptwconn);

	public native long put(long key, byte[] val, int flag, long ptwconn, long pttxn);
       
        public native int closeconnection(long ptwconn);

	public native long Count(String skey, int skeylen, String ekey, int ekeylen, long pscanf, long ptwconn);

	public native long Count(byte[] skey, byte[] ekey, long pscanf, long ptwconn);

    	public native long Count(long ptwconn);

	public native void SetAutoCommit(boolean flag, long ptwconn);

/* new API */

public native ResultSet scanDoc_dvar(String idxName, String skey, int skeylen, String ekey, int ekeylen, long sf, long dv, long ptwconn);

public native ResultSet scanDoc_dvar(String idxName, long skey, long ekey, long sf, long dv, long ptwconn);

public native ResultSet scanDoc_dvar(String idxName, byte[] skey, byte[] ekey, long sf, long dv, long ptwconn);

public native ResultSet scanDoc_dvar(String idxName, byte[] skey, byte[] ekey, long sf, long ptwconn);

public native ResultSet scan_dvar(String idxName, String skey, int skeylen, String ekey, int ekeylen, long sf, long dv, long ptwconn);

public native ResultSet scan_dvar(String idxName, byte[] skey, byte[] ekey, long sf, long dv, long ptwconn);

public native ResultSet scan_dvar(String skey, int skeylen, String ekey, int ekeylen, long sf, long dv, long ptwconn);

public native ResultSet scan_dvar(byte[] skey, byte[] ekey, long sf, long dv, long ptwconn);

public native ResultSet scan_dvar(long skey, long ekey, long sf, long dv, long ptwconn);

public native ResultSet scan_dvar(String skey, int skeylen, String ekey, int ekeylen, long txn, long sf, long dv, long ptwconn);

public native ResultSet scan_dvar(byte[] skey, byte[] ekey, long txn, long sf, long dv, long ptwconn);

public native ResultSet scan_dvar(long skey, long ekey, long txn, long sf, long dv, long ptwconn);

public native int get_dvar(long key, long dv, long ptwconn);

public native int get_dvar(long key, long dv, long txn, long ptwconn);

        public long ptwconn;
        
        public WideConnectionImpl(long conn) {
            ptwconn = conn;
        }
	
	@Override
	public long putDoc(String jsonStr) {
		return putDoc(jsonStr, ptwconn);
	}

	@Override
	public long putDoc(String key, String jsonStr, InsertOptions flag) {
		return putDoc(key, jsonStr, (short)flag.ordinal(), ptwconn);
	}

	@Override
	public long putDoc(long key, String jsonStr, InsertOptions flag)  {
		return putDoc(key, jsonStr, (short)flag.ordinal(), ptwconn);
	}

	@Override
	public ResultSet scanDoc(String idxName, String skey, String ekey, ScanFilter sf)  {
		//sf.setFilter();
		return scanDoc(idxName, skey, ekey, ptwconn, sf.pscanf);
	}
	
	@Override
	public ResultSet scanDoc(String idxName, long skey, long ekey, ScanFilter sf) {
		//sf.setFilter();
		return scanDoc(idxName, skey, ekey, ptwconn, sf.pscanf);
	}

	@Override
	public long put(String key, String val, String idxName, String idxVal) {
		return put(key, val, idxName, idxVal, ptwconn);
	}

	@Override
	public long put(String key, byte[] val, String idxName, String idxVal) {
		return put(key, val, idxName, idxVal, ptwconn);
	}

	@Override
	public long put(byte[] key, String val, String idxName, String idxVal) {
		return put(key, val, idxName, idxVal, ptwconn);
	}

	@Override
	public long put(long key, String val, String idxName, String idxVal) {
		return put(key, val, idxName, idxVal, ptwconn);
	}

	@Override
	public long put(long key, String val, InsertOptions flag) {
		return put(key, val, flag.ordinal(), ptwconn);	
	}

	@Override
	public long put(long key, byte[] val, InsertOptions flag) {
		return put(key, val, flag.ordinal(), ptwconn);
	}

@Override
public long put(long key, byte[] val, InsertOptions flag, Transaction txn) {
	return put(key, val, flag.ordinal(), ptwconn, txn.pttxn);
}

	@Override
	public long put(long key, byte[] val, String idxName, String idxVal) {
		return put(key, val, idxName, idxVal, ptwconn);
	}

	@Override
	public ResultSet scan(String idxName, String skey, String ekey, ScanFilter sf) {
		//sf.setFilter();
		return scan(idxName, skey, ekey, ptwconn, sf.pscanf);
	}

	@Override
	public ResultSet scan(String idxName, byte[] skey, byte[] ekey, ScanFilter sf) {
		//sf.setFilter();
		return scan(idxName, skey, ekey, ptwconn, sf.pscanf);
	}

	@Override
	public String getStr(long key) {
		byte[] v = getStr(key, ptwconn);
		if(v == null)
			return null;
		return new String(v);
	}

	@Override
	public byte[] getByte(long key) {
		return getByte(key, ptwconn);
	}

	@Override
	public long del(long key) {
		return del(key, ptwconn);
	}

	@Override
	public long del(long key, Transaction txn) {
		return del(key, ptwconn, txn.pttxn);
	}

	@Override
	public ResultSet scan(long skey, long ekey, ScanFilter sf) {
		//sf.setFilter();
		return scan(skey, ekey, ptwconn, sf.pscanf);
	}

@Override
public ResultSet scan(long skey, long ekey, Transaction txn, ScanFilter sf) {
	//sf.setFilter();
	return scan(skey, ekey, ptwconn, txn.pttxn, sf.pscanf);
}

	@Override
	public long count(long skey, long ekey, ScanFilter sf) {
		//sf.setFilter();
		return count(skey, ekey, sf.pscanf, ptwconn);
	}
	
	@Override
   	public long put(byte[] key, byte[] val, String index_name, byte[] index_val)
	{
		return put(key, val, index_name, index_val, ptwconn);
	}

	@Override                                                         
	public byte[] get(byte[] key)
	{
 		return get(key, ptwconn);
	}
                                                              
	@Override
	public long put(byte[] key, byte[] val, InsertOptions flag)
	{
 		return put(key, val, (short)flag.ordinal(), ptwconn);
	}
                                                              
	@Override
	public long del(byte[] key)
	{
 		return del(key, ptwconn);
	}
                                                      
	@Override                                                
	public ResultSet scan(byte[] skey, byte[] ekey, ScanFilter sf) {   
		//sf.setFilter();     
 		return Scan(skey, ekey, ptwconn, sf.pscanf);                 
	}                                                	
 
        @Override
        public String get(String key) {
		if(key == null) return null;
		byte[] bv = get(key, key.length(), ptwconn);
		if(bv == null) return null;
		String v = null;
		try{
	            v = new String(bv, "UTF8");
		}
		catch (UnsupportedEncodingException e) {
		    v = new String(bv);
		}
		return v;
        }
        
        @Override
        public long put(String key, String val, InsertOptions flag) {
		if(key == null || val == null) return -1;
           	return put(key, key.length(), val, val.length(), (short)flag.ordinal(), ptwconn);
        } 
        
        @Override
        public long del(String key) {
		if(key == null) return -1;
            	return del(key, key.length(), ptwconn);
        }

	@Override
	public ResultSet scan(String skey, String ekey, ScanFilter sf) {     
		int skeylen = (skey == null)?0:skey.length();
		int ekeylen = (ekey == null)?0:ekey.length();
		//sf.setFilter();
		return Scan(skey, skeylen, ekey, ekeylen, ptwconn, sf.pscanf);                 
	}                                                        
	   
        @Override
        public byte[] get(byte[] key, Transaction txn)
        {
        	return get(key, ptwconn, txn.pttxn);
        }
        
        @Override
        public long put(byte[] key, byte[] val, InsertOptions flag, Transaction txn)
        {
        	return put(key, val, (short)flag.ordinal(), ptwconn, txn.pttxn);
        }
        
        @Override
        public long del(byte[] key, Transaction txn)
        {
        	return del(key, ptwconn, txn.pttxn);
        }

	@Override                                                
	public ResultSet scan(byte[] skey, byte[] ekey, Transaction txn, ScanFilter sf) {
		//sf.setFilter();        
		return Scan(skey, ekey, ptwconn, txn.pttxn, sf.pscanf);                 
	}                                                	

	@Override
	public String get(String key, Transaction txn) {
		if(key == null) return null;
		byte[] bv = get(key, key.length(), ptwconn, txn.pttxn);
		if(bv == null) return null;
		String v = null;
		try{
		    v = new String(bv, "UTF8");
		}
		catch (UnsupportedEncodingException e) {
		     v = new String(bv);
		}
		return v;
	}

	@Override
	public long put(String key, String val, InsertOptions flag, Transaction txn) {
		if(key == null || val == null) return -1;
	    	return put(key, key.length(), val, val.length(), (short)flag.ordinal(), ptwconn, txn.pttxn);
	} 

	@Override
	public long del(String key, Transaction txn) {
		if(key == null) return -1;
	    	return del(key, key.length(), ptwconn, txn.pttxn);
	}
                                                             
	@Override
	public ResultSet scan(String skey, String ekey, Transaction txn, ScanFilter sf) {  
		int skeylen = (skey == null)?0:skey.length();
		int ekeylen = (ekey == null)?0:ekey.length();
		//sf.setFilter();      
		return Scan(skey, skeylen, ekey, ekeylen, ptwconn, txn.pttxn, sf.pscanf);                 
	}                                                        
	
	@Override
	public int closeConnection() {
	    return closeconnection(ptwconn);
	}	

	@Override
    	public long count(String skey, String ekey, ScanFilter sf)
	{
		int skeylen = (skey == null)?0:skey.length();
		int ekeylen = (ekey == null)?0:ekey.length();
		//sf.setFilter(); 
		return Count(skey, skeylen, ekey, ekeylen, sf.pscanf, ptwconn);
	}

	@Override
    	public long count(byte[] skey, byte[] ekey, ScanFilter sf)
	{
		//sf.setFilter();
		return Count(skey, ekey, sf.pscanf, ptwconn);
	}

	@Override
    	public long count()
	{
		return Count(ptwconn);
	}

	@Override
	public void setAutoCommit(boolean flag)
	{
		SetAutoCommit(flag, ptwconn);
	}

	/* new APIs */

@Override
public ResultSet scanDoc(String idxName, String skey, String ekey, ScanFilter sf, DataVar dv)
{
	int skeylen = (skey == null)?0:skey.length();
	int ekeylen = (ekey == null)?0:ekey.length();
	//sf.setFilter();
	return scanDoc_dvar(idxName, skey, skeylen, ekey, ekeylen, sf.pscanf, dv.pdv, ptwconn); 
}

@Override
public ResultSet scanDoc(String idxName, long skey, long ekey, ScanFilter sf, DataVar dv)
{
	//sf.setFilter();
	return scanDoc_dvar(idxName, skey, ekey, sf.pscanf, dv.pdv, ptwconn);
}

@Override
public ResultSet scanDoc(String idxName, byte[] skey, byte[] ekey, ScanFilter sf, DataVar dv)
{
	//sf.setFilter();
	return scanDoc_dvar(idxName, skey, ekey, sf.pscanf, dv.pdv, ptwconn);
}

@Override
public ResultSet scanDoc(String idxName, byte[] skey, byte[] ekey, ScanFilter sf)
{
	//sf.setFilter();
	return scanDoc_dvar(idxName, skey, ekey, sf.pscanf, ptwconn);
}

@Override
public ResultSet scan(String idxName, String skey, String ekey, ScanFilter sf, DataVar dv)
{
	int skeylen = (skey == null)?0:skey.length();
	int ekeylen = (ekey == null)?0:ekey.length();
	//sf.setFilter();
	return scan_dvar(idxName, skey, skeylen, ekey, ekeylen, sf.pscanf, dv.pdv, ptwconn);
}

@Override
public ResultSet scan(String idxName, byte[] skey, byte[] ekey, ScanFilter sf, DataVar dv)
{
	//sf.setFilter();
	return scan_dvar(idxName, skey, ekey, sf.pscanf, dv.pdv, ptwconn);
}

@Override
public ResultSet scanDv(String skey, String ekey, ScanFilter sf, DataVar dv)
{
	int skeylen = (skey == null)?0:skey.length();
	int ekeylen = (ekey == null)?0:ekey.length();
	//sf.setFilter();
	return scan_dvar(skey, skeylen, ekey, ekeylen, sf.pscanf, dv.pdv, ptwconn);
}

@Override
public ResultSet scanDv(byte[] skey, byte[] ekey, ScanFilter sf, DataVar dv)
{
	//sf.setFilter();
	return scan_dvar(skey, ekey, sf.pscanf, dv.pdv, ptwconn);
}

@Override
public ResultSet scanDv(long skey, long ekey, ScanFilter sf, DataVar dv)
{
	//sf.setFilter();
	return scan_dvar(skey, ekey, sf.pscanf, dv.pdv, ptwconn);
}

@Override
public ResultSet scanDv(String skey, String ekey, Transaction txn, ScanFilter sf, DataVar dv)
{
	int skeylen = (skey == null)?0:skey.length();
	int ekeylen = (ekey == null)?0:ekey.length();
	//sf.setFilter();
	return scan_dvar(skey, skeylen, ekey, ekeylen, txn.pttxn, sf.pscanf, dv.pdv, ptwconn);
}

@Override
public ResultSet scanDv(byte[] skey, byte[] ekey, Transaction txn, ScanFilter sf, DataVar dv)
{
	//sf.setFilter();
	return scan_dvar(skey, ekey, txn.pttxn, sf.pscanf, dv.pdv, ptwconn);
}

@Override
public ResultSet scanDv(long skey, long ekey, Transaction txn, ScanFilter sf, DataVar dv)
{
	//sf.setFilter();
	return scan_dvar(skey, ekey, txn.pttxn, sf.pscanf, dv.pdv, ptwconn);
}

@Override
public int get(long key, DataVar dv)
{
	return get_dvar(key, dv.pdv, ptwconn);
}

@Override
public int get(long key, DataVar dv, Transaction txn)
{
	return get_dvar(key, dv.pdv, txn.pttxn, ptwconn);
}

} 
      
