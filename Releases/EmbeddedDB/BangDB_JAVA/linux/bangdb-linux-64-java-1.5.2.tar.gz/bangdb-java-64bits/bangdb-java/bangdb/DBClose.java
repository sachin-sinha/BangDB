package bangdb;
public enum DBClose {

    	DEFAULT, 
	CONSERVATIVE, 
	OPTIMISTIC, 
	CLEANCLOSE, 
	SIMPLECLOSE;

	public static DBClose fromInt(int e) {
		switch(e) {
			case 0:
				return DEFAULT;
			case 1:
				return CONSERVATIVE;
			case 2:
				return OPTIMISTIC;
			case 3:
				return CLEANCLOSE;
			case 4:
				return SIMPLECLOSE;
		}
		return DEFAULT;
	}

	public static int toInt(int ordinal)
	{
		switch(ordinal)
		{
			case 0:
				return 0;
			case 1:
				return 1;
			case 2:
				return 2;
			case 3:
				return 3;
			case 4:
				return 4;
		}
		return 0;
	}

}
