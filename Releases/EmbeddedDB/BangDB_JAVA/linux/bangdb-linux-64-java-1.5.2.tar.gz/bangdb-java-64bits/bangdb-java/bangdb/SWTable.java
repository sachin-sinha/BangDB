package bangdb;

public interface SWTable {

	public void addIndex(String idxName, TableEnv tenv);

	public void initialize();
/* */
	public WideConnectionImpl getConnection();

	public WideConnectionImpl getActiveConnection();

	public WideConnectionImpl getPassiveConnection();

	public int getTTLSec();
/* */

	public int put(String str, InsertOptions iop);

	public int put(String str, String idx, String idxKey);

	public ResultSet scan(int period);

	public ResultSet scan(int period, int lag);

	public ResultSet scanFull();

	public ResultSet scanRemaining(long fromTime, int lag);

	public void close();
}
