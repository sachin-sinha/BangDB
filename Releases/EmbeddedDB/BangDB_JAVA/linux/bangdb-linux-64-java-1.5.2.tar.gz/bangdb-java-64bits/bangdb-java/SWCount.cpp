#include "bangdb_SWCountImpl.h"
#include "swCount.h"
using namespace bangdb;

JNIEXPORT jlong JNICALL Java_bangdb_SWCountImpl_init
  (JNIEnv *env, jobject obj, jint swTime, jint swExpiry, jshort swType)
{
	swCount *swc = new swCount((int)swTime, (int)swExpiry, (bangdb_count_type)swType);
	return (jlong)swc;
}

JNIEXPORT void JNICALL Java_bangdb_SWCountImpl_add
  (JNIEnv *env, jobject obj, jstring str, jint len, jlong ptswc)
{
	jboolean iscopy;
	const char *s = env->GetStringUTFChars(str, &iscopy);
	swCount *swc = (swCount*)ptswc;
	swc->add((char*)s, (int)len);
	env->ReleaseStringUTFChars(str, s);
}

JNIEXPORT jint JNICALL Java_bangdb_SWCountImpl_count
  (JNIEnv *env, jobject obj, jlong ptswc)
{
	return (jint)(((swCount*)ptswc)->count());
}

JNIEXPORT void JNICALL Java_bangdb_SWCountImpl_shutdown
  (JNIEnv *env, jobject obj, jlong ptswc)
{
	swCount *swc = (swCount*)ptswc;
	swc->close();
	delete swc;
}

JNIEXPORT jint JNICALL Java_bangdb_SWCountImpl_count__IJ
  (JNIEnv *env, jobject obj, jint span, jlong ptswc)
{
	return (jint)(((swCount*)ptswc)->count(span));
}

JNIEXPORT jintArray JNICALL Java_bangdb_SWCountImpl_list
  (JNIEnv *env, jobject obj, jint span, jlong ptswc)
{
	return NULL;
}

JNIEXPORT void JNICALL Java_bangdb_SWCountImpl_foldSlots
  (JNIEnv *env, jobject obj, jlong ptswc)
{
	((swCount*)ptswc)->foldSlots();
}

JNIEXPORT void JNICALL Java_bangdb_SWCountImpl_reset
  (JNIEnv *env, jobject obj, jlong ptswc)
{
	((swCount*)ptswc)->reset();
}
