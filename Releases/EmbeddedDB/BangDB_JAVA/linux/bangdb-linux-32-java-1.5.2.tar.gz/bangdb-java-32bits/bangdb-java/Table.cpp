#include "database.h"
#include "bangdb_TableImpl.h"
#include "table.h"
#include "iostream"
using namespace std;
using namespace bangdb;

JNIEXPORT jlong JNICALL Java_bangdb_TableImpl_init (JNIEnv *env, jobject obj, jstring rname, jshort openflg, jobject tenv) 
{
/*
    jboolean iscopy;
    const char *r_name = env->GetStringUTFChars(rname, &iscopy);
    table *tb = new table((char*)r_name, (SHORT_T) openflg, NULL, NULL);
    env->ReleaseStringUTFChars(rname,  r_name);
    jlong pttb = (jlong) tb;
    return pttb;
  */
	return -1;  
}

JNIEXPORT jstring JNICALL Java_bangdb_TableImpl_getname(JNIEnv *env, jobject, jlong pttb)
{
       table *tb = (table *) pttb;
       char *tbname = tb->getname();
       jstring tablebname = env->NewStringUTF(tbname);
       return tablebname;
}

JNIEXPORT jobject JNICALL Java_bangdb_TableImpl_getconnection (JNIEnv *env, jobject obj, jlong pttb)
{
    table *tbl =(table *) pttb;
    connection *conn = tbl->getconnection();
    jclass connClass = env->FindClass("bangdb/ConnectionImpl");
    jmethodID midConstructor = env->GetMethodID(connClass, "<init>", "(J)V");
    jobject connObject = env->NewObject(connClass, midConstructor, (jlong)conn);
    return connObject;
}

JNIEXPORT jint JNICALL Java_bangdb_TableImpl_getTableType
  (JNIEnv *env, jobject obj, jlong pttb)
{
	return (int)((((table*) pttb)->get_table_impl())->getTableType());
}

JNIEXPORT jobject JNICALL Java_bangdb_TableImpl_getPrimConnection (JNIEnv *env, jobject obj, jlong pttb)
{
    table *tbl =(table *) pttb;
    primConnection *conn = tbl->getPrimConnection();
    jclass connClass = env->FindClass("bangdb/PrimConnectionImpl");
    jmethodID midConstructor = env->GetMethodID(connClass, "<init>", "(J)V");
    jobject connObject = env->NewObject(connClass, midConstructor, (jlong)conn);
    return connObject;
}

JNIEXPORT jint JNICALL Java_bangdb_TableImpl_closeconnection (JNIEnv *env, jobject obj, jobject connobj, jlong pttb)
{
    table *tb =(table *) pttb;
    jclass cl = env->GetObjectClass(connobj);
    jfieldID fld = env->GetFieldID(cl, "ptconn", "J");
    jlong ptconn = env->GetLongField(connobj, fld);
    connection *conn = (connection *) ptconn;
    jint ret = (jint) tb->closeconnection(conn);
    delete conn;
    return ret;
}

JNIEXPORT void JNICALL Java_bangdb_TableImpl_dumpdata (JNIEnv *env, jobject obj, jlong pttb)
{
    table *tb =(table *) pttb;    
    tb->dumpdata();
}

JNIEXPORT jint JNICALL Java_bangdb_TableImpl_getindextype (JNIEnv *env, jobject obj, jlong pttb)
{
    table *tb =(table *) pttb; 
    return (jint) tb->getindextype();
}

JNIEXPORT void JNICALL Java_bangdb_TableImpl_printstats (JNIEnv *env, jobject obj, jlong pttb)
{
/*
   table *tb =(table *) pttb;
   tb->printstats();
*/
}

JNIEXPORT jint JNICALL Java_bangdb_TableImpl_closetable (JNIEnv *env, jobject obj, jlong pttb, jshort tableclose)
{
    table *tb =(table *) pttb;
    jint ret = (jint) tb->closetable((bangdb_close_type)tableclose); 
    delete tb;
    return ret; 
}

JNIEXPORT jint JNICALL Java_bangdb_TableImpl_simple_1close (JNIEnv *env, jobject obj, jlong pttb)
{
	return 0;
/*
    table *tb =(table *) pttb;
    return (jint) tb->simple_close();
*/
} 
