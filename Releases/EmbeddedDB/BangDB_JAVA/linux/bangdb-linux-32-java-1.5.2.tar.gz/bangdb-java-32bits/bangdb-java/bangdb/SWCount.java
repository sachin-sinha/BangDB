package bangdb;

public interface SWCount {

	public void add(String str);

	public int count();
/* */
	public int count(int span);

	public int[] list(int span);

	public void foldSlots();

	public void reset();
/* */
	public void shutDown();
}
