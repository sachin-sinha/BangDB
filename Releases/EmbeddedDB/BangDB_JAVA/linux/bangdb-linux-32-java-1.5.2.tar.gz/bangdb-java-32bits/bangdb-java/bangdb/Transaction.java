package bangdb;

public class Transaction
{
	public native boolean is_active(long pttxn);
	public native void close(long pttxn);
	public long pttxn;

	public Transaction() {
		pttxn = -999999;
	}
	
	public boolean isActive() {
		return is_active(pttxn);
	}

	public void close() {
		if(pttxn != -999999) {
			close(pttxn);
			pttxn = -999999;
		}
	}

	public void finalize() {
		close();
	}

}
